<?php

namespace Drupal\custom_newapi\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\taxonomy\Entity\Term;
use Drupal\file\Entity\File;

/**
 * Class CustomNewapiContentPage.
 */
class CustomNewapiContentPage extends ControllerBase {

  public function genrate( Request $request ) {
    $data = json_decode( $request->getContent(), TRUE );
$count = 0;
    foreach($data as $one_node_data)
{
        $title = isset($one_node_data['title']) ? $one_node_data['title'] : "" ;
    $rolpages_page_no = isset($one_node_data['rolpages_page_no']) ? $one_node_data['rolpages_page_no'] : "" ;
    $rolpages_unique_id = isset($one_node_data['rolpages_unique_id']) ? $one_node_data['rolpages_unique_id'] : "" ;
    $node = Node::create([
          'type'        => 'role_pages',
          'title'       => $title,
          'field_rolpages_page_no'=>$rolpages_page_no,
          'field_rolpages_unique_id'=>$rolpages_unique_id,
    ]);
$node->save();
$response['data'][$count]['nid'] =  '656';
          $response['data'][$count]['rolpages_unique_id'] =  "sdfERT-4323sdEWw-324ds";
          $count = $count + 1;
}    

    

    
    


          return new JsonResponse( $response );
  }     
  /**
   * It will return html data.
   *
   * @return html
   *   Return html output.
   */
  /*
  public function content() {
    /*try{
          
          //$nodeObj = Node::load($node->id());
          //$response['response'] =  'Success';
          //$response['code'] =  200;
          
        }catch(Exception $e){
          $response['response'] =  'Error';
          $response['code'] =  500;
          $response['data'] =  'Error in saving node data';
        }  


    /// CREATE Role Pages ///
    //if(($stage_layer_uniqueid <> "") && ($node_play_unique_id <> "")) {
for($counter = 1; $counter < 600; $counter++){
            drupal_set_message("hi");
      $node_role_pages = \Drupal::entityManager()->getStorage('node')->create([
        'type'=>'role_pages',
                  'field_rolpages_page_no'=>'1',
      'title'=>'Test Iqbal ' . $counter,
      ]);
      $node_role_pages->save();
   // } // END IF FOR CHECKING UNIQUE ID VALUES ///
}

    $stage_layers = "32423";
    $other_layers = "645";
              return [
        'pageview_count' => [
          '#markup' => 'Roles '.$stage_layers.' stage '.$other_layers.' Remaining ',
          '#prefix' => '<div class="pageview_count">',
          '#suffix' => '</div>',
        ],
      ];


  }/// END FUNCTION ///

  */
}/// END CLASS ///
