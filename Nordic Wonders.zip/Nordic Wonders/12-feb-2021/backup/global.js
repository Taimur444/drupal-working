/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.nordicwonders = {
    attach: function (context, settings) {
    
    }
  };
$(document).ready(function(){
    $('.field-group-accordion-wrapper h3:nth-child(1)').addClass("40");
    $('.field-group-accordion-wrapper h3:nth-child(3)').addClass("50");
    $('.field-group-accordion-wrapper h3:nth-child(5)').addClass("51");
    $('.field-group-accordion-wrapper h3:nth-child(7)').addClass("52");
    $('.field-group-format-toggler.accordion-item').css({"display":"none"});
//    $('#edit-field-contact-type').change(function(){
//        $('.field-group-format-toggler.accordion-item').hide();
//        $('#' + $(this).val()).show();
//        $(this).val().show();
//    });
    
  
    
    $("select#edit-field-contact-type").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".field-group-format-toggler.accordion-item").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".field-group-format-toggler.accordion-item").hide();
            }
        });
    }).change();

    
    
});
})(jQuery, Drupal);
