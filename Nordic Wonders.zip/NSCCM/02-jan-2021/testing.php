if($node->bundle() == "signup"){
  	
    if(is_numeric($node->field_group[0]->target_id)){
	  $event_node1 = \Drupal\group\Entity\Group::load($node->field_group[0]->target_id);
	  $filld_seats = seats_fill_for_events($node->field_group[0]->target_id);
	  $event_node1->field_seats_left[0]->value = 0;
	  if($filld_seats < $event_node1->field_seats[0]->value){
	    $event_node1->field_seats_left[0]->value = $event_node1->field_seats[0]->value - $filld_seats;
		$event_node1->field_seats_filled[0]->value = $filld_seats;
		$event_node1->field_waiting_list[0]->value = 0;
		
		$to = $node->field_email[0]->value;
		
		$subject = $node->field_email_notify_available->getFieldDefinition()->getLabel();
		
		$form_email = $config->get('email');
		
		$message = $node->field_email_notify_available[0]->value;
		$message = str_replace("%name",$node->title->value,$message);
		$message = str_replace("%event",$event_node1->label->value,$message);
		$headers = "From: " . $form_email . "\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8";	  
	  
	    //mail($to, $subject, $message, $headers);
		
		
		$mailManager = \Drupal::service('plugin.manager.mail');
		$module = 'custom_code_module';
		$key = 'create_signup';
		
		$paramss['mail_subject'] = $subject;
		$paramss['mail_message'] = $message;
		
	    $langcode = \Drupal::currentUser()->getPreferredLangcode();
	    $send = true;	
			
		$mailManager->mail($module, $key, $to, $langcode, $paramss, NULL, $send);	
				
		
		$system_site_config = \Drupal::config('system.site');
        $site_email = $system_site_config->get('mail');
		$to1 = $config->get('email');
		
		$subject1 = $node->field_email_notify_admin->getFieldDefinition()->getLabel();
		
		$form_email1 = $config->get('email');
		global $base_url;
		$message1 = $node->field_email_notify_admin[0]->value;
		$message1 = str_replace("%event_link_signups",$base_url."/group/".$node->field_group[0]->target_id. "/signups",$message1);
		$message1 = str_replace("%name",$node->title->value,$message1);
		$message1 = str_replace("%event",$event_node1->label->value,$message1);
		
		$fields = array('field_phone', 'field_email', 'field_company', 'field_titel', 'field_cvr', 'field_ean', 'field_comment', 'field_company_address', 'field_invoice_address');
		$fields_label = array('Telefon', 'E-mail', 'Firma / Organisation', 'Titel', 'CVR-nummer', 'EAN-nummer', 'Kommentar', 'Firmaadresse', 'Faktura stiles til');
		$message1 = str_replace("%data_name%","<b>Navn:</b> " . $node->title->value . "<br>",$message1);
		drupal_set_message("line 157");
		for($i = 0; $i < count($fields); $i++){

		    $field_object = $node->get($fields[$i])->getValue();
			if(isset($field_object[0]['value'])){
		      $message1 = str_replace("%data_".$fields[$i]."%","<b>". $fields_label[$i] . ":</b> " . $field_object[0]['value'] . "<br>",$message1);
		    }
		    if(!isset($field_object[0]['value'])){
		      $message1 = str_replace("%data_".$fields[$i]."%",'',$message1);
		    }
	    }
				
				
				
				
		////////////////////////////////////////////////////   Start Extra Part ////////////////////////////////////////////////////////
		$extra_part = "<div>";
		$index_extra = 0;
        foreach($node->field_colleges as $key => $item){
	      $item = $item->value;
	      $fc = \Drupal\field_collection\Entity\FieldCollectionItem::load($item);	 
		  if($index_extra == 0){ 
		    $extra_part = $extra_part . "<h3>Flere deltagere</h3><b>Navn:</b> " . $fc->get('field_name_colleges')->getValue()[0]['value'] . "<br><b>E-mail:</b> " . $fc->get('field_email_colleges')->getValue()[0]['value']  . "<br><b>Telefon:</b> " . $fc->get('field_phone')->getValue()[0]['value']  . "<br><b>Title:</b> " . $fc->get('field_title')->getValue()[0]['value'] . "<br>";
		  }
		  if($index_extra != 0){ 
		    $extra_part = $extra_part . "<b>Navn:</b> " . $fc->get('field_name_colleges')->getValue()[0]['value'] . "<br><b>E-mail:</b> " . $fc->get('field_email_colleges')->getValue()[0]['value']  . "<br><b>Telefon:</b> " . $fc->get('field_phone')->getValue()[0]['value']  . "<br><b>Title:</b> " . $fc->get('field_title')->getValue()[0]['value'] . "<br>";
		  }
		  $index_extra = $index_extra + 1;
		  
		  
		  
			$to = $fc->get('field_email_colleges')->getValue()[0]['value'];
			
			$subject = $node->field_email_notify_available->getFieldDefinition()->getLabel();
			
			$form_email = $config->get('email');
			
			$message = $node->field_email_notify_available[0]->value;
			$message = str_replace("%name",$fc->get('field_name_colleges')->getValue()[0]['value'],$message);
			$message = str_replace("%event",$event_node1->label->value,$message);
			$headers = "From: " . $form_email . "\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=UTF-8";	  
			
			
			$mailManager = \Drupal::service('plugin.manager.mail');
			$module = 'custom_code_module';
			$key = 'create_signup';
			
			$paramss['mail_subject'] = $subject;
			$paramss['mail_message'] = $message;
			
			$langcode = \Drupal::currentUser()->getPreferredLangcode();
			$send = true;	
				
			$mailManager->mail($module, $key, $to, $langcode, $paramss, NULL, $send);			  
		  
		  
		  
		  
		  
		  
        }	
		
        $extra_part = $extra_part . "</div><br>";
		
		$message1 = str_replace("%extra_part%", $extra_part, $message1);
		
		////////////////////////////////////////////////////   End Extra Part ////////////////////////////////////////////////////////
				
				
				
				
				
				
		$headers = "From: " . $form_email . "\r\n";
		$headers .= "Cc: " . $config->get('email_cc') . "\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8";	  
	  
	   // mail($to1, $subject1, $message1, $headers);	
		
		
		$mailManager = \Drupal::service('plugin.manager.mail');
		$module = 'custom_code_module';
		$key = 'create_signup';
		
		$paramss['mail_subject'] = $subject1;
		$paramss['mail_message'] = $message1;
		
	    $langcode = \Drupal::currentUser()->getPreferredLangcode();
	    $send = true;	
			
		$mailManager->mail($module, $key, $to1, $langcode, $paramss, NULL, $send);	
		
						
				
	  }

	  
	if($event_node1->field_seats_left[0]->value == 0){
	  	 drupal_set_message("line 259");
	     $event_node1->field_waiting_list[0]->value = $filld_seats - $event_node1->field_seats[0]->value;
		 $event_node1->field_seats_filled[0]->value = $filld_seats;
		
		 $to = $node->field_email[0]->value;
		
		 $subject = $node->field_email_notify_waiting->getFieldDefinition()->getLabel();
		
		 $form_email = $config->get('email');
		
		 $message = $node->field_email_notify_waiting[0]->value;
		 $message = str_replace("%name",$node->title->value,$message);
		 $message = str_replace("%event",$event_node1->label->value,$message);
		 $headers = "From: " . $form_email . "\r\n";
		 $headers .= "MIME-Version: 1.0\r\n";
		 $headers .= "Content-Type: text/html; charset=UTF-8";	  
	  
	     //mail($to, $subject, $message, $headers);
		
		
		 $mailManager = \Drupal::service('plugin.manager.mail');
		 $module = 'custom_code_module';
		 $key = 'create_signup';
		
		 $paramss['mail_subject'] = $subject;
		 $paramss['mail_message'] = $message;
		
	     $langcode = \Drupal::currentUser()->getPreferredLangcode();
	     $send = true;	
			
		 $mailManager->mail($module, $key, $to, $langcode, $paramss, NULL, $send);	 		
		
		
		 $system_site_config = \Drupal::config('system.site');
         $site_email = $system_site_config->get('mail');
		 $to1 = $config->get('email');
		
		 $subject1 = $node->field_email_notify_admin->getFieldDefinition()->getLabel();
		
		 $form_email1 = $config->get('email');
		 global $base_url;
		 $message1 = $node->field_email_notify_admin[0]->value;
		 $message1 = str_replace("%event_link_signups",$base_url."/group/".$node->field_group[0]->target_id. "/signups",$message1);
		 $message1 = str_replace("%name",$node->title->value,$message1);
		 $message1 = str_replace("%event",$event_node1->label->value,$message1);
		
		 $fields = array('field_phone', 'field_email', 'field_company', 'field_titel', 'field_cvr', 'field_ean', 'field_comment', 'field_company_address', 'field_invoice_address');
		 $fields_label = array('Telefon', 'E-mail', 'Firma / Organisation', 'Titel', 'CVR-nummer', 'EAN-nummer', 'Kommentar', 'Firmaadresse', 'Faktura stiles til');
		 $message1 = str_replace("%data_name%","<b>Navn:</b> " . $node->title->value,$message1);
		  for($i = 0; $i < count($fields); $i++){
		    $field_object = $node->get($fields[$i])->getValue();
			if(isset($field_object[0]['value'])){
		      $message1 = str_replace("%data_".$fields[$i]."%","<b>". $fields_label[$i] . ":</b> " . $field_object[0]['value'] . "<br>",$message1);
		    }
		    if(!isset($field_object[0]['value'])){
		      $message1 = str_replace("%data_".$fields[$i]."%",'',$message1);
		    }
		  }		
		
		
		////////////////////////////////////////////////////   Start Extra Part ////////////////////////////////////////////////////////
		
		
		$extra_part = "<div>";
		$index_extra = 0;
        foreach($node->field_colleges as $key => $item){
	      $item = $item->value;
	      $fc = \Drupal\field_collection\Entity\FieldCollectionItem::load($item);	 
		  if($index_extra == 0){ 
		    $extra_part = $extra_part . "<h3>Flere deltagere</h3><b>Navn:</b> " . $fc->get('field_name_colleges')->getValue()[0]['value'] . "<br><b>E-mail:</b> " . $fc->get('field_email_colleges')->getValue()[0]['value'] . "<br><b>Telefon:</b> " . $fc->get('field_phone')->getValue()[0]['value']  . "<br><b>Title:</b> " . $fc->get('field_title')->getValue()[0]['value'] . "<br>";
		  }
		  if($index_extra != 0){ 
		    $extra_part = $extra_part . "<b>Navn:</b> " . $fc->get('field_name_colleges')->getValue()[0]['value'] . "<br><b>E-mail:</b> " . $fc->get('field_email_colleges')->getValue()[0]['value']  . "<br><b>Telefon:</b> " . $fc->get('field_phone')->getValue()[0]['value']  . "<br><b>Title:</b> " . $fc->get('field_title')->getValue()[0]['value'] . "<br>";
		  }
		  $index_extra = $index_extra + 1;
		  
		  
		  
		  
	         $to = $fc->get('field_email_colleges')->getValue()[0]['value'];
			
			$subject = $node->field_email_notify_waiting->getFieldDefinition()->getLabel();
			
			$form_email = $config->get('email');
			
			$message = $node->field_email_notify_waiting[0]->value;
			$message = str_replace("%name",$fc->get('field_name_colleges')->getValue()[0]['value'],$message);
			$message = str_replace("%event",$event_node1->label->value,$message);
			$headers = "From: " . $form_email . "\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=UTF-8";	  
		  
			//mail($to, $subject, $message, $headers);
			
			
			$mailManager = \Drupal::service('plugin.manager.mail');
			$module = 'custom_code_module';
			$key = 'create_signup';
			
			$paramss['mail_subject'] = $subject;
			$paramss['mail_message'] = $message;
			
			$langcode = \Drupal::currentUser()->getPreferredLangcode();
			$send = true;	
				
			$mailManager->mail($module, $key, $to, $langcode, $paramss, NULL, $send);			  
			  
		  
		  
		  
		  
        }		
		
        $extra_part = $extra_part . "</div><br>";
		
		$message1 = str_replace("%extra_part%", $extra_part, $message1);	
		
		
		////////////////////////////////////////////////////   End Extra Part ////////////////////////////////////////////////////////
		
		
		
		
		$headers = "From: " . $form_email . "\r\n";
		$headers .= "Cc: " . $config->get('email_cc') . "\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		$headers .= "Content-Type: text/html; charset=UTF-8";	  
	  
	    //mail($to1, $subject1, $message1, $headers);		
		
		$mailManager = \Drupal::service('plugin.manager.mail');
		$module = 'custom_code_module';
		$key = 'create_signup';
		
		$paramss['mail_subject'] = $subject1;
		$paramss['mail_message'] = $message1;
		
	    $langcode = \Drupal::currentUser()->getPreferredLangcode();
	    $send = true;	
			
		$mailManager->mail($module, $key, $to1, $langcode, $paramss, NULL, $send);		
				
	  }

      if (is_object($event_node1)) {
        $event_node1->save();
       }

    }
	
	$language = \Drupal::languageManager()->getCurrentLanguage()->getId();
	if($language == "da"){
	  $new_path = '/da/node/61';
	}
	if($language == "en"){
	  $new_path = '/en/node/61';
	}
       $response = new Symfony\Component\HttpFoundation\RedirectResponse($new_path);
       $response->send();
       return;
	
  }
  if($node->bundle() == "event"){
	$event_node2 = \Drupal\node\Entity\Node::load($node->id());
    $event_node2->field_seats_left[0]->value = $event_node2->field_seats[0]->value;
    if (is_object($event_node2)) {
      $event_node2->save();
    }
  }
}