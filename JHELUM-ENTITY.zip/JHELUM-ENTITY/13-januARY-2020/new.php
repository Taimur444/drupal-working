<?php

$str = '&lt;a href=&quot;https://www.figover.com&quot;&gt;w3schools.com&lt;/a&gt; ';
echo html_entity_decode($str);

 
?>