jQuery Custom Input File Plugin - version 1.0
Copyright 2014, �ngel Espro, http://www.aesolucionesweb.com.ar,
Licence : GNU General Public License (read "gpl.txt")

Demos, documentation and downloads:
http://www.aesolucionesweb.com.ar/plugins/custom-input-file
