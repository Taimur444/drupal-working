
(function ($) {
  
    $("#someDiv").load("http://localhost/drupal8/node/1");
      
})(jQuery)