<?php

namespace Drupal\kiosk_pin_code\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
/**
 * Show textfields based on AJAX-enabled checkbox clicks.
 *
 * @ingroup ajax_example
 */
class simpleAjaxForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'simple_ajax_form';
  }

  /**
   * {@inheritdoc}
   *
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['message'] = [
      '#type' => 'markup',
      '#markup' => '<div class="result_message"></div>',
    ];
    $form['pincode'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Pin-Code'),
    
    ];
 /* $form['pincode2'] = [
      '#type' => 'textfield',
      '#title' => $this->t('pincode2'),
      
    ];*/

    $form['actions'] = [
      '#type' => 'submit',
      '#value' => $this->t('check'),
      '#ajax' => [
        'callback' => '::setMessage',
        
      ],
    ];

    return $form;
  }

  


  /**
   * {@inheritdoc}
   */
  public function setMessage(array &$form, FormStateInterface $form_state) {
    $responce = new AjaxResponse();
    $responce -> addCommand (
      new HtmlCommand(
        '.result_message',
       /* '<div class="my_top_message">'.$this->t('the result is @result',['@result' =>($form_state->getValue('pincode') + $form_state->getValue('pincode2'))])*/
      )
    );
    return $responce;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    $nid = 17; 
    $node_storage = \Drupal::entityTypeManager()->getStorage('node');
    $node1 = $node_storage->load($nid);
    $pincode_field = $node1->get('field_pin_code')->value; 
    $pincode_form_value = $form_state->getValue('pincode');
    if ($pincode_form_value ==$pincode_field) {
      drupal_set_message(serialize($pincode_field .'new-values' . $pincode_form_value  ));
    }
    else{
      drupal_set_message('not same value');
     //$form_value = $form_state->getValue('pincode')
    }
   // drupal_set_message(serialize($pincode_field.$form_value));
   /* $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
    db_insert('kiosk_pincode2')
    ->fields(array(
      'pincode' => $form_state->getValue('pincode'),
      'pincode2' => $form_state->getValue('pincode2'),
    ))
    ->execute();
    drupal_set_message(t('value stored to database67767'));*/
  }



        


}
