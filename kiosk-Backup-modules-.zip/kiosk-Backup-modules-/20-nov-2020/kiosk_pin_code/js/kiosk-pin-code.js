
(function ($) {
     alert('JavaScript is working');
    $("#someDiv").load("http://localhost/drupal8/node/1");


}
jQuery(document).ready(function() {
	alert('JavaScript is working1');
/*if (jQuery(window).width() <= 767) {
  jQuery('.carousel-container #glassBlockCarousel .carousel-inner .carousel-item img').removeClass("cboxElement");
  jQuery( ".carousel-container #glassBlockCarousel .carousel-inner .carousel-item" ).each(function( index ) {
    var imageElement = jQuery(this).find("img");
    var imagePathOld = jQuery( this).find("img").attr("src");
    var imagePath = imagePathOld.replace("/styles/350x350/public", "");
    var hrefImageElement = "<a href='" + imagePath + "' target=_blank>" + imageElement.prop('outerHTML') + "</a>";
    jQuery(this).html(hrefImageElement);
  });*/

}

      
})(jQuery)