<?php

namespace Drupal\kiosk_pin_code\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
/**
 * Show textfields based on AJAX-enabled checkbox clicks.
 *
 * @ingroup ajax_example
 */
class SimpleForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'simple_form';
  }

  /**
   * {@inheritdoc}
   *
   * This form has two checkboxes which the user can check in order to then
   * reveal the first and/or last name text fields.
   *
   * We could perform this behavior with #states. We might not want to if, for
   * instance, we wanted to require a name, but let the user choose whether
   * to enter first or last or both.
   *
   * For all the requests this class gets, the buildForm() method will always be
   * called. If an AJAX request comes in, the form state will be set to the
   * state the user changed that caused the AJAX request. So if the user enabled
   * one of our checkboxes, it will be checked in $form_state.
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    
    $form['pincode'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Pincode'),
      /*'#ajax' => [
        'callback' => '::textfieldsCallback',
        'wrapper' => 'textfields-container',
        'effect' => 'fade',
      ],*/
    ];
    $form['pincode2'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Pincode2'),
      /*'#ajax' => [
        'callback' => '::textfieldsCallback',
        'wrapper' => 'textfields-container',
        'effect' => 'fade',
      ],*/
    ];
    
    $form['actions'] = [
      '#type' => 'submit',
      '#value' => $this->t('submit'),
      /* '#ajax' => [
        'callback' => '::setMessage',
    ];*/
  ];
    return $form;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    drupal_set_message($form_state ->getvalue('pincode') + $form_state ->getvalue('pincode2') );

    $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
    db_insert('kiosk_pincode2')
    ->fields(array(
      'pincode' => $form_state->getValue('pincode'),
      'pincode2' => $form_state->getValue('pincode2'),
    ))
    ->execute();
    drupal_set_message(t('value stored to database'));
  }
public function node_load(){
    $nid = 16; 
    $node_storage = \Drupal::entityTypeManager()->getStorage('node');
    $node1 = $node_storage->load($nid);
    $pincode_field = $node1->get('field_pin_code')->value; 
    drupal_set_message(serialize($pincode_field));       
 }

  /**
   * Callback for ajax_example_autotextfields.
   *
   * Selects the piece of the form we want to use as replacement markup and
   * returns it as a form (renderable array).
   */
 /* public function textfieldsCallback($form, FormStateInterface $form_state) {
    
  }*/

}
