<?php
namespace Drupal\kiosk_pin_code\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\kiosk_pin_code\Form\simpleAjaxForm;


class kioskController{
  public function welcomes() {
    
    return array(
      '#markup' => 'Welcome to our Website kiosk_pin_code.'
    );
  }


}