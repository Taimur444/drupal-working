<?php
namespace Drupal\welcome_module\Controller;
class WelcomesController {
  public function welcomes() {
    return array(
      '#markup' => 'Welcome to our Website kiosk_pin_code.'
    );
  }
}