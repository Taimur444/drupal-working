/**
 * @file
 * Global utilities.
 *
 */
/*
function onresize (){
if (jQuery(window).width() <= 767) {
  jQuery('.carousel-container #glassBlockCarousel .carousel-inner .carousel-item img').removeClass("cboxElement");
  jQuery( ".carousel-container #glassBlockCarousel .carousel-inner .carousel-item" ).each(function( index ) {
    var imageElement = jQuery(this).find("img");
    var imagePathOld = jQuery( this).find("img").attr("src");
    var imagePath = imagePathOld.replace("/styles/350x350/public", "");
    var hrefImageElement = "<a href='" + imagePath + "' target=_blank>" + imageElement.prop('outerHTML') + "</a>";
    jQuery(this).html(hrefImageElement);
  });
}
else if (jQuery(window).width() == 768){
  jQuery('.carousel-container #glassBlockCarousel .carousel-inner .carousel-item img').addClass("cboxElement");
  jQuery( ".carousel-container #glassBlockCarousel .carousel-inner .carousel-item" ).each(function( index ) {
    var imageElement = jQuery(this).find("img");
    jQuery(this).html(imageElement);
    //var imagePathOld = jQuery( this).find("img").attr("src");
    //var imagePath = imagePathOld.replace("/styles/350x350/public", "");
    //var hrefImageElement = "<a href='" + imagePath + "' target=_blank>" + imageElement.prop('outerHTML') + "</a>";
    //jQuery(this).html(hrefImageElement);
  });
}
}
jQuery(window).resize(onresize );
*/

jQuery(document).ready(function() {
	
if (jQuery(window).width() <= 767) {
  jQuery('.carousel-container #glassBlockCarousel .carousel-inner .carousel-item img').removeClass("cboxElement");
  jQuery( ".carousel-container #glassBlockCarousel .carousel-inner .carousel-item" ).each(function( index ) {
    var imageElement = jQuery(this).find("img");
    var imagePathOld = jQuery( this).find("img").attr("src");
    var imagePath = imagePathOld.replace("/styles/350x350/public", "");
    var hrefImageElement = "<a href='" + imagePath + "' target=_blank>" + imageElement.prop('outerHTML') + "</a>";
    jQuery(this).html(hrefImageElement);
  });

}
else {
  // Load colobox
}

	jQuery('#glassBlockCarousel > div > div.carousel-item > img').each(function() {
			var url = jQuery(this).attr('src');
			var url = url.replace("styles/350x350/public/", "");

			console.log(url);
			
			jQuery(this).colorbox({
			  rel: 'images',
			  transition: "fade",
			  maxHeight: "900px",
			  maxWidth: "1200px",
			  opacity: 5,
			  href: url,
			  previous: "<img src='/sites/default/files/styles/thumbnail/public/2020-11/arrow-left1.png'>",
			  next: "<img src='/sites/default/files/styles/thumbnail/public/2020-11/arrow-right1_0.png'>",
			  'onComplete': function(){        
				jQuery('#cboxLoadedContent img').parent().zoom({ on:'grab' });
			}
		});
	});

});


