import '../css/shieldai.css';

// console.log('Shield AI JS loaded!');

// Load Typekit Fonts
try{Typekit.load();}catch(e){}

// initialize animation library
AOS.init();


(function ($) {

  function ieVersion() {
    var body = document.querySelector('body');
    var ua = window.navigator.userAgent;

    if (ua.indexOf("Trident/7.0") > -1) {
      body.classList.add('ie-11');
    } else if (ua.indexOf("Trident/6.0") > -1) {
      body.classList.add('ie-10');
    } else if (ua.indexOf("Trident/5.0") > -1) {
      body.classList.add('ie-9');
    } else {
      // not IE
    }
  }

  jQuery(document).ready( function () {

    // detect IE version
    ieVersion();

    var siteForm = jQuery('.views-exposed-form');
    // var siteForm = jQuery('.search-block-form');


    function toggleHeaderSearch(el) {
      var parent = jQuery(el).parent();
      var siteHeader = jQuery('.site-header .tw-container');
      var siteheaderWidth = siteHeader.width();

      if (parent.hasClass('is-active')) {
        // console.log('Open');
        parent.addClass('is-animating');
        setTimeout( function () {
          parent.removeClass('is-active');
          parent.removeClass('is-animating');
          siteForm.width('auto');
        }, 500);

      } else {
        //console.log('Closed');
        parent.addClass('is-active');

        siteForm.width(siteheaderWidth / 1.5);
      }
    }

    function subMenuSlideUp() {
      jQuery('.site-header--sub-menu').slideUp();
      jQuery('.site-header--menu-link').removeClass('is-active');
    }

    function subMenuSlideDown() {
      jQuery('.site-header--sub-menu').slideUp().removeClass('is-active');
    }


    jQuery('.site-header--menu-link > a').each( function(i) {

      if (jQuery(this).next('ul').length == 1) {

        var href = jQuery(this)[0].href;

        if (~href.indexOf("/node/226")) {
          // console.log('content found');
          // look for if content is in URL

        } else {

          var cloned_el = jQuery(this).clone();
          var submenu_container = jQuery(this).next('.site-header--sub-menu');

          cloned_el.prependTo(submenu_container);

          jQuery('.site-header--sub-menu > a').wrap('<li class="site-header--sub-menu-link site-menu--sub-menu-mobile-link"></li>');

          if (~href.indexOf("/company")) {
            jQuery('.site-menu--sub-menu-mobile-link a').text('About');
          } else {
            jQuery('.site-menu--sub-menu-mobile-link a').text('Overview');
          }

        }
      }

    });



    jQuery('.site-header--menu-link > a').click( function (e) {

      if (jQuery(this).next('ul').length == 1) {
        e.preventDefault();
        // console.log('disable click');
      } else {
        // Treat as a normal link
      }

      if (jQuery(window).width() < 1200) {
        // console.log('click triggered at less than 500px');

        var el = jQuery(this),
          parent = el.parent();

        if (parent.hasClass('is-active')) {
          parent.removeClass('is-active');
          // console.log('ACTIVE');
          el.next('.site-header--sub-menu').slideUp();

        } else {
          subMenuSlideUp();

          setTimeout(function(){
            parent.addClass('is-active');
            // console.log('not active');
            el.next('.site-header--sub-menu').slideDown();
          }, 250);

        }

      }

    });


    jQuery('.site-header--sub-menu .site-header--sub-menu-link a.is-active').parents('li').parents('li').addClass('parent-active');


    jQuery('.js-toggle-search').keyup( function () {
      toggleHeaderSearch(this);
    });

    jQuery('.js-toggle-search').click( function () {
      toggleHeaderSearch(this);
    });

    // Mobile Menu
    var menuMobileToggle = jQuery('.js-site-header-menu-toggle');
    var mobileNav = jQuery('.js-site-header--nav');
    var mobileSearch = jQuery('.js-site-header--search');

    if (jQuery(window).width() < 1200) {
      mobileNav.slideUp();
      mobileSearch.slideUp();
      subMenuSlideUp();
    } else {
      mobileNav.slideDown();
      mobileSearch.slideDown();
      subMenuSlideDown();
    }

    jQuery(window).resize(function () {
      if (jQuery(window).width() < 1200) {
        mobileNav.slideUp();
        mobileSearch.slideUp();
      }
      else {
        mobileNav.slideDown();
        mobileSearch.slideDown();
      }
    });

    function toggleMainMobileMenu(el) {

      var parent = menuMobileToggle.parent().parent();

      if (parent.hasClass('is-active')) {
        mobileNav.slideUp();
        mobileSearch.slideUp();
        setTimeout(function () {
          parent.removeClass('is-active');
        }, 500);

      } else {
        mobileNav.slideDown();
        parent.addClass('is-active');
        mobileSearch.slideDown();
      }

    }

    menuMobileToggle.keyup( function () {
      toggleMainMobileMenu(this);
    });

    menuMobileToggle.click( function () {
      toggleMainMobileMenu(this);
    });

    // Carousel
    jQuery('.js-carousel-blog-cards-1-up').slick({
      slidesPerRow: 1,
      slidesToScroll: 1,
      swipeToSlide: true,
      infinite: false,
      responsive: [
        {
          breakpoint: 960,
          settings: {
            arrows: true,
            // centerMode: true,
            // centerPadding: '40px',
            slidesPerRow: 1,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 680,
          settings: {
            arrows: false,
            // centerMode: true,
            // centerPadding: '40px',
            slidesPerRow: 1,
            slidesToScroll: 1,
          }
        }
      ]
    });

    jQuery('.js-carousel-blog-cards-2-up').slick({
      slidesPerRow: 2,
      slidesToScroll: 2,
      swipeToSlide: true,
      infinite: false,
      responsive: [
        {
          breakpoint: 960,
          settings: {
            arrows: true,
            // centerMode: true,
            // centerPadding: '40px',
            slidesPerRow: 1,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 680,
          settings: {
            arrows: false,
            // centerMode: true,
            // centerPadding: '40px',
            slidesPerRow: 1,
            slidesToScroll: 1,
          }
        }
      ]
    });

    jQuery('.js-carousel-blog-cards-3-up').slick({
      slidesPerRow: 3,
      slidesToScroll: 3,
      swipeToSlide: true,
      infinite: false,
      responsive: [
        {
          breakpoint: 1440,
          settings: {
            arrows: true,
            // centerMode: true,
            // centerPadding: '40px',
            slidesPerRow: 2,
            slidesToScroll: 2,
          }
        },
        {
          breakpoint: 960,
          settings: {
            arrows: true,
            // centerMode: true,
            // centerPadding: '40px',
            slidesPerRow: 1,
            slidesToScroll: 1,
          },
        },
        {
          breakpoint: 680,
          settings: {
            arrows: false,
            // centerMode: true,
            // centerPadding: '40px',
            slidesPerRow: 1,
            slidesToScroll: 1,
          }
        }
      ]
    });

    jQuery('.js-carousel-news-cards-2-up').slick({
      slidesPerRow: 2,
      slidesToScroll: 2,
      swipeToSlide: true,
      infinite: false,
      responsive: [
        {
          breakpoint: 960,
          settings: {
            arrows: true,
            // centerMode: true,
            // centerPadding: '40px',
            slidesPerRow: 1,
            slidesToScroll: 1,
          }
        },
        {
          breakpoint: 680,
          settings: {
            arrows: false,
            // centerMode: true,
            // centerPadding: '40px',
            slidesPerRow: 1,
            slidesToScroll: 1,
          }
        }
      ]
    });

    function changeNova() {
      jQuery(".paragraph-banner").each(function() {
        var temp = jQuery(this).find('.block--background');
        if (jQuery(window).width() < 1024) {
          var link = temp.attr('data-mobile');
        }
        else {
          var link = temp.attr('data-desktop');
        }
        temp.children().children().css('background-image','url(' + link + ')');
        temp.find('source').attr('src',link);
        temp.find('img').attr('src', link);
      });
      if(jQuery(".block--background video").length > 0) {
        jQuery(".block--background video")[0].load();
      }
    }

    changeNova();

    function novaGif() {
      if (jQuery(window).width() < 1024) {
        jQuery('.hover-image-container').prepend(jQuery('<img>',{id:'mobileHoverImg',src:'https://shield.ai/sites/default/files/2021-03/nova_rotator.gif'}));
      }
    }

    novaGif();



    function toggleFilters() {
      if (window.innerWidth <= 1279) {
        jQuery(".page-filters--container").slideUp('slow');
      }

      if (window.innerWidth >= 1280) {
        jQuery(".page-filters--container").slideDown('slow');
      }
    }

    toggleFilters();

    // Page Filters
    window.onresize = function () {
      toggleFilters();
    }

    // jQuery('.js-page-filters--mobile-show').click( function () {
    //   jQuery('.page-filters--container').slideToggle();
    //   console.log('clicked filter');
    // });


  });




  // Fix Widows in Headlines
  // jQuery(".text-widow").each( function () {
  //   var wordArray = jQuery(this).text().split(" ");
  //   if (wordArray.length > 1) {
  //     wordArray[wordArray.length - 2] += "&nbsp;" + wordArray[wordArray.length - 1];
  //     wordArray.pop();
  //     jQuery(this).html(wordArray.join(" "));
  //   }
  // });

  if (typeof Drupal !== "undefined") {
    Drupal.behaviors.betterExposedFilters = {
      attach: function(context) {
        jQuery('.js-page-filters--mobile-show').click( function () {
          jQuery('.page-filters--container').slideToggle();
        });
      }}
  }

})(jQuery);
