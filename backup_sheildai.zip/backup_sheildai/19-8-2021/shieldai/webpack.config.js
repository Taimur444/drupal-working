/**
 * @file
 */

// let mix = require('laravel-mix');

// mix.postCss('src/shieldai.css', 'dist', [
//   require('precss')(),
//   require('tailwindcss')('./tailwindcss.config.js'),
// ]);

// mix.postCss('src/shieldai.css', 'dist', [
//   require('tailwindcss')('./tailwindcss.config.js'),
// ])

// mix.js('src/shieldai.js', 'dist')


// Webpack uses this to work with directories
const path = require('path');
const glob = require('glob')

// Webpack plugins
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const OptimizeCSSAssetsPlugin = require("optimize-css-assets-webpack-plugin");
const UglifyJsPlugin = require('uglifyjs-webpack-plugin');
const WatchExternalFilesPlugin = require('webpack-watch-files-plugin').default;
const tailwindcss = require('tailwindcss');

// Static Paths
const bundleName = 'shieldai';
const entryFile = './src/js/shieldai.js';

var config = {
  entry: entryFile,

  output: {
    path: path.resolve(__dirname, 'dist'),
  },

  optimization: {
    minimize: true
  },

  performance: {
    maxAssetSize: 1000000,
    maxEntrypointSize: 1000000,
    hints: "warning"
  },

  // https://webpack.js.org/concepts/modules/
  module: {
    rules: [
      {
        // Apply rule for .js
        test: /\.js$/,
        exclude: /(node_modules)/,
        // Set loaders to transform files.
        use: {
          loader: 'babel-loader',
          options: {
            presets: ['@babel/preset-env']
          }
        }
      },
      {
        // Apply rule for .css files
        test: /\.css$/,
        // Set loaders to transform files.
        use: [
          {
            loader: MiniCssExtractPlugin.loader
          },    
          {
            loader: "css-loader",
          },
          { 
            loader: 'postcss-loader',
            options: {
              ident: 'postcss',
              plugins: [
                require('postcss-import'),
                tailwindcss('./tailwindcss.config.js'),
                require('tailwindcss'),
                require('postcss-nested'),
                // require('autoprefixer'),
                require('autoprefixer')({ grid: true}),
              ],
            }, 
          }
        ]
      },
      {
        // Apply rule for images
        test: /\.(png|jpe?g|gif|svg)$/,
        // Set loaders to transform files.
        use: [
          {
            loader: "file-loader",
            options: {
              outputPath: 'images'
            }
          },
          {
            loader: 'image-webpack-loader',
            options: {
              mozjpeg: {
                progressive: true,
                quality: 65
              },
              // optipng.enabled: false will disable optipng
              optipng: {
                enabled: false,
              },
              pngquant: {
                quality: '65-90',
                speed: 4
              },
              gifsicle: {
                interlaced: false,
              },
              // the webp option will enable WEBP
              webp: {
                quality: 75
              }
            }
          }
        ]
      }
    ]
  },

  // https://webpack.js.org/concepts/plugins/
  plugins: [
    new CleanWebpackPlugin(),
  ]
};


module.exports = (env, argv) => {

  if (argv.mode === 'development') {
    // Development Config
    config.devtool = 'source-map';
    config.output.filename = './'+bundleName+'.bundle.js';
    config.watch = true;

    // Development Plugins
    config.plugins = [
      new MiniCssExtractPlugin({ filename: bundleName+'.bundle.css' }),
    ];
  }

  if (argv.mode === 'production') {
    // Production Config
    config.output.filename = './'+bundleName+'.bundle.min.js';
    config.optimization.minimize = true;
    // config.mode = 'production';

    // Production Plugins
    config.plugins = [ 
      new OptimizeCSSAssetsPlugin({}),
      new MiniCssExtractPlugin({ filename: bundleName+'.bundle.min.css' }),
    ];
  }

  return config;

};
