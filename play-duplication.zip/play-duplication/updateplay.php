<?php


use Drupal\Core\DrupalKernel;
use Symfony\Component\HttpFoundation\Request;
$autoloader = require_once 'autoload.php';

$kernel = new DrupalKernel('prod', $autoloader);
$request = Request::createFromGlobals();
$response = $kernel->handle($request);

use \Drupal\node\Entity\Node;



$bookid = '';
$title = '';
$duration = '';
$theater = '';
$layout = '';
$pdf = '';
$last_updated_date = '';
$unique_id = '';
$play_type = '';

$bookid = '8';
if(isset($_POST['bookid']))
	$bookid = $_POST['bookid'];


if(isset($_POST['title']))
	$title = $_POST['title'];
if(isset($_POST['userid']))
	$userid = $_POST['userid'];
if(isset($_POST['duration']))
	$duration = $_POST['duration'];
if(isset($_POST['theater']))
	$theater = $_POST['theater'];
if(isset($_POST['layout']))	
	$layout = $_POST['layout'];
if(isset($_POST['play_type']))	
	$play_type = $_POST['play_type'];
	
if(isset($_POST['pdf']))	
	$pdf = $_POST['pdf'];

if(isset($_POST['uuid']))	
	$uuid = $_POST['uuid'];

if(isset($_POST['last_updated_date']))	
	$last_updated_date = $_POST['last_updated_date'];	

if(isset($_POST['unique_id']))	
	$unique_id = $_POST['unique_id'];
   echo $unique_id;




if($title == '' && $duration == '' && $theater == '' && $layout == '')
{
	return;
}


$target_dir = "sites/default/files/thumbnails";
if(!file_exists($target_dir))
{
	mkdir($target_dir, 0777, true);
}
 
$filename = date("Ymd").$unique_id.basename($_FILES["file"]["name"]);
$target_dir = $target_dir . "/" . $filename;
move_uploaded_file($_FILES["file"]["tmp_name"], $target_dir);



/////THESE ARE VARIABLES AVAILABLE//////

////$title = Play Title, $duration = date, $userid = user id, $theater = theaterid, $pdf = pdf file name, $filename = image name, image folder = /thumbnails 

////$duration VARIABLE HAS DATE INTO THIS FORMAT "fromdate-todate"

///WRITE THE CODE TO CREATE NODE ////




if(isset($title) && isset($theater) && isset($userid) && isset($bookid)){
if(is_numeric($theater) && is_numeric($userid)){

$node2 = Node::load($bookid);

$data = file_get_contents('http://cuetocueapp.figover.com/sites/default/files/thumbnails/'.$filename);
$file = file_save_data($data, 'public://'.$filename, FILE_EXISTS_RENAME);
$node2->field_image->target_id = $file->id();
$node2->set("field_default_image_play",$filename);
$node2->set("field_play_layout",$layout);
$node2->setTitle($title);
$node2->set("field_last_updated_date",$last_updated_date);
$node2->set("field_play_duration",$duration);
$node2->set("field_unique_id",$unique_id);
$node2->set("field_play_type",$play_type);
//$node2->set("field_default_pdf_play",$filename);

$node2->save();



echo json_encode(array("bookid"=>$bookid));
}
}


////SAVE CREATED NODE ID INTO THIS VARIABLE $cuebook_nid

/////CODE WILL END HERE ///////

//echo json_encode(array("bookid"=>$bookid));

?>
