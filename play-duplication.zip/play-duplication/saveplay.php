<?php
use Drupal\Core\DrupalKernel;
use Symfony\Component\HttpFoundation\Request;
$autoloader = require_once 'autoload.php';

$kernel = new DrupalKernel('prod', $autoloader);
$request = Request::createFromGlobals();
$response = $kernel->handle($request);

use \Drupal\node\Entity\Node;



$title = '';
$duration = '';
$theater = '';
$layout = '';
$pdf = '';
$play_type = '';

if(isset($_POST['title']))
	$title = $_POST['title'];
if(isset($_POST['userid']))
	$userid = $_POST['userid'];
if(isset($_POST['duration']))
	$duration = $_POST['duration'];
if(isset($_POST['theater']))
	$theater = $_POST['theater'];
if(isset($_POST['layout']))	
	$layout = $_POST['layout'];
if(isset($_POST['play_type']))	
	$play_type = $_POST['play_type'];
	
if(isset($_POST['pdf']))	
	$pdf = $_POST['pdf'];

if(isset($_POST['uuid']))	
	$uuid = $_POST['uuid'];

if(isset($_POST['last_updated_date']))	
	$last_updated_date = $_POST['last_updated_date'];	

if(isset($_POST['unique_id']))	
	$unique_id = $_POST['unique_id'];
	

if($title == '' && $duration == '' && $theater == '' && $layout == '')
{
	return;
}

$target_dir = "sites/default/files/thumbnails";
if(!file_exists($target_dir))
{
	mkdir($target_dir, 0777, true);
}

//$filename = date("Ymdhis").basename($_FILES["file"]["name"]);
$filename = date("Ymd").$unique_id.basename($_FILES["file"]["name"]);
$target_dir = $target_dir . "/" . $filename;
move_uploaded_file($_FILES["file"]["tmp_name"], $target_dir);



/////THESE ARE VARIABLES AVAILABLE//////

////$title = Play Title, $duration = date, $userid = user id, $theater = theaterid, $pdf = pdf file name, $filename = image name, image folder = /thumbnails 

////$duration VARIABLE HAS DATE INTO THIS FORMAT "fromdate-todate"

///WRITE THE CODE TO CREATE NODE ////

if(isset($title) && isset($theater) && isset($userid)){

if(is_numeric($theater) && is_numeric($userid)){
	$connection_text = \Drupal::database();     
            $cue_nodes = $connection_text->query("SELECT node_field_data.langcode AS node_field_data_langcode, node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
    FROM
    {node_field_data} node_field_data
    LEFT JOIN {node__field_unique_id} node__field_unique_id ON node_field_data.nid = node__field_unique_id.entity_id AND node__field_unique_id.deleted = '0'
    WHERE (node_field_data.type IN ('play')) AND (node__field_unique_id.field_unique_id_value LIKE '" . $unique_id . "')
    ORDER BY node_field_data_created DESC");
            $cue_flag ="false";
            $cue_node_id = "";
            
        foreach($cue_nodes as $nid_cue){
            	//print_r($nid_cue);
            	//echo $nid_cue->nid;
              $cue_node_id = $nid_cue->nid;
              //echo $cue_node_id;
               $cue_flag ="true";
            }
        if ($cue_flag =="true") {
            	  echo json_encode(array("bookid"=>$cue_node_id));
            }
            else{
            	 $data = file_get_contents('http://cuetocueapp.figover.com/sites/default/files/thumbnails/'.$filename);
                  $file = file_save_data($data, 'public://'.$filename, FILE_EXISTS_RENAME);
                 $node1 = Node::create([
                'type'        => 'play',
                'title'       => $title,
				'uid'         => $userid,
				'field_default_image_play' => array('value' => $filename),
				'field_play_layout' => array('value' => $layout),
				'field_play_duration' => array('value' => $duration),
				'field_last_updated_date' => array('value' => $last_updated_date),
				'field_unique_id' => array('value' => $unique_id),
                                'field_play_type' => array('value' => $play_type),
				'field_image' => [
                'target_id' => $file->id(),
                ],
              ]);
            $node1->save();	
            $cuebook_nid = $node1->id();
            $node_data = \Drupal\node\Entity\Node::load($node1->id());
            $group = \Drupal\group\Entity\Group::load($theater);
            $group->addContent($node_data, 'group_node:play');
            $group->save();	

            echo json_encode(array("bookid"=>$cuebook_nid));


            }
             
}
}


////SAVE CREATED NODE ID INTO THIS VARIABLE $cuebook_nid

/////CODE WILL END HERE ///////



?>
