<?php
/**
*@file
*Contains \Drupal\rsvplist\Form\RSVPForm
*/

namespace Drupal\rsvplist\Form;

use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
/**
*provides an email for resvp listRSVPForm
*/

class RSVPForm extends FormBase{
    /**
    *(@inheritdoc)
    */
	public function getFormId() {
		return 'rsvplist_email_form';
	}
    public function BuildForm(array $form, FormStateInterface $form_state)
    {
    	$node = \Drupal::routeMatch()->getParameter('node');
    	$nid = $node->nid->value;
    	$form['email'] = array(
    		'#title' => t('Email Address'),
    		'#type' => 'textfield',
    		'#size' => 25,
    		'#description' => t("We will send updates to Email Address"),

    	);

    	$form['submit'] =  array(
            '#type' => 'submit' ,
            '#value' => t('RSVP'),
             );

    	$form['nid'] =  array(
            '#type' => 'hidden' ,
            '#value' => $nid, 
        );
    	return $form;
    }
      /**
    *(@inheritdoc)
    */
    public function SubmitForm(array &$form, FormStateInterface $form_state){
        $user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
       /* db_insert('rsvplist')
        ->fields(array(
       'mail' => $form_state->getValue('email'),
       'nid' => $form_state->getValue('nid'),
       'uid' => $user->id(),
       'created' => time(),
    ))
    ->execute();*/
    drupal_set_message(t('Thankyou for rsvp.'));
    }
}

?>