<?php

namespace Drupal\kiosk_pin_code\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Database\Database;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Ajax\AjaxResponse;
use Drupal\Core\Ajax\HtmlCommand;
use Drupal\Core\Controller\ControllerBase;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
/**
 * Show textfields based on AJAX-enabled checkbox clicks.
 *
 * @ingroup ajax_example
 */
class pincodeForm extends FormBase {

  /**
   * {@inheritdoc}
   */
  public function getFormId() {
    return 'pincode_form';
  }

  /**
   * {@inheritdoc}
   *
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['message'] = [
      '#type' => 'markup',
      '#markup' => '<div class="result_message"></div>',
    ];
    $form['pincode'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Pin-Code'),
    
    ];
    $form['time'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Time'),
    
    ];
 /* $form['pincode2'] = [
      '#type' => 'textfield',
      '#title' => $this->t('pincode2'),
      
    ];*/

    $form['actions'] = [
      '#type' => 'submit',
      '#value' => $this->t('check'),
      '#ajax' => [
        'callback' => '::setMessage',
        
      ],
    ];

    return $form;
  }

  


  /**
   * {@inheritdoc}
   */
  public function setMessage(array &$form, FormStateInterface $form_state) {
    $responce = new AjaxResponse();
    /*$responce -> addCommand (
      new HtmlCommand(
        '.result_message',
       /* '<div class="my_top_message">'.$this->t('the result is @result',['@result' =>($form_state->getValue('pincode') + $form_state->getValue('pincode2'))])
      )
    );*/
    return $responce;
  }

  /**
   * {@inheritdoc}
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
   //  $pincode_form_value = $form_state->getValue('pincode');
   //  $node_id = substr($pincode_form_value,8); 
   // // $pincode_without_node_id   =  substr($pincode_form_value,0,-2);
   //  drupal_set_message($pincode_form_value.  $node_id);
   //  $nid = $node_id; 
   //  $node_storage = \Drupal::entityTypeManager()->getStorage('node');
   //  $node1 = $node_storage->load($nid);
   //  $pincode_field = $node1->get('field_new_code')->value;
   //  $compnay_name = $node1->get('field_comp')->value;
   //  drupal_set_message($pincode_field. "---------------" . $compnay_name    );
   //  $imageUrl = $node1->get('field_image')->entity->uri->value;
   //  $img_path = substr($imageUrl,8);
   //  $new_path = "/drupal-8.9.2/drupal-8.9.2/sites/default/files".$img_path;
   //  drupal_set_message($new_path);
   //  //$logo = $node1->get('field_company_name')->entity->uri->value;
   //  drupal_set_message($new_path . "---------------" . $logo);
   //  if ($pincode_form_value == $pincode_field){
   //    drupal_set_message('Pincode Accepted');
   //  }
   //  else{
   //    drupal_set_message('Wrong Pin Code');
   //   //$form_value = $form_state->getValue('pincode')
   //  }
   
   /* $query = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
    FROM
    {node_field_data} node_field_data
    WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('room')LIMIT 11 OFFSET 0");
     foreach ($query as $value) {
    drupal_set_message($value);
 }
 

    $time_form_value = $form_state->getValue('time');
      $nids = \Drupal::entityQuery('node')->condition('type','room')->execute();
      $nodes =  \Drupal\node\Entity\Node::loadMultiple($nids);
      
      
     drupal_set_message(serialize($nodes)."---------------".$time_form_value."---------------".$time_database);*/


     /*$query = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
    FROM
    {node_field_data} node_field_data
    WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('room')LIMIT 11 OFFSET 0");
     if(isset($query)){
      drupal_set_message('taimur');
     }*/

    $nids = db_query('SELECT nid FROM {node} WHERE type =  :type', array(
    ':type' => 'time',
      ))->fetchCol();
    drupal_set_message(serialize($nids)."456");
    foreach ($nids as $nid) {
      $node_storage = \Drupal::entityTypeManager()->getStorage('node');
      $node1 = $node_storage->load($nid);
     $time_interval = $node1->get('field_time')->value;
      drupal_set_message(serialize($time_interval)."hello");
    }
    
  }



        


}
