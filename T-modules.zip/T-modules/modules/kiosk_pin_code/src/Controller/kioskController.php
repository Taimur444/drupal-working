<?php
namespace Drupal\kiosk_pin_code\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\kiosk_pin_code\Form\simpleAjaxForm;


class kioskController{
  public function welcomes() {
  	$user = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
    $name = $user->get('name')->value;
    drupal_set_message($name);
    
    return array(
      '#markup' => 'Welcome to our Website kiosk_pin_code.'
    );
  }


}