<?php

namespace Drupal\hello_world\Controller;


class helloworldController{
	public function hello() {
		return array(
			'#tittle' => 'helloworld!',
			'#markup' => 'this is some content.'

		 );
	}

}

?>