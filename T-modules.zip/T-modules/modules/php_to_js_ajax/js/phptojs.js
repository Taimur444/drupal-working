/**
 * @file
 * Contains JS function
 */

(function ($, Drupal, drupalSettings) {
	alert('ello22');
  'use strict';
  Drupal.behaviors.jsDrupalupTest = {
    attach: function (context, settings) {

    	jQuery.ajax({
                type: 'GET',
                url: 'http://localhost/drupal-new/drupal-8.8.3/php-to-js-ajax',
                success: function(data){
                console.log('success',data);

                $('.js-var').once('jsDrupalupTest').append('<button class="button">' + drupalSettings.js_example.title + '</button>');
                 console.log(drupalSettings.js_example.title);
               },
            });
      
    }
  };
})(jQuery, Drupal, drupalSettings);


// jQuery(document).ready(function($) {
// 	alert('ello2');
// 	$.ajax({
//   	 type: 'GET',
//     	url: 'http://localhost/drupal-new/drupal-8.8.3/php-to-js-ajax',
//     	success: function(data){
//         	console.log('success',data);
//        	// alert(data);
//         	$.each(data, function(i,data){
//           	// $data.append('<li>company_name: '+data.field_company_name+'</li>');
//           	// $data.append('<li>time_interval: '+data.field_time_interval+'</li>');             
                        

//         	});
//       	}
//    });

// });