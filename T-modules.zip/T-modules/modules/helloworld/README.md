# Hello World!

## INTRODUCTION

"Hello World!" example in Drupal.
Drupal 8 module with a controller.

## REQUIREMENTS

The module does not have any specific requirements.

## INSTALLATION

Install as you would normally install a Drupal module.

Please download and install through Drupal admin area
or use `composer require drupal/helloworld`,
then enable the "Hello World" D8 module.

## CONFIGURATION

The Hello World module does not need any specific
configuration. After the enabling of module you will
directly see the new main menu link "Hello World" and
just click on it. That is all.
