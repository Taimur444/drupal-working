<?php
namespace Drupal\kiosk_pin_code\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\kiosk_pin_code\Form\simpleAjaxForm;


class kioskController{
  public function welcomes() {
    
    return array(
      '#markup' => 'Welcome to our Website kiosk_pin_code.'
    );
  }
public function query(){

     $query = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
    FROM
    {node_field_data} node_field_data
    WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('room')LIMIT 11 OFFSET 0");
     foreach ($query as $value) {
     	drupal_set_message("taimur11");
       if(is_numeric($value->id)){
             drupal_set_message("taimur");
       }
 }
}

}