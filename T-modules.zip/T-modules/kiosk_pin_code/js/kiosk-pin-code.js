(function ($) {
  // alert("elo");
 var image = $('.content.node--type-room .node__content .field--name-field-image .field__label .field__item img').html();
 var pincode = $('.content.node--type-room .node__content  .field--name-field-new-code .field__label .field__item').html();
 var Company_name = $('.content .node--type-room .node__content  .field--name-field-comp .field__label .field__item ').html();
  /*$( ".carousel-container #glassBlockCarousel .carousel-inner .carousel-item" ).each(function( index ) {
    $ imageElement = jQuery(this).find("img");
    $ imagePathOld = jQuery( this).find("img").attr("src");
  $ imagePath = imagePathOld.replace("/styles/350x350/public", "");
    $ hrefImageElement = "<a href='" + imagePath + "' target=_blank>" + imageElement.prop('outerHTML') + "</a>";
    $(this).html(hrefImageElement);*/
      //alert(image);
      //alert(Company_name);
      //alert(pincode);
})(jQuery) 