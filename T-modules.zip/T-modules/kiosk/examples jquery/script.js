var colorInput = document.querySelector('#color');
    var hexInput = document.querySelector('#hex');

    colorInput.addEventListener('input',() =>{
    	var color = colorInput.value;
    	hexInput.value = color;
    	document.querySelector('h1').style.color = color;
    });