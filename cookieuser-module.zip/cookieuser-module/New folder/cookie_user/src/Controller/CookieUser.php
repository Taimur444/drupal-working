<?php

namespace Drupal\rest_example\Plugin\rest\resource;

use Drupal\rest\ModifiedResourceResponse;
use Drupal\rest\Plugin\ResourceBase;
use Drupal\rest\ResourceResponse;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

use Drupal\rest\Plugin\rest\resource\EntityResource;
//use Drupal\Core\Controller\ControllerBase;
//use Drupal\Core\Database\Database;
//use setasign\Fpdi\Fpdi;
//use setasign\Fpdi\PdfReader;
/**
 * Class CustomPdfImagePageContent.
 */
class CookieUser extends EntityResource {

  /**
   * It will return html data.
   *
   * @return html
   *   Return html output.
   */
 
 
} //Class End
