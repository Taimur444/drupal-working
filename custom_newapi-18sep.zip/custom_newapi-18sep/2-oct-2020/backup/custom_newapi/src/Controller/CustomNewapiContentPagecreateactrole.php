<?php

namespace Drupal\custom_newapi\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\taxonomy\Entity\Term;
use Drupal\file\Entity\File;

/**
 * Class CustomNewapiContentPage.
 */
class CustomNewapiContentPagecreateactrole extends ControllerBase { // class start

  public function genrate( Request $request ) {  // function for json decode 
    $data2 = json_decode( $request->getContent(), TRUE ); // store value of json decode in variable
    $count = 0;
    foreach($data2 as $one_node_data1){  // foreach for json data
      $title = isset($one_node_data1['title']) ? $one_node_data1['title'] : "" ;
      $actor_ids = isset($one_node_data1['actor_ids']) ? $one_node_data1['actor_ids'] : "" ;
      $unique_id = isset($one_node_data1['unique_id']) ? $one_node_data1['unique_id'] : "" ;
      
      $nid_act_role_nid ="";
      $act_role_unique_id_not_exist = TRUE;
      $connection_act_role = \Drupal::database();  
      $nids_act_role = $connection_act_role->query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
FROM
{node_field_data} node_field_data
LEFT JOIN {node__field_unique_id} node__field_unique_id ON node_field_data.nid = node__field_unique_id.entity_id AND node__field_unique_id.deleted = '0'
WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('act_role')) AND (node__field_unique_id.field_unique_id_value LIKE '" . $unique_id . "' )");

      foreach($nids_act_role as $nid_act_role){
        if(!empty($nid_act_role->nid)){
          $act_role_unique_id_not_exist = FALSE;
          $nid_act_role_nid = $nid_act_role->nid;
        }
        else{
          $act_role_unique_id_not_exist = TRUE;
        }
      
      }

    if($act_role_unique_id_not_exist){
       $last_updated_date = isset($one_node_data1['last_updated_date']) ? $one_node_data1['last_updated_date'] : "" ;
       $role_color = isset($one_node_data1['role_color']) ? $one_node_data1['role_color'] : "" ;
       $role_symbol = isset($one_node_data1['role_symbol']) ? $one_node_data1['role_symbol'] : "" ;
       $role_play_unique_id = isset($one_node_data1['role_play_unique_id']) ? $one_node_data1['role_play_unique_id'] : "" ;
       $role_layer_unique_id = isset($one_node_data1['role_layer_unique_id']) ? $one_node_data1['role_layer_unique_id'] : "" ;
       $role_order = isset($one_node_data1['role_order']) ? $one_node_data1['role_order'] : "" ;
       $role_image = isset($one_node_data1['role_image']) ? $one_node_data1['role_image'] : "" ;
       // if 
        $node = Node::create([   // create node of content type role pages with fields title ,rolpages_page_no and  rolpages_unique_id.
          'type'        => 'act_role',
          'title'       => $title,
          'field_actor_ids'=>$actor_ids,
          'field_unique_id'=>$unique_id ,
          'field_last_updated_date'=>$last_updated_date,
          'field_role_color'=>$role_color,
          'field_role_symbol'=>$role_symbol, 
          'field_role_play_unique_id'=>$role_play_unique_id,
          'field_role_layer_unique_id'=>$role_layer_unique_id,
          'field_role_image'=>$role_image,
           'field_role_order'=>$role_order, 
        ]); 
        $node->save(); //node save
        $response['data'][$count]['nid'] =  $node->id(); // at 2 index of array tere is nid = 656
        $response['data'][$count]['unique_id'] =  $unique_id;
        } // Check role page unique id already exist if End
        else{
         $response['data'][$count]['nid'] =  $nid_act_role_nid;
         $response['data'][$count]['unique_id'] =  $unique_id;
        
        }
      $count = $count + 1;  //count +1
   } // For Each Loop ends*/
    return new JsonResponse( $response ); //return json response
  }     
  
}/// END CLASS ///
