<?php

namespace Drupal\custom_newapi\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\taxonomy\Entity\Term;
use Drupal\file\Entity\File;

/**
 * Class CustomNewapiContentPage.
 */
class CustomNewapiContentPage extends ControllerBase { // class start

  public function genrate( Request $request ) {  // function for json decode 
    $data = json_decode( $request->getContent(), TRUE ); // store value of json decode in variable
    $count = 0;
    foreach($data as $one_node_data){  // foreach for json data
        $title = isset($one_node_data['title']) ? $one_node_data['title'] : "" ; // if $one_node_data['title'] return true means there is title then store it in $title and if return false means empty the store "" to $title
    	$rolpages_page_no = isset($one_node_data['rolpages_page_no']) ? $one_node_data['rolpages_page_no'] : "" ;// if $one_node_data['rolpages_page_no'] return true means there is rolpages_page_no then store it in $rolpages_page_no and if return false means empty the store "" to $rolpages_page_no
    	$rolpages_unique_id = isset($one_node_data['rolpages_unique_id']) ? $one_node_data['rolpages_unique_id'] : "" ; // if $one_node_data['rolpages_unique_id'] return true means there is rolpages_unique_id then store it in $rolpages_unique_id and if return false means empty the store "" to $rolpages_unique_id
    	$rolpages_role_unique_id = isset($one_node_data['rolpages_role_unique_id']) ? $one_node_data['rolpages_role_unique_id'] : "" ;
        $rolpages_last_updated_date = isset($one_node_data['rolpages_last_updated_date']) ? $one_node_data['rolpages_last_updated_date'] : "" ;
       $rolpages_type = isset($one_node_data['rolpages_type']) ? $one_node_data['rolpages_type'] : "" ;
        $rolepages_x = isset($one_node_data['rolepages_x']) ? $one_node_data['rolepages_x'] : "" ;
        $rolepages_y = isset($one_node_data['rolepages_y']) ? $one_node_data['rolepages_y'] : "" ;
        $page_unique_id = isset($one_node_data['page_unique_id']) ? $one_node_data['page_unique_id'] : "" ;
    	$node = Node::create([   // create node of content type role pages with fields title ,rolpages_page_no and  rolpages_unique_id.
          'type'        => 'role_pages',
          'title'       => $title,
          'field_rolpages_page_no'=>$rolpages_page_no,
          'field_rolpages_unique_id'=>$rolpages_unique_id,
          'field_rolpages_role_unique_id'=>$rolpages_role_unique_id,
          'field_rolpages_last_updated_date'=>$rolpages_last_updated_date,
          'field_rolpages_type'=>$rolpages_type,
          'field_rolepages_x'=>$rolepages_x,
          'field_rolepages_y'=>$rolepages_y,
          'field_page_unique_id'=>$page_unique_id,
	]); 

	$node->save(); //node save
	  $response['data'][$count]['nid'] =  '656'; // at 2 index of array tere is nid = 656
    $response['data'][$count]['rolpages_unique_id'] =  "tyty-4323sdEWw-324ds"; // at 2 index of array there is rolpages_unique_id = "sdfERT-4323sdEWw-324ds"
   /* $response['data'][$count]['field_rolpages_role_unique_id'] =  "uuuuuu-rrrr-rrr";
    $response['data'][$count]['field_rolpages_last_updated_date'] =  "iiiiii-432fgsdfgWw-324ds";
    $response['data'][$count]['rolpages_type'] =  "speaking";
    $response['data'][$count]['rolepages_x'] =  "11.25aa";
    $response['data'][$count]['rolepages_y'] =  "31.2aa";
    $response['data'][$count]['page_unique_id'] =  "aaaaa-E360-4F70-B330-765yfhE72Baa";*/
    $count = $count + 1;  //count +1
}    

    

    
    


        return new JsonResponse( $response ); //return json response
  }     
  /**
   * It will return html data.
   *
   * @return html
   *   Return html output.
   */
  /*
  public function content() {
    /*try{
          
          //$nodeObj = Node::load($node->id());
          //$response['response'] =  'Success';
          //$response['code'] =  200;
          
        }catch(Exception $e){
          $response['response'] =  'Error';
          $response['code'] =  500;
          $response['data'] =  'Error in saving node data';
        }  


    /// CREATE Role Pages ///
    //if(($stage_layer_uniqueid <> "") && ($node_play_unique_id <> "")) {
for($counter = 1; $counter < 600; $counter++){
            drupal_set_message("hi");
      $node_role_pages = \Drupal::entityManager()->getStorage('node')->create([
        'type'=>'role_pages',
                  'field_rolpages_page_no'=>'1',
      'title'=>'Test Iqbal ' . $counter,
      ]);
      $node_role_pages->save();
   // } // END IF FOR CHECKING UNIQUE ID VALUES ///
}

    $stage_layers = "32423";
    $other_layers = "645";
              return [
        'pageview_count' => [
          '#markup' => 'Roles '.$stage_layers.' stage '.$other_layers.' Remaining ',
          '#prefix' => '<div class="pageview_count">',
          '#suffix' => '</div>',
        ],
      ];


  }/// END FUNCTION ///

  */
}/// END CLASS ///
