<?php

namespace Drupal\custom_newapi\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;

use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;

use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\taxonomy\Entity\Term;
use Drupal\file\Entity\File;

/**
 * Class CustomNewapiContentPage.
 */
class CustomNewapiContentPageaupdate extends ControllerBase { // class start

  public function genrate( Request $request ) {  // function for json decode 

        $data1 = json_decode( $request->getContent(), TRUE ); // store value of json decode in variable
        $count = 0;
        foreach($data1 as $json_node_data){  // foreach for json data

           $nid = isset($json_node_data['nid']) ? $json_node_data['nid'] : "" ; 
    	  $rolpages_page_no = isset($json_node_data['rolpages_page_no']) ? $json_node_data['rolpages_page_no'] : "" ;
    	  $rolpages_unique_id = isset($json_node_data['rolpages_unique_id']) ? $json_node_data['rolpages_unique_id'] : "" ;
    	  $rolpages_last_updated_date = isset($json_node_data['rolpages_last_updated_date']) ? $json_node_data['rolpages_last_updated_date'] : "" ;
    	  $rolepages_x = isset($json_node_data['rolepages_x']) ? $json_node_data['rolepages_x'] : "" ;
    	  $rolepages_y = isset($json_node_data['rolepages_y']) ? $json_node_data['rolepages_y'] : "" ;
    	  $rolpages_type = isset($json_node_data['rolpages_type']) ?  $json_node_data['rolpages_type'] : "" ;
    	  
    	  $rolpages_role_unique_id = isset($json_node_data['rolpages_role_unique_id']) ? $json_node_data['rolpages_role_unique_id'] : "" ;
        
          
          
          
          $page_unique_id = isset($json_node_data['page_unique_id']) ? $json_node_data['page_unique_id'] : "" ;
   
    
          $node_storage_role_pages = \Drupal::entityManager()->getStorage('node');
          $load_nodeid_role_pages = $node_storage_role_pages->load($nid);
		  // $role_pages_title = $load_node_role_pages->getTitle();//get field
         
          $load_nodeid_role_pages->set('field_rolpages_unique_id', $rolpages_unique_id);
          $load_nodeid_role_pages->set('field_rolpages_last_updated_date', $rolpages_last_updated_date);
          $load_nodeid_role_pages->set('field_rolpages_page_no', $rolpages_page_no);
          $load_nodeid_role_pages->set('field_rolepages_x',$rolepages_x);
          $load_nodeid_role_pages->set('field_rolepages_y',$rolepages_y);

          $load_nodeid_role_pages->set('field_rolpages_type',$rolpages_type);
          $load_nodeid_role_pages->set('field_page_unique_id', $page_unique_id);
		  $load_nodeid_role_pages->set('field_rolpages_role_unique_id', $rolpages_role_unique_id);
		  

          $load_nodeid_role_pages->save();

          $response['data'][$count]['nid'] =  $nid;
          $response['data'][$count]['rolpages_last_updated_date'] =$rolpages_last_updated_date;
          $response['data'][$count]['rolpages_page_no'] = $rolpages_page_no;
          $response['data'][$count]['rolepages_y'] =  $rolepages_x;
          $response['data'][$count]['rolepages_x'] =  $rolepages_y;
          $response['data'][$count]['rolepages_type'] =  $rolpages_type;
          $response['data'][$count]['page_unique_id'] =  $page_unique_id;
          $response['data'][$count]['rolpages_role_unique_id'] =  $rolpages_role_unique_id;
          $response['data'][$count]['rolpages_unique_id'] =  $rolpages_unique_id;
           $count = $count + 1;
        } //for each loop end
         
         return new JsonResponse( $response );
         
        
   } // function end


   
}/// END CLASS ///
