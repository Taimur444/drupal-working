<div class="seventy-five-per">
<div class="mydiv" style="position: absolute; z-index: -1; inset: 0px; background: rgba(0, 0, 0, 0) url(&quot;/sites/default/files/styles/large/public/2020-12/main.jpg?itok=dU9-IiJy&quot;) no-repeat scroll 0% 0% / 832px 600px; opacity: 0.3;"></div><div class="view view-front-screen-75-block view-id-front_screen_75_block view-display-id-default">
  
    
      
      <div class="view-empty">
      <div class="item-list">
  
  <ul><li><div class="views-field views-field-field-image"><div class="field-content">  <img src="/sites/default/files/styles/large/public/2020-12/main.jpg?itok=dU9-IiJy" alt="hhhh" typeof="Image" class="image-style-large" width="480" height="320"></div></div><div class="views-field views-field-field-logo"><div class="field-content">  <img src="typeof=&quot;Image&quot;" width="1600" height="900"></div></div><div class="views-field views-field-title"><span class="field-content">washingtan3</span></div><div class="views-field views-field-field-company-name"><div class="field-content">figover</div></div><div class="views-field views-field-field-time-date"><div class="field-content"></div></div><div class="views-field views-field-field-current-time-date"><div class="field-content"></div></div></li>
    
  </ul></div>
    </div>
  
          </div>
</div>