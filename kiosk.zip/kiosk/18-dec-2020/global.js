/**
 * @file
 * Global utilities.
 *
 */
 
// (function ($, Drupal) {
  
//   'use strict';

//   Drupal.behaviors.kiosk = {
//     attach: function (context, settings) {

//     }
//   };
  

jQuery(document).ready(function($) {
$(".reserved").click(function(){
  var sarmad = $(this).siblings(".parent-node-detail").html();
  $("#block-nodefieldsblock").html(sarmad);  
  });
  });


jQuery(document).ready(function($){

  $(".cross").click(function(){
       alert("wat");

});
  });
