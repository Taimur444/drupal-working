<?php
namespace Drupal\kiosk_pin_code\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\Database\Database;
use Drupal\user\Entity\User;
use Drupal\node\Entity\Node;
use Drupal\kiosk_pin_code\Form\simpleAjaxForm;


class kioskController{
  public function welcomes() {

  	
     // $test_date = date('Y-m-d h:i:s', time());
  	$test_date = date('Y-m-d G:i:s', strtotime('+5 hours'));
  	$q_time_substr = substr($test_date,-8);
    $query_min = substr($q_time_substr,3,2); //substr  for min roundoff query time
    $query_hour = substr($q_time_substr,0,2); //substr  for hour roundoff query time
    
    $q_date_substr =  substr($test_date,0,10);
    if ($query_min >= 1 && $query_min < 30 ){ $query_min = "0"."0"; }
    if($query_min >= 31 && $query_min < 60){ $query_min = 30; }
    
   // $query_time = $q_date_substr."T".$q_time_substr;
    $query_time = $q_date_substr."T".$query_hour.":".$query_min.":00"; //setting query current time
    drupal_set_message($query_time);
    
    $day_plus  = date('Y-m-d G:i:s', strtotime('+330 minutes')); //quert time for 24hours meeting
    $q_time_plus_substr = substr($day_plus,-8);
    $q_date_plus_substr =  substr($day_plus,0,10);
    $query_day_plus = $q_date_plus_substr."T".$q_time_plus_substr;
  	 
  	//, strtotime('+5 hours')
   // drupal_set_message($query_day_plus."hierer");
    $server_time = date("h:i:s a", strtotime('+5 hours'));

    $div_hour =substr($server_time,0,-9);
    $div_min = substr($server_time,3,2);
    $div_sec = substr($server_time,6,2);
    $am_pm = substr($server_time,9,2);

    if ($div_min >= 1 && $div_min < 30 ){ $div_min = "0"."0"; }
    if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
    $server_time = $div_hour.":".$div_min.":"."00".$am_pm;//.$div_sec;

    $z = strtotime("+30 minutes", strtotime($server_time));//adding 30 mins to server time 
    $incremented_time = date('h:i:sa', $z); //converting time format 

    $flag = False;
    $next_time_flag1 = False;

    $search_results = db_query("SELECT node__field_meeting_start_time.field_meeting_start_time_value AS node__field_meeting_start_time_field_meeting_start_time_valu, node_field_data.nid AS nid
	FROM
		{node_field_data} node_field_data
		LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
		WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time', '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$day_plus', '%Y-%m-%d\T%H:%i:%s')))
			ORDER BY node__field_meeting_start_time_field_meeting_start_time_valu");

    foreach($search_results as $result){ //foreach to get results
    	if(is_numeric($result->nid)){

        $node_storage = \Drupal::entityTypeManager()->getStorage('node'); //load node
        $node = $node_storage->load($result->nid);//load node by nid
        $node_time = $node->get('field_meeting_start_time')->value;//get meeting start time field 
      
        
        $node_time_substr = substr($node_time,11,8);//substring the field value as 18:00
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm; 

             $htmla = "start".$meeting_start_time ."$server".$server_time . "incre" . $incremented_time;
          if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
            $flag = True;
            if($next_time_flag1 == False){
              $meeting_end_time = $node->get('field_meeting_end_time')->value; // getting field value
              //$next_time_flag1 = True;

                $next_time_sub_str = substr($meeting_end_time,11,8);// substring value of meeting end time as04:00

                $next_time = date('h:i:sa', strtotime($next_time_sub_str));

                $div_hour =substr($next_time,0,2);
                //$div_hour = 10;
                $div_min = substr($next_time,3,2);
                //$div_min = 45;
            
                $am_pm = substr($next_time,8,2);
              
               if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
               if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++; }

               if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
               //if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

               $div_hour_length =  strlen($div_hour);
               //if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
               if($div_hour_length > 2){  $div_hour =  substr($div_hour,1);}
               $next_time = $div_hour.":".$div_min.":00".$am_pm; //.$div_sec;


                $company_img = $node->get('field_image')->entity->uri->value;
               $company_logo = $node->get('field_logo')->entity->uri->value;
               $name_a = $node->get('title')->value;
               $entity_id = $node->get('field_company_name')->first()->getValue()['target_id'];//getting entity ref from node company name id


              $entity_node_storage = \Drupal::entityTypeManager()->getStorage('node');//load node for entityref
              $entity_node = $entity_node_storage->load($entity_id);
              //$company_name_a = $entity_node->get('title')->value;
              
              if(isset($entity_node)){
               $company_name_a = $entity_node->get('title')->value;
               }

             $htmla = $htmla.'<div>'.$name_a.'</div>'.'<div>'.$company_name_a.'</div>'.'<div>'.$company_img.'</div>'.'<div>'.$company_logo.'</div>';

             $server_time = $next_time ;
             $a = strtotime("+30 minutes", strtotime($server_time));
                $incremented_time = date('h:i:sa', $a); 
            }
           }
    	  }

      if($flag == False) {  //if flag is false i.e is control dont find any meeting in current time
    
      $htmla = $htmla. '<div>'."meeting is availble untill".'</div>';//post half hour div
      $server_time = $incremented_time;
       
      $a = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $a);

      }
    }

    
     return array(
       '#markup' => $htmla,
     );
  }


}