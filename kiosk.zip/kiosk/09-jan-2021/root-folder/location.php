<?php
use Drupal\Core\DrupalKernel;
use Symfony\Component\HttpFoundation\Request;
$autoloader = require_once 'autoload.php';

$kernel = new DrupalKernel('prod', $autoloader);
$request = Request::createFromGlobals();
$response = $kernel->handle($request);

use \Drupal\node\Entity\Node;


//<---****  This query is Take From View Module  ****----> 

$company_title = "";
$company_name1 = "";
$node_time = "";
$node_time2 = "";
$pic = "";
$description = "";
$company_logo = "";
$tid = '6';
$time = '1607785462';

if(isset($_GET['tid']))
    $tid = $_GET['tid'];
if(isset($_GET['time']))
    $time = $_GET['time'];

//This line  should be uncommented after work done.
$time = substr($time, 0, -3);

$time = strtotime("+5 hours", $time);
$add_time = '1608108761';

$tt = '1607873461';
$second_time = date('r', $tt);

$ss = '1607869561';
$third_time = date('r', $ss);

$ff = '1607794881 </br>';
$fourth_time = date('r', $ff);

$standard_time = date('r', $time);
$standard_add_time = date('r', $add_time);

// convert Time into a formate that we want.

$dt = new DateTime("@$time");  
$url_time =  $dt->format('Y-m-d\TH:i:s');

// Removing seconds and milli second form time / and adding 30 minutes here.

 $start_time_min = substr($url_time,14,2);
if($start_time_min >= 0 && $start_time_min < 30){
   $start_time_min = "0"."0"; 
}
if($start_time_min >= 30 && $start_time_min < 60){
   $start_time_min = 30; 
}
$date_hour = substr($url_time,0,14);
$sec = substr($url_time,16,3);

 $sec = ":00";
$url_time = $date_hour.$start_time_min.$sec;
$ba = substr($url_time,0,11);
$aa = substr($url_time,11);

$ca = date('H:i:s', strtotime("+29 minutes", strtotime($aa)));

$test_date = date('Y-m-d G:i:s', strtotime('+10 hours'));
$q_time_substr = substr($test_date,-8);
$query_min = substr($q_time_substr,3,2); //substr  for min roundoff query time
$query_hour = substr($q_time_substr,0,2);
$q_date_substr =  substr($test_date,0,10);
$query_time = $q_date_substr."T".$query_hour.":".$query_min.":00";

// Adding 30 Minutes End here. 

$updated_thirty_min = $ba.$ca;

/*$query = db_query("SELECT node_field_data.created AS node_field_data_created, node__field_meeting_start_time.field_meeting_start_time_value AS node__field_meeting_start_time_field_meeting_start_time_valu, node_field_data.nid AS nid
FROM
{node_field_data} node_field_data
INNER JOIN {node__field_loco} node__field_loco ON node_field_data.nid = node__field_loco.entity_id AND node__field_loco.deleted = '0'
LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
WHERE ((node__field_loco.field_loco_target_id = '$tid')) AND ((node_field_data.status = '1') AND ((DATE_FORMAT((node__field_meeting_start_time.field_meeting_start_time_value + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT(('$url_time' + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT(('$updated_thirty_min' + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s')))) ORDER BY node__field_meeting_start_time_field_meeting_start_time_valu DESC"); */

$end_meetings = db_query("SELECT node__field_meeting_end_time.field_meeting_end_time_value AS node__field_meeting_end_time_field_meeting_end_time_value, node_field_data.nid AS nid
FROM
{node_field_data} node_field_data
LEFT JOIN {node__field_meeting_end_time} node__field_meeting_end_time ON node_field_data.nid = node__field_meeting_end_time.entity_id AND node__field_meeting_end_time.deleted = '0'
LEFT JOIN {node__field_loco} node__field_loco ON node_field_data.nid = node__field_loco.entity_id AND node__field_loco.deleted = '0'
WHERE ((node__field_loco.field_loco_target_id = '$tid')) AND ((node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_end_time.field_meeting_end_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$url_time', '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_time', '%Y-%m-%d\T%H:%i:%s'))))
ORDER BY node__field_meeting_end_time_field_meeting_end_time_value DESC
LIMIT 1 OFFSET 0");



//<---****Appling Foreach Loop on Query.And get the value of the query.****---->


// Taking Global Variables X,Y For Stop Extra Looping.

$x = "1";
$y = "";


$company_title = "";
foreach($end_meetings as $result)
    
{    //For each loop Start. to finding meeting .
    
    if(is_numeric($result->nid))
        
    {   // If condition start. if nid match $result then execute this. 
        
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node1 = $node_storage->load($result->nid);
        $node_time = $node1->get('field_meeting_start_time')->value; 

        $meeting_start_time = substr($node_time,11,6)."00";

        $server_time = time();
        $change =  date('r', $server_time). "</br>";
        $server_time1 = substr($change,16,9);
        $incremented_time = date(strtotime('+30 minutes', $server_time)); 

        $company_title = $node1->get('title')->value;
        $description = $node1->get('body')->value;  
        $company_logo = $node1->get('field_logo')->entity->uri->value;

        $entity_id = $node1->get('field_company_name')->first()->getValue()['target_id'];
        $entity_node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $entity_node = $entity_node_storage->load($entity_id);
        //$company_name1 = $entity_node->get('title')->value;
        if(isset($entity_node)){
               $company_name1 = $entity_node->get('title')->value;
        }

        $node_time = $node1->get('field_meeting_start_time')->value;     
        $node_time2 = $node1->get('field_meeting_end_time')->value;    
        $total_Time = $node_time.$node_time2;
        $company_image1 = substr($company_image,9);
      //$pic = "localhost/drupal8/sites/default/files/styles/thumbnail/public/".$company_image1;
        
    } // End of If condition. 
    
} // End of For each Loop.


if($company_title == ""){

    $query2 = db_query("SELECT node_field_data.created AS node_field_data_created, node__field_meeting_start_time.field_meeting_start_time_value AS node__field_meeting_start_time_field_meeting_start_time_valu, node_field_data.nid AS nid
    FROM
    {node_field_data} node_field_data
    INNER JOIN {node__field_loco} node__field_loco ON node_field_data.nid = node__field_loco.entity_id AND node__field_loco.deleted = '0'
    LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
    WHERE ((node__field_loco.field_loco_target_id = '$tid')) AND ((node_field_data.status = '1') AND ((DATE_FORMAT((node__field_meeting_start_time.field_meeting_start_time_value + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT(('$url_time' + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT(('$updated_thirty_min' + INTERVAL 72000 SECOND), '%Y-%m-%d\T%H:%i:%s')))) ORDER BY node__field_meeting_start_time.field_meeting_start_time_value"); 


    ///////////////////meeting not found start///////////////////////////////


    //echo "hello2";  

    foreach($query2 as $result2)
    {  



        //echo "hello1";  
        if(is_numeric($result2->nid))
        {   
            if($x == '1'){

                

                $node_storage2 = \Drupal::entityTypeManager()->getStorage('node');
                $node2 = $node_storage2->load($result2->nid);
                $node_time2 = $node2->get('field_meeting_start_time')->value;
                $y = $node_time2;
                //echo'Meeting Start Time Without Substring. </br>' .($y)."</br>";

                $meeting_start_time2 = substr($node_time,11,6)."00";

                $x = "2";

            } // end if x value checking
                
        } // end if query check

    } // end for each
    if($y == ""){
        $company_name1 = "This room is  not  available for today ";

    }
    else{
        $company_name1 = "This room is available <br> until " . $y;
    }


    
} // end if meeting title checking , if record not found in current meeting

//<---****php Array.  And Encode this array in Json Array.****---->
header('Content-type: application/json');
$arr = array('meeting_title'=>$company_title,'company_name'=>$company_name1,'total_time'=>$total_Time,'image'=>$pic,'description'=>$description,'company_logo'=>$company_logo);
echo json_encode($arr);
?>