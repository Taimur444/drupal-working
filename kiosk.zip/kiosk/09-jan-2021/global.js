/**
 * @file
 * Global utilities.
 *
 */
 
// (function ($, Drupal) {
  
//   'use strict';

//   Drupal.behaviors.kiosk = {
//     attach: function (context, settings) {

//     }
//   };
  

jQuery(document).ready(function($) {
    var image_bg_view = $('.views-field.views-field-field-image img').attr('src');
    $('.seventy-five-per .mydiv').css({"position": "absolute",
          "z-index": "-1",
          "top": "0",
          "bottom": "0",
          "left": "0",
          "right": "0",
          "background": "url('" + image_bg_view + "')",
          "background-repeat": "no-repeat",
          "opacity": ".3",
          "background-size":" 832px 600px",});
     var number;
     var popup = 0;
$(".reserved").click(function(){
    if(popup == 0){
   $('#pincode-text-box1').val('');
   $('#pincode-text-box2').val('');
   $('#pincode-text-box3').val('');
   $('#pincode-text-box4').val('');
    number = 1 + Math.floor(Math.random() * 999);
        
    $(this).addClass("re-no-" + number );
    $(this).siblings(".grey").addClass("gr-no-" + number );
  var sarmad = $(this).siblings(".parent-node-detail").html();
  $("#block-nodefieldsblock").html(sarmad);  
  $("#block-nodefieldsblock").css({"display": "block"});
    
}
}); 
  $(document).on('click', '.cross', function() 
    { $('#block-nodefieldsblock').hide(); 
                    
    });
    
    $(document).on('click', '.node-fields .three-elements .cancel-btn', function()
    { 
        popup = 2;
        $('.outer-box-pincode').show();
        $('#block-nodefieldsblock').hide();
    });
    
    $(document).on('click', '.end', function()
    { 
        popup = 0;
        $('.outer-box-pincode').hide();
    });
    
    //This Task Is Remaine .
// $(".all-textbox-pincode.inputs").keypress(function(){
//    if (this.value.length == this.maxLength) {
//     $(this).next(".all-textbox-pincode.inputs").focus();
//   }  
// });  
    
    var str1 = "";
    var str2 = "";
    var str3 = "";
    var str4 = "";
    var totl = "";
    var pass = "";
    $("#pincode-text-box1").keyup(function(){
         str1 = $("#pincode-text-box1").val(); 
});
   
    $("#pincode-text-box2").keyup(function(){
         str2 = $("#pincode-text-box2").val();
});
    
    $("#pincode-text-box3").keyup(function(){
         str3 = $("#pincode-text-box3").val(); 
});
    
    $("#pincode-text-box4").keyup(function(){
    str4 = $("#pincode-text-box4").val();     
    var totl = str1+str2+str3+str4;    
    var pass  =  $(".clearfix .text-formatted p").html();
    if(totl == pass){
   
    $(".outer-box-pincode").hide();
    var cancel =  $(".cancel-text-parent").html();    
    $("#block-cancelmeetingblock").html(cancel);
    $("#block-cancelmeetingblock").css({"display": "block"});
    
}
    else
    {
        alert("The Code Is Wrong Sorry");
    }
        
}); 
    
$(document).on('click', '.no', function(){
    popup = 0;
    $('#block-cancelmeetingblock').hide();
}); 
    
$(document).on('click', '.yes', function(){ 
   popup = 0;
    
$('.gr-no-'+number).show();
$('.re-no-'+number).hide();
$('#block-cancelmeetingblock').hide();
});
 
    $(document).on('click', '.x-end', function(){
        popup = 0;
       $('#block-cancelmeetingblock').hide();   
    });
    
  
    /*
    *Add Time And Date in Running Time.      
    */
    
$(document).ready(function() {
 clockUpdate();
 setInterval(clockUpdate, 1000);
})

function clockUpdate() {
 var date = new Date();
//  $('.views-field.views-field-field-current-time-date').css({'color': '#fff', 'text-shadow': '0 0 6px #ff0'});
 function addZero(x) {
   if (x < 10) {
     return x = '0' + x;
   } else {
     return x;
   }
 }

 function twelveHour(x) {
   if (x > 12) {
     return x = x - 12;
   } else if (x == 0) {
     return x = 12;
   } else {
     return x;
   }
 }

 var h = addZero(twelveHour(date.getHours()));
 var m = addZero(date.getMinutes());
 var s = addZero(date.getSeconds());
 $('.views-field.views-field-field-current-time-date.field-content.timeonly').text(h + ':' + m + ':' + s )
}
     
});
