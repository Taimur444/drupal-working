<?php

namespace Drupal\php_to_js_ajax\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\views\Views;
//use Drupal\Core\Controller\Views;
//use Drupal\Views;
/**
 * Output of our JS page.
 */
class PhptojsController extends ControllerBase {

  public function PhpPage() {

    $server_time = date("h:i:s a", strtotime('+5 hours'));//adding 5 hours in server time for pk time
    
    $div_hour =substr($server_time,0,-9);
    $div_min = substr($server_time,3,2);
    $div_sec = substr($server_time,6,2);
    $am_pm = substr($server_time,9,2);

    //drupal_set_message($server_time."before rounding".$div_hour.$div_min.$div_sec .$am_pm);
    if ($div_min >= 1 && $div_min < 30 ){ $div_min = "0"."0"; }
    if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
    $server_time = $div_hour.":".$div_min.":"."00".$am_pm;//.$div_sec;
  //  drupal_set_message($server_time);
    
    $z = strtotime("+30 minutes", strtotime($server_time));//adding 30 mins to server time 
    $incremented_time = date('h:i:sa', $z);//converting time format 
   // drupal_set_message($incremented_time);
    $div_hour =substr($server_time,0,-6);//substring te server time and get hour i.e. 11 in 11:00am
    $div_min = substr($server_time,14,2);//substring te server time and get hour i.e. 50 in 11:50am
    $flag = False; //intializing all flag variables as a False
    $flag1 = False;
    $flag2 = False;
    $flag3 = False;
    $flag4 = False; 
    $flag5 = False;
    $flag6 = False;
    $flag7 = False;
    $flag8 = False;
    $flag9 = False;
    $htmla = "";
    $htmlb = "";
    $htmlc = "";
    $htmld = "";
    $htmle = "";
    $htmlf = "";
    $htmlg = "";
    $htmlh = "";
    $htmli = "";
    $htmlj = "";
    $next_time_flag1 = False;
    $next_time_flag2 = False;
    $next_time_flag3 = False;
    $next_time_flag4 = False;
    $next_time_flag5 = False;
    $next_time_flag6 = False;
    $next_time_flag7 = False;
    $next_time_flag8 = False;
    $next_time_flag9 = False;  
    $next_time_flag10 = False;   
    $meeting_ids = array();       
          
 //get  all meetings of current time  +1 day 
  $search_results = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data 
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('2020-12-12T06:52:14', '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('2020-12-13T06:52:14', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
      
    foreach($search_results as $result){ //foreach to get results
      $htmla = $htmla . "3";
      if(is_numeric($result->nid)){ //get nid from $results
        $node_storage = \Drupal::entityTypeManager()->getStorage('node'); //load node
        $node = $node_storage->load($result->nid);//load node by nid
        $node_time = $node->get('field_meeting_start_time')->value;//get meeting start time field 
        
        $node_time_substr = substr($node_time,11,8);//substring the field value as 18:00
          
          $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
          drupal_set_message($meeting_start_time);
        if(($meeting_start_time >= $server_time) || ($node->get('field_meeting_end_time')->value >= $server_time)) {
          
          if(!in_array($result->nid, $meeting_ids)){
          $meeting_ids[] = $result->nid;
          $htmla = $htmla . "4";
          $flag = True;  // intialize $flag as a true
          if($next_time_flag1 == False){
            $meeting_end_time = $node->get('field_meeting_end_time')->value; // getting field value
            $next_time_flag1 = True;
            $htmla = $htmla  . " meeting_end_time " . $meeting_end_time;
            $next_time_sub_str = substr($meeting_end_time,11,8);// substring value of meeting end time as04:00
            $next_time = date('h:i:sa', strtotime($next_time_sub_str));
            drupal_set_message($next_time."old");
            $div_hour =substr($next_time,0,2);
            $div_min = substr($next_time,3,2);
            $div_sec = substr($next_time,6,2);
            $am_pm = substr($next_time,8,2);
            
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++; }

            $next_time = $div_hour.":".$div_min.":00".$am_pm; //.$div_sec;
            drupal_set_message($next_time."new");
            $htmla = $htmla  . "next_time_modified ". $next_time;

          $htmla = $htmla . "server time". $server_time;
          $div_hour =substr($server_time,0,-9);
          $div_min = substr($server_time,3,2); //substring minutes from server time i.e 00 from 01:00
          $am_pm = substr($server_time,9,2);


          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; } //set limit of minutes if its is between 1-30 then show 30 and if it is btw 30-60 then 59.
          if($div_min >= 31 && $div_min < 60){ $div_min = 30;}
          //$htmla = $htmla . "Iqbal Testing";
          $htmla = $htmla . '<div class = "reserved">'.$div_hour.":".$div_min .$am_pm."hi1".'</div>';//div to post on js side
          $htmla = $htmla . "meeting id" . $result->nid;
          drupal_set_message($htmla."new html");
          
          $server_time = $next_time ; // giving meeting end time to server time.
          $htmla = $htmla  . "server time from next time new" . $server_time;


          $htmla = $htmla  . " first row second server time " . $server_time;
          $a = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('h:i:s', $a); 

          } // Next Time Flag checking array
        
          } // End If for checking meeting ids
        }
          
      }
    }

    if($flag == False) {  //if flag is false i.e is control dont find any meeting in current time
      $div_hour =substr($server_time,0,-6); //substring hour from server time i.e 01 from 01:00
      $div_min = substr($server_time,3,2); //substring hour from server time i.e 01 from 01:00
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }//set limit of minutes if its is between 1-30 then show 30 and if it is btw 30-60 then 59.
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmla = $htmla . '<div>'.$div_hour.":".$div_min."hi2".'</div>';//post half hour div
      $server_time = $incremented_time;
      $a = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:s', $a);
    }

    //some comments for next 9 for each to show 9 meetings with half hour gap
/*----------------------------------------2nd time-------------------------------------------------*/
    // $server_time = $incremented_time; // giving 30+ min time in curent time to server
    // $a = strtotime("+30 minutes", strtotime($server_time));//add 30+ min again in server time
    // $incremented_time = date('H:i:s', $a);// converting to normal
      
       $second_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data 
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('2020-12-12T06:52:14', '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('2020-12-13T06:52:14', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    

      foreach( $second_turn as $aa){
      //print_r($aa);
        

      if(is_numeric($aa->nid)){
        
        
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node1 = $node_storage->load($aa->nid);
        $node_time = $node1->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        //drupal_set_message($server_time."servertime in 2nd slot".$incremented_time."increment time");


        
       // $htmlb = $htmlb . " meeting_start_time " . $meeting_start_time . " server_time " . $server_time . " meeting_start_time " . $meeting_start_time . " incremented_time " . $incremented_time . " next line ";
/*
 meeting_start_time 14:10:00 >= server_time 16:00:00
AND
  meeting_start_time 14:10:00 <= incremented_time 16:30:00 

 next line 

 meeting_start_time 15:00:00 >= server_time 16:00:00
AND
  meeting_start_time 15:00:00 <= incremented_time 16:30:00 

 next line tird

*/
        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
          //$htmlb = $htmlb . "AAAsecond";
          $flag1 = True;
          $meeting_end_time = $node1->get('field_meeting_end_time')->value;
          if($next_time_flag2 == False){
            $next_time_flag2 = True;
            $next_time = substr($meeting_end_time,11,8);
            $htmlb = $htmlb  . " second server time " . $server_time;
            $div_hour =substr($next_time,0,-6);
            $div_min = substr($next_time,3,2);
            $div_sec = substr($next_time,6,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++; }
            $next_time = $div_hour.":".$div_min.":".$div_sec;
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
          if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
          $htmlb = $htmlb  .'<div class = "reserved">'.$div_hour.":".$div_min ."hi3".'</div>';
          //$htmlb = $htmlb . " $next_time " . $next_time;
          $server_time = $next_time ;
          $htmlb = $htmlb . " meeting id " . $aa->nid;
          $htmlb = $htmlb  . " second row second server time " . $server_time;
          $b = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('H:i:s', $b);

          }

            
        }
          
      }
      
    }

    if($flag1 == False) {
      //$htmlb = $htmlb . " server time " . $server_time;
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmlb = $htmlb . '<div>'.$div_hour.":".$div_min."hi4".'</div>';
      $server_time = $incremented_time;
      $b = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('H:i:s', $b);
    }


/*----------------------------------------3rd time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $third_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('2020-12-12T06:52:14', '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('2020-12-13T06:52:14', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    
    foreach($third_turn as $result2){
     // $htmlc = $htmlc . "asdf";
      if(is_numeric($result2->nid)){
        
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node2 = $node_storage->load($result2->nid);
        $node_time = $node2->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        //drupal_set_message($server_time."servertime in 3rd slot".$incremented_time."increment time");
 //$htmlc = $htmlc . " meeting_start_time " . $meeting_start_time . " server_time " . $server_time . " meeting_start_time " . $meeting_start_time . " incremented_time " . $incremented_time . " next line ";
        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
          //drupal_set_message("3rd step if");
          $flag2 = True;
          $meeting_end_time = $node2->get('field_meeting_end_time')->value;
          if($next_time_flag3 == False){
            $next_time_flag3 = True;
            $next_time = substr($meeting_end_time,11,8);
            $div_hour =substr($next_time,0,-6);
            $div_min = substr($next_time,3,2);
            $div_sec = substr($next_time,6,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++; }
            $next_time = $div_hour.":".$div_min.":".$div_sec;
          
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
          if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
          $htmlc = $htmlc . '<div class = "reserved">'.$div_hour.":".$div_min."hi5".'</div>';
          $server_time = $next_time ;
          
          $c = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('H:i:s', $c);

          }
             
        }
          
      }
    }

    if($flag2 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; $div_hour++; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmlc = $htmlc . '<div>'.$div_hour.":".$div_min."hi6".'</div>';
      $server_time = $incremented_time;
      $c = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('H:i:s', $c);
    }


/*------------------------------------------------------------------------------------------------*/

/*----------------------------------------4th time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $third_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('2020-12-12T06:52:14', '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('2020-12-13T06:52:14', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
   
    foreach($third_turn as $result2){
      if(is_numeric($result2->nid)){
        
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node2 = $node_storage->load($result2->nid);
        $node_time = $node2->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        //drupal_set_message($server_time."servertime in 3rd slot".$incremented_time."increment time");
        $htmld = $htmld  . " htmld server time " . $server_time."meeting start".$meeting_start_time  ;
        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
          //drupal_set_message("3rd step if");
          $flag3 = True;
          $meeting_end_time = $node2->get('field_meeting_end_time')->value;
          if($next_time_flag4 == False){
            $next_time_flag4 = True;
            $next_time = substr($meeting_end_time,11,8);
           $div_hour =substr($next_time,0,-6);
            $div_min = substr($next_time,3,2);
            $div_sec = substr($next_time,6,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++;}
            $next_time = $div_hour.":".$div_min.":".$div_sec;
          
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
          if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
          $htmld = '<div class = "reserved">'.$div_hour.":".$div_min."hi7".'</div>';
          $server_time = $next_time ;
          
          $c = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('H:i:s', $c);
        }
             
        }
          
      }
    }

    if($flag3 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmld = '<div>'.$div_hour.":".$div_min."hi8".'</div>';
      $server_time = $incremented_time;
      $c = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('H:i:s', $c);
    }


/*------------------------------------------------------------------------------------------------*/


/*----------------------------------------5th time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $third_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('2020-12-12T06:52:14', '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('2020-12-13T06:52:14', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    
    foreach($third_turn as $result2){
      if(is_numeric($result2->nid)){
        
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node2 = $node_storage->load($result2->nid);
        $node_time = $node2->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

       // drupal_set_message($server_time."servertime in 3rd slot".$incremented_time."increment time");

        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
          drupal_set_message("3rd step if");
          $flag4 = True;
          $meeting_end_time = $node2->get('field_meeting_end_time')->value;
          if($next_time_flag5 == False){
            $next_time_flag5 = True;
            $next_time = substr($meeting_end_time,11,8);
            $div_hour =substr($next_time,0,-6);
            $div_min = substr($next_time,3,2);
            $div_sec = substr($next_time,6,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++;}
            $next_time = $div_hour.":".$div_min.":".$div_sec;
          
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
          if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
          $htmle = '<div class = "reserved">'.$div_hour.":".$div_min."hi9".'</div>';
          $server_time = $next_time ;
          
          $c = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('H:i:s', $c);

        }
             
        }
          
      }
    }

    if($flag4 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmle = '<div>'.$div_hour.":".$div_min."hi10".'</div>';
      $server_time = $incremented_time;
      $c = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('H:i:s', $c);
    }


/*------------------------------------------------------------------------------------------------*/

    $viewId = 'front_screen_75_block';
    $view = Views::getView($viewId);

    if(is_object($view)) {
      $view->setDisplay('block');
      //$view->setArguments($arguments);
      $view->execute();
      // Render the view
      $result = \Drupal::service('renderer')->render($view->render());
      // return $result;   
    }

    $build = [];
    $build['content'] = [

    '#markup' => $result . $htmla.$htmlb.$htmlc.$htmld .$htmle.$htmlf.$htmlg.$htmlh.$htmli.$htmlj,
      //'#markup' => '<div class="js-var">Our JS Page</div>',
    ];

    $build['#attached']['library'][] = 'php_to_js_ajax/js_exp_two';
    $build['#attached']['drupalSettings']['js_example']['title'] = "helo";

    return $build;
  }

}
