/**
 * @file
 * Global utilities.
 *
 */
 
// (function ($, Drupal) {
  
//   'use strict';

//   Drupal.behaviors.kiosk = {
//     attach: function (context, settings) {

//     }
//   };
  

jQuery(document).ready(function($) {
$(".reserved").click(function(){
  var sarmad = $(this).siblings(".parent-node-detail").html();
  $("#block-nodefieldsblock").html(sarmad);  
  $("#block-nodefieldsblock").css({"display": "block"});

}); 
  $(document).on('click', '.cross', function() 
    { $('#block-nodefieldsblock').hide(); 
                    
    });
    
    $(document).on('click', '.node-fields .three-elements .cancel-btn', function()
    { 
        $('.outer-box-pincode').show();
        $('#block-nodefieldsblock').hide();
    });
    
    $(document).on('click', '.end', function()
    { 
        $('.outer-box-pincode').hide();
    });
    
    
  // $(".all-textbox-pincode #pincode-boxes").keyup(function(){
       
//       alert('keyup');
//         if (this.value.length == this.maxLength) {
//      $(this).next(".all-textbox-pincode #pincode-boxes").focus();
//    }
    
//});
    
//   $("#pincode-boxes").keyup(function () {
//    if (this.value.length == this.maxLength) {
//      $(this).next("#pincode-boxes").focus();
//    }
//});
    
    
   
      
});

function checkPasswordMatch() {
    var password = $(".all-textbox-pincode #pincode-boxes").val();
    var confirmPassword = $(".views-field-field-pincode .field-content").val();

    if (password != confirmPassword)
       // $("#divCheckPasswordMatch").html("Passwords do not match!");
        alert('not match');
    else
//        $("#divCheckPasswordMatch").html("Passwords match.");
        alert('password matched');
}

$(document).ready(function () {
   $(".views-field-field-pincode .field-content").keyup(checkPasswordMatch);
});


//<------textboxes classes--------->

//.all-textbox-pincode

//<-------password class name-------->

//.views-field-field-pincode .field-content