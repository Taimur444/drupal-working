<?php
use Drupal\Core\DrupalKernel;
use Symfony\Component\HttpFoundation\Request;
$autoloader = require_once 'autoload.php';

$kernel = new DrupalKernel('prod', $autoloader);
$request = Request::createFromGlobals();
$response = $kernel->handle($request);

use \Drupal\node\Entity\Node;


//<---****  This query is Take From View Module  ****----> 

$company_title = "";
$company_name = "";
$node_time = "";
$node_time2 = "";
$pic = "";
$description = "";
$company_logo = "";
$tid = '6';
$time = '1607785462';


if(isset($_GET['tid']))
	$tid = $_GET['tid'];
if(isset($_GET['time']))
	$time = $_GET['time'];

//$time = substr($time, 0, -3);
//echo substr("1608313648329", 0, -3);
//echo $time_test . "<br>";

$time = strtotime("+5 hours", $time);


//$tid = $_GET['tid'];
//$time =$_GET['time'];
//$add_time = $_GET['add_time'];

//$time = '1607676761';

//echo'</br>';echo'</br>';echo'</br>';echo'</br>';echo'</br>';echo'</br>';echo'</br>';echo'</br>';echo'</br>';echo'</br>';echo'</br>';echo'</br>';


$add_time = '1608108761';

$tt = '1607873461';
$second_time = date('r', $tt);
//echo($second_time).'second</br>';

$ss = '1607869561';
$third_time = date('r', $ss);
//echo($third_time).' url time</br>';

$ff = '1607794881 </br>';
$fourth_time = date('r', $ff);
//echo($fourth_time);

//$now_time = '1607785462';
   // echo  date('r',$now_time);

$standard_time = date('r', $time);
$standard_add_time = date('r', $add_time);






$dt = new DateTime("@$time");  
$url_time =  $dt->format('Y-m-d\TH:i:s');

//$url_time1 =  date('h:i A', strtotime($url_time));
//echo 'This is Am and Pm Formate Time zone' . ($url_time1) .'</br>';

//echo " First URL Time query " . $url_time . "<br />";

//echo ($standard_time )."standard time<br>";
//echo ($new_dt )."formated<br>";

//$dt1 = new DateTime("@$add_time");  
//$new_dt1 = $dt1->format('Y-m-d\TH:i:s');

//echo ($new_dt)."old min ";

 $start_time_min = substr($url_time,14,2);
if($start_time_min >= 0 && $start_time_min < 30){
   $start_time_min = "0"."0"; 
}
if($start_time_min >= 30 && $start_time_min < 60){
   $start_time_min = 30; 
}
$date_hour = substr($url_time,0,14);
$sec = substr($url_time,16,3);
 
$url_time = $date_hour.$start_time_min.$sec;
$ba = substr($url_time,0,11);
$aa = substr($url_time,11);

$ca = date('H:i:s', strtotime("+30 minutes", strtotime($aa)));

//$ca1 =  date('h:i:s A', strtotime("+30 minutes", strtotime($aa)));

$updated_thirty_min = $ba.$ca;

//echo "<br />" . $url_time . " URL Time " . $updated_thirty_min . " Next Time <br /><br /> ca " . $ca;

/*
print "SELECT node_field_data.created AS node_field_data_created, node__field_meeting_start_time.field_meeting_start_time_value AS node__field_meeting_start_time_field_meeting_start_time_valu, node_field_data.nid AS nid
FROM
{node_field_data} node_field_data
INNER JOIN {node__field_loco} node__field_loco ON node_field_data.nid = node__field_loco.entity_id AND node__field_loco.deleted = '0'
LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
WHERE ((node__field_loco.field_loco_target_id = '$tid')) AND ((node_field_data.status = '1') AND ((DATE_FORMAT((node__field_meeting_start_time.field_meeting_start_time_value + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT(('$url_time' + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT(('$updated_thirty_min' + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s'))))";

echo "<br /><br /><br />";
*/
$query = db_query("SELECT node_field_data.created AS node_field_data_created, node__field_meeting_start_time.field_meeting_start_time_value AS node__field_meeting_start_time_field_meeting_start_time_valu, node_field_data.nid AS nid
FROM
{node_field_data} node_field_data
INNER JOIN {node__field_loco} node__field_loco ON node_field_data.nid = node__field_loco.entity_id AND node__field_loco.deleted = '0'
LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
WHERE ((node__field_loco.field_loco_target_id = '$tid')) AND ((node_field_data.status = '1') AND ((DATE_FORMAT((node__field_meeting_start_time.field_meeting_start_time_value + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT(('$url_time' + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT(('$updated_thirty_min' + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s'))))"); 


/*
$query = db_query("
SELECT node_field_data.created AS node_field_data_created, node__field_meeting_start_time.field_meeting_start_time_value AS node__field_meeting_start_time_field_meeting_start_time_valu, node_field_data.nid AS nid FROM {node_field_data} node_field_data INNER JOIN {node__field_loco} node__field_loco ON node_field_data.nid = node__field_loco.entity_id AND node__field_loco.deleted = '0' LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0' WHERE ((node__field_loco.field_loco_target_id = '1')) AND ((node_field_data.status = '1') AND ((DATE_FORMAT((node__field_meeting_start_time.field_meeting_start_time_value + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT(('2020-12-18T16:00:14' + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT(('2020-12-18T16:30:14 PM' + INTERVAL 3600 SECOND), '%Y-%m-%d\T%H:%i:%s'))))");
*/


//<---****Appling Foreach Loop on Query.And get the value of the query.****---->
 
$company_title = "";
foreach($query as $result)
{    
if(is_numeric($result->nid))
{        
$node_storage = \Drupal::entityTypeManager()->getStorage('node');
$node1 = $node_storage->load($result->nid);
$node_time = $node1->get('field_meeting_start_time')->value; 
        
$meeting_start_time = substr($node_time,11,6)."00";
$server_time = time();
$change =  date('r', $server_time). "</br>";
$server_time1 = substr($change,16,9);
//echo " hello ";
$incremented_time = date(strtotime('+30 minutes', $server_time)); 

//echo " <br>  node_time " . $node_time . " meeting_start_time " . $meeting_start_time . " server_time " . $server_time . " change " . $change . " server_time1 " . $server_time1 . " incremented_time " . $incremented_time . " <br> ";

/*

node_time 2020-12-18T15:05:00 
meeting_start_time 15:05:
server_time 1608289804 change Fri, 18 Dec 2020 11:10:04 +0000
server_time1 11:10:04 incremented_time 1608291604 


node_time 2020-12-18T16:05:00 
meeting_start_time 16:05:
server_time 1608289554 change Fri, 18 Dec 2020 11:05:54 +0000
server_time1 11:05:54 incremented_time 1608291354

$meeting_start_time = 


if($meeting_start_time >= $server_time1 && $meeting_start_time <= $incremented_time)
{
	*/
//echo "<h3>Yes Its Working Fine And The Query is Running.</h3> </br>";
$company_title = $node1->get('title')->value;
$description = $node1->get('body')->value;  
//$company_image = $node1->get('field_company_image')->entity->uri->value;
$company_logo = $node1->get('field_logo')->entity->uri->value;
$company_name = $node1->get('field_company_name')->value; 
$node_time = $node1->get('field_meeting_start_time')->value; 
//$location = $node1->get('field_loco')->getString(); 
$node_time2 = $node1->get('field_meeting_end_time')->value; 
$company_image1 = substr($company_image,9);
//$pic = "localhost/drupal8/sites/default/files/styles/thumbnail/public/".$company_image1;
   // echo($company_name);
/*   
}    
else
{
echo " The 'If' is Not Working ";
} 
*/

}   
}
if($company_title == ""){
	$company_title = "Meeting is available till some time";
}
//<---****php Array.  And Encode this array in Json Array.****---->
header('Content-type: application/json');
$arr = array('meeting_title'=>$company_title,'company_name'=>$company_name,'strat_time'=> $node_time,'end_time'=>$node_time2,'image'=>$pic,'description'=>$description,'company_logo'=>$company_logo);
echo json_encode($arr);
?>