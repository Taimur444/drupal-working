<?php

namespace Drupal\my_event_subscriber\EventSubscriber;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Drupal\state_machine\Event\WorkflowTransitionEvent;
use Drupal\Core\Entity\EntityTypeManager;
use \Drupal\node\Entity\Node;

/**
 * Class OrderCompleteSubscriber.
 *
 * @package Drupal\my_event_subscriber
 */
class OrderCompleteSubscriber implements EventSubscriberInterface {

  /**
   * Drupal\Core\Entity\EntityTypeManager definition.
   *
   * @var \Drupal\Core\Entity\EntityTypeManager
   */
  protected $entityTypeManager;

  /**
   * Constructor.
   */
  public function __construct(EntityTypeManager $entity_type_manager) {
    $this->entityTypeManager = $entity_type_manager;
  }

  /**
   * {@inheritdoc}
   */
  static function getSubscribedEvents() {
    $events['commerce_order.place.post_transition'] = ['orderCompleteHandler'];

    return $events;
  }

  /**
   * This method is called whenever the commerce_order.place.post_transition event is
   * dispatched.
   *
   * @param WorkflowTransitionEvent $event
   */
  public function orderCompleteHandler(WorkflowTransitionEvent $event) {
    /** @var \Drupal\commerce_order\Entity\OrderInterface $order */
    $order = $event->getEntity();

    // Order items in the cart.
    $items = $order->getItems();
    
    // Write your custom logic here.
	
	
	if(is_numeric($order->id())){
      $search_results = db_query("SELECT sid FROM {webform_submission_data} WHERE name LIKE 'order_number' AND value = ".$order->id());
      foreach($search_results as $result){
		if(isset($result->sid)){
		  $webform_submission = \Drupal\webform\Entity\WebformSubmission::load($result->sid);
          $data = $webform_submission->getData();	

            $user = \Drupal::currentUser();
			$uid = 1;
			if($user->id() == 0){
	          $language = \Drupal::languageManager()->getCurrentLanguage()->getId();
			  $user = \Drupal\user\Entity\User::create();
			//drupal_set_message('<pre>'. print_r($data, true) .'</pre>'); 
			  // Mandatory.
			  $password_new = generateRandomString(10);
			  $user->setPassword($password_new);
			  $user->enforceIsNew();
			  $user->setEmail($data['email']);
			  $user->setUsername($data['email']);
			
			  // Optional.
			  $user->set('init', $data['email']);
			  $user->set('langcode', $language);
			  $user->set('preferred_langcode', $language);
			  $user->set('preferred_admin_langcode', $language);
			  $user->set('field_first_name', $data['name']); 
			  $user->set('field_last_name', $data['last_name']); 
			  $user->activate();
			
			  // Save user account.
			  $result = $user->save();
                          $uid = $user->id();
                          $account = \Drupal\user\Entity\User::load($uid); // pass your uid
                          $account->setUsername($data['email']);
			  _user_mail_notify('register_no_approval_required', $account);
			  $config = \Drupal::config('event_module_notification.settings');
			  $email_subject = $config->get('freelance_subject');
			  $email_bio = $config->get('freelance_bio');
			  
			  $email_bio = str_replace("%subscription_price%", round($order->getTotalPrice()->getNumber(),2), $email_bio);
			  $email_bio = str_replace("%subscriber_name%", $data['name'], $email_bio);

			  $email_to = $data['email'];
			  $email_from = "Cue to Cue<test@cue-to-cue.dk>";
			  
			  // To send HTML mail, the Content-type header must be set
			  $headers  = 'MIME-Version: 1.0' . "\r\n";
			  $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
				// Create email headers
				$headers .= 'From: '.$email_from."\r\n".
					'Reply-To: '.$email_from."\r\n" .
					'X-Mailer: PHP/' . phpversion();
				mail($email_to, $email_subject, $email_bio, $headers);
			  
                          
			 // drupal_set_message("hello");
			    $webform_submission->setOwnerId($user->id());
                $webform_submission->save();
				











/////////////////////////////////////////////////////////////////////////////////////////////
    /** @var \Drupal\commerce_recurring\SubscriptionStorageInterface $subscription_storage */
    $subscription_storage = $this->entityTypeManager->getStorage('commerce_subscription');
/*  
  $subscriptions = $subscription_storage->loadMultiple();
        foreach ($subscriptions as $subscription) {
          //$subscription->getState()->applyTransitionById('cancel');
          //$subscription->save();
          drupal_set_message("hello1");
        }
*/
//$subscription = $subscription_storage->load();
      /** @var \Drupal\commerce_recurring\Entity\SubscriptionInterface[] $subscriptions */
      $query = $subscription_storage->getQuery();
      $query
        ->condition('initial_order', $order->id())
        ->condition('state', ['trial', 'active'], 'IN');
      $result = $query->execute();
      if ($result) {
        $subscriptions = $subscription_storage->loadMultiple($result);
        foreach ($subscriptions as $subscription) {
          //$subscription->getState()->applyTransitionById('cancel');
          //$subscription->save();
//$dfdf = $subscription->getCustomerId();
$subscription->setCustomerId($uid);
$subscription->save();
//drupal_set_message(serialize($dfdf));
        }
      }
//$subscription->setCustomerId("531");
//$subscription->setCustomer("532");
//$subscription->setCustomer($user);
//$subscription->save();
//drupal_set_message($dfdf);
///////////////////////////////////////////////////////////////////////////////////////


























				$order_da = \Drupal\commerce_order\Entity\Order::load($order->id());
			    $account1 = \Drupal\user\Entity\User::load($user->id());
			    $order_da->setCustomer($account1);
			    $order_da->save();
			}
			//drupal_set_message($user->id());
			//drupal_set_message($data['theatre_name']);
			//drupal_set_message(generateRandomString(5).$user->id());
			//drupal_set_message($data['theatre_adresse']['city']);
			//$application_group = \Drupal\group\Entity\Group::create(['type' => 'theater', 'uid' => $user->id(), 'label' => $data['theatre_name'], 'field_login_path' => generateRandomString(5).$user->id(), 'field_city' => $data['theatre_adresse']['city']]);
			if(is_numeric($uid)){



if(isset($data['theatre_name'])) {
			$application_group = \Drupal\group\Entity\Group::create(['type' => 'theater', 'label' => $data['theatre_name'], 'field_login_path' => generateRandomString(5).$uid, 'field_city' => $data['theatre_adresse']['city'], 'uid' => $uid]);

    //drupal_set_message('<pre>'. print_r($application_group, true) .'</pre>');  
            $application_group->save();
}
else {


			$application_group = \Drupal\group\Entity\Group::create(['type' => 'theater', 'label' => $data['name'] . ' ' . $data['last_name'] . ' Theater', 'field_login_path' => generateRandomString(5).$uid, 'uid' => $uid]);

    //drupal_set_message('<pre>'. print_r($application_group, true) .'</pre>');  
            $application_group->save();
}






			}
		}
	  }
	}
  }
}
function generateRandomString($length) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
