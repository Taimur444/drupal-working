<?php

namespace Drupal\my_event_subscriber\Controller;

use Symfony\Component\HttpFoundation\RedirectResponse;
use Drupal\Core\Url;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\HttpKernel\Event\FilterResponseEvent;
use Symfony\Component\HttpKernel\KernelEvents;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;
use Drupal\examples\Utility\DescriptionTemplateTrait;

/**
 * Controller routines for page example routes.
 */
class UpdateInterval extends ControllerBase {

//  use DescriptionTemplateTrait;

  /**
   * {@inheritdoc}
   */
  protected function getModuleName() {
    return 'my_event_subscriber';
  }

  /**
   * Constructs a simple page.
   *
   * The router _controller callback, maps the path
   * 'examples/page-example/simple' to this method.
   *
   * _controller callbacks return a renderable array for the content area of the
   * page. The theme system will later render and surround the content with the
   * appropriate blocks, navigation, and styling.
   */
  public function simple($first, $second, $third, $fourth, $fifth) {
    // Make sure you don't trust the URL to be safe! Always check for exploits.


    if (!is_numeric($first) || !is_numeric($second)) {
      // We will just show a standard "access denied" page in this case.
drupal_set_message("hi");
      throw new AccessDeniedHttpException();

    }


drupal_set_message("hi2");
    $list[] = $this->t("First number was @number.", ['@number' => $first]);
    $list[] = $this->t("Second number was @number.", ['@number' => $second]);
    $list[] = $this->t('The total was @number.', ['@number' => $first + $second]);

    $render_array['page_example_simple'] = [
      // The theme function to apply to the #items.
      '#theme' => 'item_list',
      // The list itself.
      '#items' => $list,
      '#title' => $this->t('Argument Information'),
    ];


//    $order_item = \Drupal\commerce_order\Entity\OrderItem::load($first);

//drupal_set_message(serialize($order_item));





//$redirect = new RedirectResponse(Url::fromUserInput('/checkout/' . $first . '/order_information')->toString());;
//$redirect->send();

/*
    $order = \Drupal\commerce_order\Entity\Order::load($first);
$items = $order->getItems();
drupal_set_message(serialize($items));
*/
   $productId = $second;
   $productObj = \Drupal\commerce_product\Entity\Product::load($productId);
   $product_variation_id_0index = $productObj->get('variations')->getValue()[0]['target_id'];
   $product_variation_id_1index = $productObj->get('variations')->getValue()[1]['target_id'];
   if($product_variation_id_0index == $third) {
     $product_variation_id = $product_variation_id_1index;
   }
   else {
     $product_variation_id = $product_variation_id_0index;
   }
   //$product_variation_id = $productObj->get('variations')->getValue()[1]['target_id'];

   //$storeId = $productObj->get('stores')->getValue()[0]['target_id'];
   $variationobj = \Drupal::entityTypeManager()->getStorage('commerce_product_variation')->load($product_variation_id);
   /*
   $store = \Drupal::entityTypeManager()->getStorage('commerce_store')->load($storeId);
   $cart_provider = \Drupal::service('commerce_cart.cart_provider');
   $cart = $cart_provider->getCart('default', $store);


   $cart_provider = \Drupal::service('commerce_cart.cart_provider');   
   $cart = $cart_provider->getCart('default', $store);     
   if (!$cart) {
     $cart = $cart_provider->createCart('default', $store);
   }
   $line_item_type_storage = \Drupal::entityTypeManager()->getStorage('commerce_order_item_type');



   $cart_manager = \Drupal::service('commerce_cart.cart_manager');
   
   $cart_manager->emptyCart($cart);

   $line_item = $cart_manager->addEntity($cart, $variationobj);
*/
//////////////////////////////////////////////////////////////////////
$storeId_Eur = "1";
$storeId_Int = "2"; 
$storeId_Dan = "3";
$storeEur = \Drupal::entityTypeManager()->getStorage('commerce_store')->load($storeId_Eur);
$cart_providerEur = \Drupal::service('commerce_cart.cart_provider');
$cartEur = $cart_providerEur->getCart('default', $storeEur);

$storeInt = \Drupal::entityTypeManager()->getStorage('commerce_store')->load($storeId_Int);
$cart_providerInt = \Drupal::service('commerce_cart.cart_provider');
$cartInt = $cart_providerInt->getCart('default', $storeInt);

$storeDan = \Drupal::entityTypeManager()->getStorage('commerce_store')->load($storeId_Dan);
$cart_providerDan = \Drupal::service('commerce_cart.cart_provider');
$cartDan = $cart_providerEur->getCart('default', $storeDan);
if($cartEur) {
  drupal_set_message("Euro Store");
  $cart_managerEur = \Drupal::service('commerce_cart.cart_manager');
  $cart_managerEur->emptyCart($cartEur);
  $line_item = $cart_managerEur->addEntity($cartEur, $variationobj);
}
else if($cartInt) {
  drupal_set_message("Int Store");
  $cart_managerInt = \Drupal::service('commerce_cart.cart_manager');
  $cart_managerInt->emptyCart($cartInt);
  $line_item = $cart_managerInt->addEntity($cartInt, $variationobj);
}
else if($cartDan) {
  drupal_set_message("Dan Store");
  $cart_managerDan = \Drupal::service('commerce_cart.cart_manager');
  $cart_managerDan->emptyCart($cartDan);
  $line_item = $cart_managerDan->addEntity($cartDan, $variationobj);
}
/*
   if ($cart) {
     $order_data = \Drupal\commerce_order\Entity\Order::load($cart->id());
   $order_data->delete();
   drupal_flush_all_caches();
   }
*/
///////////////////////////////////////////////////////////////////////

$root = "";

/*
if($fifth == "yes") {
$redirect = new RedirectResponse(Url::fromUserInput('/checkout/' . $first . '/order_information')->toString());
$redirect->send();



}

*/

if($fifth == "no") {
if($fourth == "da")
  $root = "/da";
if($fourth == "en")
  $root = "/en";
$redirect = new RedirectResponse(Url::fromUserInput($root . '/checkout/' . $first . '/order_information')->toString());
$redirect->send();
}
else {
$redirect = new RedirectResponse(Url::fromUserInput('/checkout/' . $first . '/order_information')->toString());
$redirect->send();
}


//$redirect = new RedirectResponse(Url::fromUserInput('/da/checkout/' . $first . '/order_information')->toString());
//$redirect->send();

    return $render_array;
  }

  /**
   * A more complex _controller callback that takes arguments.
   *
   * This callback is mapped to the path
   * 'examples/page-example/arguments/{first}/{second}'.
   *
   * The arguments in brackets are passed to this callback from the page URL.
   * The placeholder names "first" and "second" can have any value but should
   * match the callback method variable names; i.e. $first and $second.
   *
   * This function also demonstrates a more complex render array in the returned
   * values. Instead of rendering the HTML with theme('item_list'), content is
   * left un-rendered, and the theme function name is set using #theme. This
   * content will now be rendered as late as possible, giving more parts of the
   * system a chance to change it if necessary.
   *
   * Consult @link http://drupal.org/node/930760 Render Arrays documentation
   * @endlink for details.
   *
   * @param string $first
   *   A string to use, should be a number.
   * @param string $second
   *   Another string to use, should be a number.
   *
   * @throws \Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException
   *   If the parameters are invalid.
   */
  public function arguments($first, $second) {
    // Make sure you don't trust the URL to be safe! Always check for exploits.
    if (!is_numeric($first) || !is_numeric($second)) {
      // We will just show a standard "access denied" page in this case.
      throw new AccessDeniedHttpException();
    }

    $list[] = $this->t("First number was @number.", ['@number' => $first]);
    $list[] = $this->t("Second number was @number.", ['@number' => $second]);
    $list[] = $this->t('The total was @number.', ['@number' => $first + $second]);

    $render_array['page_example_arguments'] = [
      // The theme function to apply to the #items.
      '#theme' => 'item_list',
      // The list itself.
      '#items' => $list,
      '#title' => $this->t('Argument Information'),
    ];
    return $render_array;
  }

}
