<?php

namespace Drupal\php_to_js_ajax\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Output of our JS page.
 */
class PhptojsController extends ControllerBase {

  public function PhpPage() {

   $search_results = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
FROM
{node_field_data} node_field_data
LEFT JOIN {node__field_time_date} node__field_time_date ON node_field_data.nid = node__field_time_date.entity_id AND node__field_time_date.deleted = '0'
WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_time_date.field_time_date_value, '%Y-%m-%d\T%H:%i:%s') >= DATE_FORMAT('2020-12-01T12:00:00', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
  // if (isset($search_results)) {
  //   drupal_set_message('hi');
  // }
   foreach($search_results as $result){
       
         if(is_numeric($result->nid)){
          $node_storage = \Drupal::entityTypeManager()->getStorage('node');
          $node1 = $node_storage->load($result->nid);
          $title_company = $node1->get('title')->value;
          $meeting_time = $node1->get('field_time_date')->value;

             substr("2020-12-01T16:12:20",0,-9)
           
           $today = date("Y-m-d");
           drupal_set_message($today.     $meeting_time);
           
         }

      // $node_storage = \Drupal::entityTypeManager()->getStorage('node');
      // $node1 = $node_storage->load($result);
      // drupal_set_message(serialize($node1));
   }
     // ))->fetchCol();

   

    $build = [];
    $build['content'] = [
      '#markup' => '<div class="js-var">Our JS Page</div>',
    ];
    $build['#attached']['library'][] = 'php_to_js_ajax/js_exp_two';
    $build['#attached']['drupalSettings']['js_example']['title'] = $this->config('system.site')->get('name');

    return $build;
  }

}
