/**
 * @file
 * Global utilities.
 *
 */
 
// (function ($, Drupal) {
  
//   'use strict';

//   Drupal.behaviors.kiosk = {
//     attach: function (context, settings) {

//     }
//   };
  

jQuery(document).ready(function($) {
    var number;
     var popup = 0;
$(".reserved").click(function(){
    if(popup == 0){
   $('#pincode-text-box1').val('');
   $('#pincode-text-box2').val('');
   $('#pincode-text-box3').val('');
   $('#pincode-text-box4').val('');
    number = 1 + Math.floor(Math.random() * 999);
        
    $(this).addClass("re-no-" + number );
    $(this).siblings(".grey").addClass("gr-no-" + number );
  var sarmad = $(this).siblings(".parent-node-detail").html();
  $("#block-nodefieldsblock").html(sarmad);  
  $("#block-nodefieldsblock").css({"display": "block"});
    
}
}); 
  $(document).on('click', '.cross', function() 
    { $('#block-nodefieldsblock').hide(); 
                    
    });
    
    $(document).on('click', '.node-fields .three-elements .cancel-btn', function()
    { 
        popup = 2;
        $('.outer-box-pincode').show();
        $('#block-nodefieldsblock').hide();
    });
    
    $(document).on('click', '.end', function()
    { 
        popup = 0;
        $('.outer-box-pincode').hide();
    });
    
    //This Task Is Remaine .
// $(".all-textbox-pincode.inputs").keypress(function(){
//    if (this.value.length == this.maxLength) {
//     $(this).next(".all-textbox-pincode.inputs").focus();
//   }  
// });  
    
    var str1 = "";
    var str2 = "";
    var str3 = "";
    var str4 = "";
    var totl = "";
    var pass = "";
    $("#pincode-text-box1").keyup(function(){
         str1 = $("#pincode-text-box1").val(); 
});
   
    $("#pincode-text-box2").keyup(function(){
         str2 = $("#pincode-text-box2").val();
});
    
    $("#pincode-text-box3").keyup(function(){
         str3 = $("#pincode-text-box3").val(); 
});
    
    $("#pincode-text-box4").keyup(function(){
    str4 = $("#pincode-text-box4").val();     
    var totl = str1+str2+str3+str4;    
    var pass  =  $(".clearfix .text-formatted p").html();
    if(totl == pass){
   
    $(".outer-box-pincode").hide();
    var cancel =  $(".cancel-text-parent").html();    
    $("#block-cancelmeetingblock").html(cancel);
    $("#block-cancelmeetingblock").css({"display": "block"});
    
}
    else
    {
        alert("The Code Is Wrong Sorry");
    }
        
}); 
    
$(document).on('click', '.no', function(){
    popup = 0;
    $('#block-cancelmeetingblock').hide();
}); 
    
$(document).on('click', '.yes', function(){ 
   popup = 0;
    
$('.gr-no-'+number).show();
$('.re-no-'+number).hide();
$('#block-cancelmeetingblock').hide();
});
 
    $(document).on('click', '.x-end', function(){
        popup = 0;
       $('#block-cancelmeetingblock').hide();   
    });
    
 
});
