<?php

namespace Drupal\php_to_js_ajax\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\views\Views;
//use Drupal\Core\Controller\Views;
//use Drupal\Views;
/**
 * Output of our JS page.
 */
class PhptojsController extends ControllerBase {

  public function PhpPage() {

    /*$search_results = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
     FROM
     {node_field_data} node_field_data
      LEFT JOIN {node__field_time_date} node__field_time_date ON node_field_data.nid = node__field_time_date.entity_id AND node__field_time_date.deleted = '0'
      WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_time_date.field_time_date_value, '%Y-%m-%d\T%H:%i:%s') >= DATE_FORMAT('2020-12-01T12:00:00', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");*/
      $search_results = db_query("SELECT DISTINCT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
    FROM
	{node_field_data} node_field_data
	LEFT JOIN {node__field_time_date} node__field_time_date ON node_field_data.nid = node__field_time_date.entity_id AND node__field_time_date.deleted = '0'
	INNER JOIN {node__field_loco} node__field_loco ON node_field_data.nid = node__field_loco.entity_id AND node__field_loco.deleted = '0'
		WHERE ((node__field_loco.field_loco_target_id = '1')) AND ((node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_time_date.field_time_date_value, '%Y-%m-%d\T%H:%i:%s') >= DATE_FORMAT('2020-12-02T12:00:00', '%Y-%m-%d\T%H:%i:%s'))))LIMIT 11 OFFSET 0");

    //drupal_set_message(serialize($search_results));

    foreach($search_results as $result){
      //drupal_set_message(serialize($result));
      if(is_numeric($result->nid)){

          $node_storage = \Drupal::entityTypeManager()->getStorage('node');
          $node1 = $node_storage->load($result->nid);
         
          $title_company = $node1->get('title')->value;
          
         
          $company_image = $node1->get('field_image')->entity->uri->value;
          $company_logo = $node1->get('field_logo')->entity->uri->value;
          
          $location_company = $node1->get('field_loco')->value;
          $meeting_time = $node1->get('field_time_date')->value;

          //$field_output = entity_view($node1->get('field_company_name')->entity, 'default');
           //$field_output2 = entity_view($node1->get('field_loco')->entity, 'default');
          //get full $_REQUEST

          //$today = date("Y-m-d");
          $asd = "";
          $asd = $_POST['pid'];
          if( $asd == '34' ){
          $today_checking = "find";
          }
          else{
          $today_checking = serialize($_POST);
            }

          //$today_checking = date("l jS \of F Y h:i:s A") ."Fida";
          $today = date("Y-m-d");
          $system_time = time();
          $converted_sys_time = gmdate("H:i:s", $system_time);
          $endTime = date("H:i", strtotime('+5 hours', $system_time));
          drupal_set_message($endTime . "five");
          $a = strtotime("+30 minutes");
          $incremented_time = gmdate("H:i:s", $a);
        
           $node_date = substr($meeting_time,0,-9);
           $node_time = substr($meeting_time,11,8);
          $modified_node_time   =  substr($node_time,0,5);
          // $time_in_sec =strtotime($node_time);

           //$time = time();
          //drupal_set_message($system_time);

          
              $div_hour =substr($converted_sys_time,0,-6);
              drupal_set_message($converted_sys_time ."system".$div_hour);
          //drupal_set_message($modified_node_time ."node time" );
           // && $system_time == $time_in_sec
           
          if ($node_date == $today && $converted_time == $modified_node_time  ) {
             
          }
           
      }

     
    }
     $search_results2 = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
    FROM
    {node_field_data} node_field_data
   LEFT JOIN {node__field_current_time_date} node__field_current_time_date ON node_field_data.nid = node__field_current_time_date.entity_id AND node__field_current_time_date.deleted = '0'
    WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_current_time_date.field_current_time_date_value, '%Y-%m-%d\T%H:%i:%s') >= DATE_FORMAT('2020-12-05T12:12:08', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
      foreach($search_results2 as $result2){
        
        if(is_numeric($result2->nid)){
          

          $node_storage = \Drupal::entityTypeManager()->getStorage('node');
          $node1 = $node_storage->load($result2->nid);
         
          $node_time = $node1->get('field_meeting_start_time')->value;
          $meeting_start_time= substr($node_time,11,8);
          $meeting_end_time = $node1->get('field_meeting_end_time')->value;
          drupal_set_message($meeting_start_time."meeting_start_time");
          $div_min = substr($meeting_end_time,3,2);
          if ($div_min >1 && $div_min < 30 ) {

            $div_min = 30;
          }
            if($div_min > 31 && $div_min < 59 ) {

            $div_min = 00;
          }
           drupal_set_message($incremented_time ."old");

          if($meeting_start_time >= $converted_sys_time && $meeting_start_time <= $incremented_time){
             
             $html = '<div class = "scroll">'.$div_hour.":".$div_min ."hi1".'</div>';
             
          }
          else{
            $html = '<div>'.$div_hour.":".$div_min."hi2".'</div>';
          }

        $incremented_time = $converted_sys_time ;
         $c = strtotime("+30 minutes", strtotime($incremented_time));
            $incremented_time = date('h:i:s', $c);
            drupal_set_message($incremented_time. "new");

          if ($meeting_start_time >= $converted_sys_time && $meeting_start_time <= $incremented_time) {

               $html = '<div class = "scroll">'.$div_hour.":".$div_min ."hi3".'</div>';
            }
            else{
                  $html = '<div class = "scroll">'.$div_hour.":". $div_min ."hi4".'</div>';
            }

            $incremented_time = $converted_sys_time ;
           $d = strtotime("+30 minutes", strtotime($incremented_time));
            $incremented_time = date('h:i:s', $d);
            drupal_set_message($incremented_time. "new2");

            if ($meeting_start_time >= $converted_sys_time && $meeting_start_time <= $incremented_time) {

               $html = '<div class = "scroll">'.$div_hour.":".$div_min ."hi5".'</div>';
            }
            else{
                  $html = '<div class = "scroll">'.$div_hour.":". $div_min ."hi6".'</div>';
            }
        }
      }


    $viewId = 'front_screen_75_block';
    $view = Views::getView($viewId);
    if(is_object($view)) {
      $view->setDisplay('block');
      //$view->setArguments($arguments);
      $view->execute();
      // Render the view
      $result = \Drupal::service('renderer')->render($view->render());
      // return $result;   
     }
     $build = [];
    $build['content'] = [

      '#markup' => $result . $html ,
      //'#markup' => '<div class="js-var">Our JS Page</div>',
    ];
    $build['#attached']['library'][] = 'php_to_js_ajax/js_exp_two';
    $build['#attached']['drupalSettings']['js_example']['title'] = "helo";

    return $build;
  }

}
