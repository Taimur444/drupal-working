/**
 * @file
 * Contains JS function
 */

(function ($, Drupal, drupalSettings) {
	//alert('ello44');
  'use strict';
  Drupal.behaviors.jsDrupalupTest = {
    attach: function (context, settings) {
    //setInterval(function(){
        //alert("Hello");
        var $data = $('.block-page-title-block');
    	jQuery.ajax({
                type: 'GET',
                url: 'http://shoppingnew.figover.com/meeting-json/10',
                //data: {pid : '34'},
                success: function(data){http://prod2-db.cue-to-cue.dk/api/textanno/103838
                console.log('success',data);

                $('.js-var').append('<button class="button">' + drupalSettings.js_example.title + '</button>');
                 //console.log(drupalSettings.js_example.title);
                //var obj = jQuery.parseJSON(data)
                var data2 = JSON.stringify(data);
                alert( data2 );
         //         $.each(data, function(i,data){
         //   $data.append('<br>company_name: '+ data.field_company_name+'</br>');
         //   $data.append('<br>time & DATE: '+ data.field_time_date+'</br>');             
                        

         // });
               },
            });
       // },10000);
    }

  };
  var company_name = jQuery('.view-id-front_screen_75_block .views-field-field-company-name .field-content').text();
  var company_name = jQuery('.view-id-front_screen_75_block .views-field-field-time-date .field-content').text();
  //alert(company_name);
})(jQuery, Drupal, drupalSettings);


// var $data = $('.new-data');
//   $.ajax({
//    type: 'GET',
//     url: 'http://shoppingnew.figover.com/node-json',
//     success: function(data){
//         console.log('success',data);
        

//        // alert(data);
//         $.each(data, function(i,data){
//           $data.append('<li>company_name: '+data.field_company_name+'</li>');
//           $data.append('<li>time_interval: '+data.field_time_interval+'</li>');             
                        

//         });
//     }
// })