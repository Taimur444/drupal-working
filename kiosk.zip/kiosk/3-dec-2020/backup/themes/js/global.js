/**
 * @file
 * Global utilities.
 *
 */
 /*
(function ($, Drupal) {
  
  'use strict';

  Drupal.behaviors.kiosk = {
    attach: function (context, settings) {

    }
  };
  
$(document).ready(function(){
$("hello").scroll(function(){
	alert("hi");
  	/*var currentscrollposition = $(this).scrollTop();
   // $("span").text( x+= 1);
   if (currentscrollposition > midscroll ) {
   //	$("hello").hide();
   	//alert("scroll=281");
   }
    $("h1").text(currentscrollposition);*/
    /*
  });

});
     
})(jQuery, Drupal);

*/
jQuery(document).ready(function($) {


/* var $data = $('.new-data');
  $.ajax({
   type: 'GET',
    url: 'http://shoppingnew.figover.com/node-json',
    success: function(data){
        console.log('success',data);
        

       // alert(data);
        $.each(data, function(i,data){
          $data.append('<li>company_name: '+data.field_company_name+'</li>');
          $data.append('<li>time_interval: '+data.field_time_interval+'</li>');             
                        

        });
    }
});*/

	// var d = new Date();
	
	 var company_name = jQuery('.block-views-blockview-for-company-block-1 .views-field-title .field-content').text();
	 	  //alert(company_name);
   $("#hello").scroll(function() {
   	  var myDiv = document.getElementById("hello");
     // window.scrollTo(500, myDiv.innerHeight);
    //scroll_new.scrollTo(0, 300);

     
});
// 	$('.hello').scroll(function(){

//     $('.hello').scrollTo(0, 300);
	

// });


});


// $(function(){
//   $.ajax({
//     url: node/500,
//     success: function(response){
//         var ajaxresult = $("<div/>").append(
//         response.replace(/<script(.|\s)*?\/script>/g, "").find('#field-want-this-field').html();
//         $someplace.append(ajaxresult);
//     }
// });
// });