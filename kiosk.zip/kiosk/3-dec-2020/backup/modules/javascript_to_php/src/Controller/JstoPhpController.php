<?php

namespace Drupal\javascript_to_php\Controller;

use Drupal\Core\Controller\ControllerBase;

/**
 * Output of our JS page.
 */
class JstoPhpController extends ControllerBase {

  public function jsPage() {

  	$nids = db_query('SELECT nid FROM {node} WHERE type =  :type', array(
    ':type' => 'time',
      ))->fetchCol();
    drupal_set_message(serialize($nids)."456");
    foreach ($nids as $nid) {
      $node_storage = \Drupal::entityTypeManager()->getStorage('node');
      $node1 = $node_storage->load($nid);
     $time_interval = $node1->get('field_time')->value;
      drupal_set_message(serialize($time_interval)."hello");
    }

    $build = [];
    $build['content'] = [
      '#markup' => '<div class="js-var">Our JS Page</div>',
    ];
    $build['#attached']['library'][] = 'javascript_to_php/js_example';
    $build['#attached']['drupalSettings']['js_example']['title'] = $this->config('system.site')->get('name');

    return $build;
  }

}
