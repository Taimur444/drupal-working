/**
 * @file
 * Contains JS function
 */

(function ($, Drupal, drupalSettings) {
	//alert('ello44');
  'use strict';
  Drupal.behaviors.jsDrupalupTest = {
    attach: function (context, settings) {
    setInterval(function(){

var d = new Date().getDay()           // Get the weekday as a number (0-6)
var y = new Date().getFullYear()      // Get the four digit year (yyyy)
var h = new Date().getHours()         // Get the hour (0-23)

var min = new Date().getMinutes()       // Get the minutes (0-59)
var m = new Date().getMonth()         // Get the month (0-11)
var start = y+ '-' +m+ '-' +d + ' ' + h+ ':' +min+ ':00';


var oldDate = new Date();
var minut = oldDate.getMinutes();
var newDate = oldDate.setMinutes(minut + 5);
//alert(oldDate)
//alert(newDate);

//var da = oldDate.getDay()           // Get the weekday as a number (0-6)
//alert("my" +da);
/*var y = newDate.getFullYear()      // Get the four digit year (yyyy)
var h = newDate.getHours()         // Get the hour (0-23)

var min = newDate.getMinutes()       // Get the minutes (0-59)
var m = newDate.getMonth()         // Get the month (0-11)

var end = y+ '-' +m+ '-' +d + ' ' + h+ ':' +min+ ':00';
*/
//alert(start);
//alert(newDate);

      function AddMinutesToDate(date, minutes) {
      return new Date(date.getTime() + minutes*60000);
      }
      function DateFormat(date){
      var days = date.getDate();
      var year = date.getFullYear();
      var month = (date.getMonth()+1);
      var hours = date.getHours();
      var minutes = date.getMinutes();
      minutes = minutes < 10 ? '0' + minutes : minutes;
      var strTime = year + '-' + month + '-' + days +' '+hours + ':' + minutes;
       return strTime;
        }
     var now = new Date();
    // alert(DateFormat(now));
     var next = AddMinutesToDate(now,60);
    // alert(DateFormat(next));




        var $data = $('.block-page-title-block');
    	jQuery.ajax({
                type: 'GET',
                url: 'http://shoppingnew.figover.com/meeting-json/1/' + DateFormat(now) + '--' +DateFormat(next),
                success: function(data){
                console.log('success',data);

                var meeting_name = data[0].title;

                var meeting_span = '<span class="field-content">' + meeting_name + '</span>';
                $(".views-field.views-field-title").html(meeting_span);
                //alert( data2 );
         //         $.each(data, function(i,data){
         //   $data.append('<br>company_name: '+ data.field_company_name+'</br>');
         //   $data.append('<br>time & DATE: '+ data.field_time_date+'</br>');             
                        

         // });
               },
            });
        },10000);
    }

  };
  var company_name = jQuery('.view-id-front_screen_75_block .views-field-field-company-name .field-content').text();
  var company_name = jQuery('.view-id-front_screen_75_block .views-field-field-time-date .field-content').text();
  //alert(company_name);
})(jQuery, Drupal, drupalSettings);


// var $data = $('.new-data');
//   $.ajax({
//    type: 'GET',
//     url: 'http://shoppingnew.figover.com/node-json',
//     success: function(data){
//         console.log('success',data);
        

//        // alert(data);
//         $.each(data, function(i,data){
//           $data.append('<li>company_name: '+data.field_company_name+'</li>');
//           $data.append('<li>time_interval: '+data.field_time_interval+'</li>');             
                        

//         });
//     }
// })