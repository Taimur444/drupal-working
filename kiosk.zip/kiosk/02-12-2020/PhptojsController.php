<?php

namespace Drupal\php_to_js_ajax\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\views\Views;
//use Drupal\Core\Controller\Views;
//use Drupal\Views;
/**
 * Output of our JS page.
 */
class PhptojsController extends ControllerBase {

  public function PhpPage() {

    $search_results = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
     FROM
     {node_field_data} node_field_data
      LEFT JOIN {node__field_time_date} node__field_time_date ON node_field_data.nid = node__field_time_date.entity_id AND node__field_time_date.deleted = '0'
      WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_time_date.field_time_date_value, '%Y-%m-%d\T%H:%i:%s') >= DATE_FORMAT('2020-12-01T12:00:00', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");

    foreach($search_results as $result){
      if(is_numeric($result->nid)){
          $node_storage = \Drupal::entityTypeManager()->getStorage('node');
          $node1 = $node_storage->load($result->nid);
          $title_company = $node1->get('title')->value;

          $company_image = $node1->get('field_image')->entity->uri->value;
          $company_logo = $node1->get('field_logo')->entity->uri->value;
          
          $location_company = $node1->get('field_loco')->value;
          $meeting_time = $node1->get('field_time_date')->value;
          $today = date("Y-m-d");
          $system_time =time();
          $converted_time = gmdate("H:i", $system_time);
           $node_date = substr($meeting_time,0,-9);
           $node_time = substr($meeting_time,11,8);
          $modified_node_time   =  substr($node_time,0,5);
          // $time_in_sec =strtotime($node_time);

           //$time = time();
          drupal_set_message($company_logo);
          // drupal_set_message($converted_time ."system");
          //drupal_set_message($logo_company . $location_company . $meeting_time );
           // && $system_time == $time_in_sec
           
          if ($node_date == $today && $converted_time == $modified_node_time ) {
             drupal_set_message($title_company);
          }
           
      }

     
    }
     



    $viewId = 'front_screen_75_block';
    $view = Views::getView($viewId);
    if(is_object($view)) {
      $view->setDisplay('block');
      //$view->setArguments($arguments);
      $view->execute();
      // Render the view
      $result = \Drupal::service('renderer')->render($view->render());
      // return $result;   
     }
     $build = [];
    $build['content'] = [

      '#markup' =>$title_company . $result ,
      //'#markup' => '<div class="js-var">Our JS Page</div>',
    ];
    $build['#attached']['library'][] = 'php_to_js_ajax/js_exp_two';
    $build['#attached']['drupalSettings']['js_example']['title'] = $node_date;

    return $build;
  }

}
