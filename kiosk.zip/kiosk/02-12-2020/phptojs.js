/**
 * @file
 * Contains JS function
 */

(function ($, Drupal, drupalSettings) {
	//alert('ello44');
  'use strict';
  Drupal.behaviors.jsDrupalupTest = {
    attach: function (context, settings) {
      setInterval(function(){
        //alert("Hello");
    	jQuery.ajax({
                type: 'GET',
                url: 'http://shoppingnew.figover.com/php-to-js-ajax',
                success: function(data){
                console.log('success',data);

                $('.js-var').once('jsDrupalupTest').append('<button class="button">' + drupalSettings.js_example.title + '</button>');
                 console.log(drupalSettings.js_example.title);
               },
            });
        },60000);
    }
  };
})(jQuery, Drupal, drupalSettings);
