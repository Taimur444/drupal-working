<?php

namespace Drupal\php_to_js_ajax\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\views\Views;

//use Drupal\Core\Controller\Views;
//use Drupal\Views;
/**
 * Output of our JS page.
 */
class PhptojsController extends ControllerBase {

  public function PhpPage() {
  	// $test_date = date('Y-m-d h:i:s', time());
  	$test_date = date('Y-m-d G:i:s', strtotime('+5 hours'));
  	$q_time_substr = substr($test_date,-8);
    $query_min = substr($q_time_substr,3,2); //substr  for min roundoff query time
    $query_hour = substr($q_time_substr,0,2); //substr  for hour roundoff query time
    
    $q_date_substr =  substr($test_date,0,10);
    if ($query_min >= 1 && $query_min < 30 ){ $query_min = "0"."0"; }
    if($query_min >= 31 && $query_min < 60){ $query_min = 30; }
    
   // $query_time = $q_date_substr."T".$q_time_substr;
    $query_time = $q_date_substr."T".$query_hour.":".$query_min.":00"; //setting query current time
   

    $day_plus  = date('Y-m-d G:i:s', strtotime('+29 hours')); //quert time for 24hours meeting
    $q_time_plus_substr = substr($day_plus,-8);
    $q_date_plus_substr =  substr($day_plus,0,10);
    $query_day_plus = $q_date_plus_substr."T".$q_time_plus_substr;
  	 
  	//, strtotime('+5 hours')

    $server_time = date("h:i:s a", strtotime('+5 hours'));//adding 5 hours in server time for pk time
   
    $div_hour =substr($server_time,0,-9);
    $div_min = substr($server_time,3,2);
    $div_sec = substr($server_time,6,2);
    $am_pm = substr($server_time,9,2);


    if ($div_min >= 1 && $div_min < 30 ){ $div_min = "0"."0"; }
    if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
    $server_time = $div_hour.":".$div_min.":"."00".$am_pm;//.$div_sec;
 
    
    $z = strtotime("+30 minutes", strtotime($server_time));//adding 30 mins to server time 
    $incremented_time = date('h:i:sa', $z);//converting time format 
    
    $div_hour =substr($server_time,0,-6);//substring te server time and get hour i.e. 11 in 11:00am
    $div_min = substr($server_time,14,2);//substring te server time and get hour i.e. 50 in 11:50am
    $flag = False; //intializing all flag variables as a False
    $flag1 = False;
    $flag2 = False;
    $flag3 = False;
    $flag4 = False; 
    $flag5 = False;
    $flag6 = False;
    $flag7 = False;
    $flag8 = False;
    $flag9 = False;
    $flag_view75 = False;
    $htmla = "";
    $htmlb = "";
    $htmlc = "";
    $htmld = "";
    $htmle = "";
    $htmlf = "";
    $htmlg = "";
    $htmlh = "";
    $htmli = "";
    $htmlj = "";
    $full_view_75 = "";

    $next_time_flag1 = False;
    $next_time_flag2 = False;
    $next_time_flag3 = False;
    $next_time_flag4 = False;
    $next_time_flag5 = False;
    $next_time_flag6 = False;
    $next_time_flag7 = False;
    $next_time_flag8 = False;
    $next_time_flag9 = False;  
    $next_time_flag10 = False;
    $next_time_flag_view75 = False;    
    $meeting_ids = array(); 


        
          
 //get  all meetings of current time  +1 day 
  $search_results = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data 
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");


            
    foreach($search_results as $result){ //foreach to get results
        if(is_numeric($result->nid)){ //get nid from $results
        $nid = $result->nid;
        
        $node_storage = \Drupal::entityTypeManager()->getStorage('node'); //load node
        $node = $node_storage->load($result->nid);//load node by nid
        $node_time = $node->get('field_meeting_start_time')->value;//get meeting start time field 
      
        
        $node_time_substr = substr($node_time,11,8);//substring the field value as 18:00
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm; 
         // drupal_set_message($meeting_start_time." strt time");

        //if(($meeting_start_time >= $server_time) || ($node->get('field_meeting_end_time')->value >= $server_time)) {

          if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
            if(!in_array($result->nid, $meeting_ids)){
            $meeting_ids[] = $result->nid;
          
       
            $flag = True;  // intialize $flag as a true
          
              if($next_time_flag1 == False){
              $meeting_end_time = $node->get('field_meeting_end_time')->value; // getting field value
              $next_time_flag1 = True;
            
              $next_time_sub_str = substr($meeting_end_time,11,8);// substring value of meeting end time as04:00
          
           
              $next_time = date('h:i:sa', strtotime($next_time_sub_str));

              $div_hour =substr($next_time,0,2);
              //$div_hour = 10;
              $div_min = substr($next_time,3,2);
              //$div_min = 45;
            
              $am_pm = substr($next_time,8,2);
            
              if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
              if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++; }

              if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
              //if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

              $div_hour_length =  strlen($div_hour);
              //if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
              if($div_hour_length > 2){  $div_hour =  substr($div_hour,1);}
              $next_time = $div_hour.":".$div_min.":00".$am_pm; //.$div_sec;

            
           
              $div_next_time = substr($next_time,0,5);
              $div_next_am_pm = substr($next_time,8,2);
              $div_meeting_end = $div_next_time.$div_next_am_pm;
            
              $name_a = $node->get('title')->value;
              $entity_id = $node->get('field_company_name')->first()->getValue()['target_id'];//getting entity ref from node company name id
           
         
              $entity_node_storage = \Drupal::entityTypeManager()->getStorage('node');//load node for entityref
              $entity_node = $entity_node_storage->load($entity_id);
              //$company_name_a = $entity_node->get('title')->value;
              
              if(isset($entity_node)){
               $company_name_a = $entity_node->get('title')->value;
               }
              $user_data = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());//loading user
	            // $user_email = $user_data->get('email')->value;
              $user_pincode_a = $user_data->get('field_pincode')->value;//getting pincode fro  user profile
              $user_phone_a = $user_data->get('field_phone_')->value;
           
         
           
              $div_hour =substr($server_time,0,2);
              $div_min = substr($server_time,3,2); //substring minutes from server time i.e 00 from 01:00
              $am_pm = substr($server_time,8,2);
            
              if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; } //set limit of minutes if its is between 1-30 then show 30 and if it is btw 30-60 then 59.
              if($div_min >= 31 && $div_min < 60){ $div_min = 30;}


         
              $htmla = '<div class= "parent-node-fields">'.'<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.'<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.'<div class = "parent-node-detail">'.'<div class= "node-fields">'.'<div class= "three-elements">'.'<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.'<div class = "cancel-btn">'."CANCEL".'</div>'.'<div class = "cross">'."X".'</div>'.'</div>'.'<div class = "name">' .'<span>'."Name:".'</span>'.$name_a.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_a.'</div>'.'<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_a.'</div>'.'<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.'<div class = "pincode">' .$user_pincode_a.'</div>'.'</div>'.'</div>'.'</div>';

          
          
          
          
                $server_time = $next_time ; // giving meeting end time to server time.
                // $htmla = $htmla  . "server time from next time new" . $server_time;
          

                 // $htmla = $htmla  . " first row second server time " . $server_time;
                $a = strtotime("+30 minutes", strtotime($server_time));
                $incremented_time = date('h:i:sa', $a); 
          
         
         
              } // Next Time Flag checking array
        
            } // End If for checking meeting ids
          } //main meeting condition
        } //is numeric
    }//for each
   
    if($flag == False) {  //if flag is false i.e is control dont find any meeting in current time
      $div_hour =substr($server_time,0,2); //substring hour from server time i.e 01 from 01:00
      $div_min = substr($server_time,3,2); //substring hour from server time i.e 01 from 01:00
      $am_pm = substr($server_time,8,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }//set limit of minutes if its is between 1-30 then show 30 and if it is btw 30-60 then 59.
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmla =  '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';//post half hour div
      $server_time = $incremented_time;
       
      $a = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $a);

    }

    //some comments for next 9 for each to show 9 meetings with half hour gap
/*----------------------------------------2nd time-------------------------------------------------*/
    // $server_time = $incremented_time; // giving 30+ min time in curent time to server
    // $a = strtotime("+30 minutes", strtotime($server_time));//add 30+ min again in server time
    // $incremented_time = date('H:i:s', $a);// converting to normal
      
       $second_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data 
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    

      foreach( $second_turn as $aa){
        if(is_numeric($aa->nid)){
        $nid = $aa->nid;
        $node_storage1 = \Drupal::entityTypeManager()->getStorage('node');
        $node1 = $node_storage1->load($aa->nid);
        $node_time = $node1->get('field_meeting_start_time')->value;
        $node_time_substr= substr($node_time,11,8);
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));

        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;

          if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
            $flag1 = True;
            $meeting_end_time = $node1->get('field_meeting_end_time')->value;
            if($next_time_flag2 == False){
              $next_time_flag2 = True;
              $next_time_sub_str = substr($meeting_end_time,11,8);

              $next_time = date('h:i:sa', strtotime($next_time_sub_str));
            
              $div_hour =substr($next_time,0,2);
              $div_min = substr($next_time,3,2);
              $am_pm = substr($next_time,8,2);
              if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
              if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++; }
			        if ($div_min == "0"."0") {$div_hour = "0".$div_hour;}
              //if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}
              $div_hour_length =  strlen($div_hour);
              //if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
              if($div_hour_length > 2){  $div_hour =  substr($div_hour,1);}
              $next_time = $div_hour.":".$div_min.":00".$am_pm;
           
              $div_next_time = substr($next_time,0,5);
              $div_next_am_pm = substr($next_time,8,2);
              $div_meeting_end = $div_next_time.$div_next_am_pm;
            
              $name_b = $node1->get('title')->value;
              $entity_id_b = $node1->get('field_company_name')->first()->getValue()['target_id'];
         
              $entity_node_storage1 = \Drupal::entityTypeManager()->getStorage('node');
              $entity_node1 = $entity_node_storage1->load($entity_id_b);
              //$company_name_b = $entity_node1->get('title')->value;
              //drupal_set_message(serialize($entity_node1)."h2");
              if(isset($entity_node1)){
               $company_name_b = $entity_node1->get('title')->value;
               }

              $user_data = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());

              //$user_email = $user_data->get('email')->value;
              $user_pincode_b = $user_data->get('field_pincode')->value;
              $user_phone_b = $user_data->get('field_phone_')->value;
          

              $div_hour =substr($server_time,0,2);
              $div_min = substr($server_time,3,2);
              $am_pm = substr($server_time,8,2);
              if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
              if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
         
              $htmlb = '<div class= "parent-node-fields">'.'<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.'<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.'<div class = "parent-node-detail">'.'<div class= "node-fields">'.'<div class= "three-elements">'.'<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.'<div class = "cancel-btn">'."CANCEL".'</div>'.'<div class = "cross">'."X".'</div>'.'</div>'.'<div class = "name">' .'<span>'."Name:".'</span>'.$name_b.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_b.'</div>'.'<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_b.'</div>'.'<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.'<div class = "pincode">' .$user_pincode_b.'</div>'.'</div>'.'</div>'.'</div>';
          
         
                $server_time = $next_time ;
       
                $b = strtotime("+30 minutes", strtotime($server_time));
                $incremented_time = date('h:i:sa', $b);
         
             
            }// flag if condition

            
          }//main meetings time if condition
          
        }//if numeric condtion
      
      } //for each

    if($flag1 == False) {
  
      
      $div_hour =substr($server_time,0,2);
      $div_min = substr($server_time,3,2);
      $am_pm = substr($server_time,8,2);

      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmlb =  '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';
     
      $server_time = $incremented_time;
      
      //$htmlb = $htmlb  . " server_time 2nd turn" . $server_time;
      $b = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $b);
    }


/*----------------------------------------3rd time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $third_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    
    foreach($third_turn as $result2){
      if(is_numeric($result2->nid)){
        $nid = $result2->nid;
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node2 = $node_storage->load($result2->nid);
        $node_time = $node2->get('field_meeting_start_time')->value;
        $node_time_substr= substr($node_time,11,8);
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;

        
       
       
    
        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
          //drupal_set_message("3rd step if");
          $flag2 = True;
          $meeting_end_time = $node2->get('field_meeting_end_time')->value;
          if($next_time_flag3 == False){
            $next_time_flag3 = True;
            $next_time_sub_str = substr($meeting_end_time,11,8);


            $next_time = date('h:i:sa', strtotime($next_time_sub_str));
            $div_hour =substr($next_time,0,2);
            $div_min = substr($next_time,3,2);
            $div_sec = substr($next_time,6,2);
            $am_pm = substr($next_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++; }
			      if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
            // if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

            $div_hour_length =  strlen($div_hour);
            //if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
            if($div_hour_length > 2){  $div_hour =  substr($div_hour,1); }
            $next_time = $div_hour.":".$div_min.":00".$am_pm;

            
            $div_next_time = substr($next_time,0,5);
            $div_next_am_pm = substr($next_time,8,2);
            $div_meeting_end = $div_next_time.$div_next_am_pm;
            
            $name_c = $node2->get('title')->value;
            $entity_id = $node2->get('field_company_name')->first()->getValue()['target_id'];
         
           $entity_node_storage2 = \Drupal::entityTypeManager()->getStorage('node');
           $entity_node2 = $entity_node_storage2->load($entity_id);
           //$company_name_c = $entity_node2->get('title')->value;

           if(isset($entity_node2)){
               $company_name_c = $entity_node2->get('title')->value;
               }

           $user_data = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
           // $user_email = $user_data->get('email')->value;
           $user_pincode_c = $user_data->get('field_pincode')->value;
           $user_phone_c = $user_data->get('field_phone_')->value;

          
           $div_hour =substr($server_time,0,2);
           $div_min = substr($server_time,3,2);
           $am_pm = substr($server_time,8,2);
           if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
           if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
         
        
           $htmlc = '<div class= "parent-node-fields">'.'<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.'<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.'<div class = "parent-node-detail">'.'<div class= "node-fields">'.'<div class= "three-elements">'.'<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.'<div class = "cancel-btn">'."CANCEL".'</div>'.'<div class = "cross">'."X".'</div>'.'</div>'.'<div class = "name">' .'<span>'."Name:".'</span>'.$name_c.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_c.'</div>'.'<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_c.'</div>'.'<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.'<div class = "pincode">' .$user_pincode_c.'</div>'.'</div>'.'</div>'.'</div>';
           $server_time = $next_time ;
         
           $c = strtotime("+30 minutes", strtotime($server_time));
           $incremented_time = date('h:i:sa', $c);

          }// flag if condition
             
        }//main meetings time check 
          
      }//if numeric condition
    }//for each
     
  
    if($flag2 == False) {
      $div_hour =substr($server_time,0,2);
      $div_min = substr($server_time,3,2);
      $am_pm = substr($server_time,8,2);
      
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; $div_hour++; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmlc = $htmlc. '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';
      $server_time = $incremented_time;
      $c = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $c);
    }


/*------------------------------------------------------------------------------------------------*/

/*----------------------------------------4th time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $fourth_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
   
    foreach($fourth_turn as $result3){
      if(is_numeric($result3->nid)){
        $nid = $result3->nid;
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node3 = $node_storage->load($result3->nid);
        $node_time = $node3->get('field_meeting_start_time')->value;
        $node_time_substr= substr($node_time,11,8);

        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;



           
    
       // $htmld = $htmld . " meeting_start_time forth" . $meeting_start_time . " server_time forth "  . $meeting_start_time . " incremented_time forth " . $incremented_time . " next line ";
        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
          $flag3 = True;
          $meeting_end_time = $node3->get('field_meeting_end_time')->value;
          if($next_time_flag4 == False){
            $next_time_flag4 = True;
            $next_time_sub_str = substr($meeting_end_time,11,8);
            $next_time = date('h:i:sa', strtotime($next_time_sub_str));
           
            $div_hour =substr($next_time,0,2);
            $div_min = substr($next_time,3,2);
            $am_pm = substr($next_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++;}
            if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
            //if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

            $div_hour_length =  strlen($div_hour);
            //if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
            if($div_hour_length > 2){  $div_hour =  substr($div_hour,1); }

            $next_time = $div_hour.":".$div_min.":00".$am_pm;

            $div_next_time = substr($next_time,0,5);
            $div_next_am_pm = substr($next_time,8,2);
            $div_meeting_end = $div_next_time.$div_next_am_pm;
            
            $name_d = $node3->get('title')->value;
            $entity_id_d = $node3->get('field_company_name')->first()->getValue()['target_id'];
         
            $entity_node_storage3 = \Drupal::entityTypeManager()->getStorage('node');
            $entity_node3 = $entity_node_storage3->load($entity_id_d);
            //$company_name_d = $entity_node3->get('title')->value;

            if(isset($entity_node3)){
               $company_name_d = $entity_node3->get('title')->value;
               }

            $user_data3 = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
            // $user_email = $user_data->get('email')->value;
            $user_pincode_d = $user_data3->get('field_pincode')->value;
            $user_phone_d = $user_data3->get('field_phone_')->value;
          
            $div_hour =substr($server_time,0,2);
            $div_min = substr($server_time,3,2);
            $am_pm = substr($server_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
            if($div_min >= 31 && $div_min < 60){ $div_min = 30; }

          
            $htmld = '<div class= "parent-node-fields">'.'<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.'<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.'<div class = "parent-node-detail">'.'<div class= "node-fields">'.'<div class= "three-elements">'.'<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.'<div class = "cancel-btn">'."CANCEL".'</div>'.'<div class = "cross">'."X".'</div>'.'</div>'.'<div class = "name">' .'<span>'."Name:".'</span>'.$name_d.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_d.'</div>'.'<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_d.'</div>'.'<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.'<div class = "pincode">' .$user_pincode_d.'</div>'.'</div>'.'</div>'.'</div>';
              $server_time = $next_time ;
          
              $d = strtotime("+30 minutes", strtotime($server_time));
              $incremented_time = date('h:i:sa', $d);
            }
             
          }
          
        }
      }

    if($flag3 == False) {
      $div_hour =substr($server_time,0,2);
      $div_min = substr($server_time,3,2);
      $am_pm = substr($server_time,8,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmld =  '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';
      $server_time = $incremented_time;
      $d = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $d);
    }


/*------------------------------------------------------------------------------------------------*/


/*----------------------------------------5th time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $fift_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    
    foreach($fift_turn as $result4){
      if(is_numeric($result4->nid)){
        $nid = $result4->nid;
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node4 = $node_storage->load($result4->nid);
        $node_time = $node4->get('field_meeting_start_time')->value;
        $node_time_substr = substr($node_time,11,8);
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;

         //$htmle = $htmle . " meeting_start_time fith " . $meeting_start_time . " server_time fift" . $meeting_start_time . " incremented_time fift " . $incremented_time . " next line ";

        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
         
          $flag4 = True;
          $meeting_end_time = $node4->get('field_meeting_end_time')->value;
          if($next_time_flag5 == False){
            $next_time_flag5 = True;
            $next_time_sub_str = substr($meeting_end_time,11,8);

            $next_time = date('h:i:sa', strtotime($next_time_sub_str));
            $div_hour =substr($next_time,0,2);
            $div_min = substr($next_time,3,2);
             $am_pm = substr($next_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++;}

            if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
            //if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

            $div_hour_length =  strlen($div_hour);
            //if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
            if($div_hour_length > 2){  $div_hour =  substr($div_hour,1); }

            $next_time = $div_hour.":".$div_min.":00".$am_pm;

            $div_next_time = substr($next_time,0,5);
            $div_next_am_pm = substr($next_time,8,2);
            $div_meeting_end = $div_next_time.$div_next_am_pm;
            
            $name_e = $node4->get('title')->value;
            $entity_id_e = $node4->get('field_company_name')->first()->getValue()['target_id'];
         
            $entity_node_storage4 = \Drupal::entityTypeManager()->getStorage('node');
            $entity_node4 = $entity_node_storage4->load($entity_id_e);
            //$company_name4 = $entity_node4->get('title')->value;
            if(isset($entity_node4)){
               $company_name_e = $entity_node4->get('title')->value;
               }

            $user_data = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
            // $user_email = $user_data->get('email')->value;
            $user_pincode_e = $user_data->get('field_pincode')->value;
            $user_phone_e = $user_data->get('field_phone_')->value;
          
            $div_hour =substr($server_time,0,2);
            $div_min = substr($server_time,3,2);
            $am_pm = substr($server_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
            if($div_min >= 31 && $div_min < 60){ $div_min = 30; }

          
            $htmle = '<div class= "parent-node-fields">'.'<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.'<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.'<div class = "parent-node-detail">'.'<div class= "node-fields">'.'<div class= "three-elements">'.'<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.'<div class = "cancel-btn">'."CANCEL".'</div>'.'<div class = "cross">'."X".'</div>'.'</div>'.'<div class = "name">' .'<span>'."Name:".'</span>'.$name_e.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_e.'</div>'.'<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_e.'</div>'.'<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.'<div class = "pincode">' .$user_pincode_e.'</div>'.'</div>'.'</div>'.'</div>';
              $server_time = $next_time ;
          
              $e = strtotime("+30 minutes", strtotime($server_time));
              $incremented_time = date('h:i:sa', $e);

            }//flag condition
             
          }// meetings time check
          
        }//if numeric
      
      }//for each

    if($flag4 == False) {
      $div_hour =substr($server_time,0,2);
      $div_min = substr($server_time,3,2);
       $am_pm = substr($server_time,8,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmle = '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';
      $server_time = $incremented_time;
      $e = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $e);
    }


/*------------------------------------------------------------------------------------------------*/
/*----------------------------------------6th time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $sixth_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    
    foreach($sixth_turn as $result5){
      if(is_numeric($result5->nid)){
       $nid = $result5->nid;
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node5 = $node_storage->load($result5->nid);
        $node_time = $node5->get('field_meeting_start_time')->value;
        $node_time_substr = substr($node_time,11,8);
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;

         //$htmle = $htmle . " meeting_start_time fith " . $meeting_start_time . " server_time fift" . $meeting_start_time . " incremented_time fift " . $incremented_time . " next line ";

        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
         
          $flag5 = True;
          $meeting_end_time = $node5->get('field_meeting_end_time')->value;
          if($next_time_flag6 == False){
            $next_time_flag6 = True;
            $next_time_sub_str = substr($meeting_end_time,11,8);

            $next_time = date('h:i:sa', strtotime($next_time_sub_str));
            $div_hour =substr($next_time,0,2);
            $div_min = substr($next_time,3,2);
             $am_pm = substr($next_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++;}

            if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
           // if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

            $div_hour_length =  strlen($div_hour);
            //if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
            if($div_hour_length > 2){  $div_hour =  substr($div_hour,1); }

            $next_time = $div_hour.":".$div_min.":00".$am_pm;

            $div_next_time = substr($next_time,0,5);
            $div_next_am_pm = substr($next_time,8,2);
            $div_meeting_end = $div_next_time.$div_next_am_pm;
            
            $name_f = $node5->get('title')->value;
           $entity_id_f = $node5->get('field_company_name')->first()->getValue()['target_id'];
         
           $entity_node_storage = \Drupal::entityTypeManager()->getStorage('node');
           $entity_node = $entity_node_storage->load($entity_id_f);
          // $company_name_f = $entity_node->get('title')->value;

           if(isset($entity_node)){
               $company_name_f = $entity_node->get('title')->value;
               }

           $user_data = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
           // $user_email = $user_data->get('email')->value;
           $user_pincode_f = $user_data->get('field_pincode')->value;
           $user_phone_f = $user_data->get('field_phone_')->value;
          
          $div_hour =substr($server_time,0,2);
          $div_min = substr($server_time,3,2);
           $am_pm = substr($server_time,8,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
          if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
          
          $htmlf = '<div class= "parent-node-fields">'.'<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.'<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.'<div class = "parent-node-detail">'.'<div class= "node-fields">'.'<div class= "three-elements">'.'<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.'<div class = "cancel-btn">'."CANCEL".'</div>'.'<div class = "cross">'."X".'</div>'.'</div>'.'<div class = "name">' .'<span>'."Name:".'</span>'.$name_f.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_f.'</div>'.'<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_f.'</div>'.'<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.'<div class = "pincode">' .$user_pincode.'</div>'.'</div>'.'</div>'.'</div>';
          $server_time = $next_time ;
          
          $f = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('h:i:sa', $f);

        }
             
        }
          
      }
    }

    if($flag5 == False) {
      $div_hour =substr($server_time,0,2);
      $div_min = substr($server_time,3,2);
       $am_pm = substr($server_time,8,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmlf = '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';
      $server_time = $incremented_time;
      $f = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $f);
    }


/*------------------------------------------------------------------------------------------------*/
/*----------------------------------------7th time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $seventh_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    
    foreach($seventh_turn as $result6){
      if(is_numeric($result6->nid)){
       $nid = $result6->nid;
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node6 = $node_storage->load($result6->nid);
        $node_time = $node6->get('field_meeting_start_time')->value;
        $node_time_substr = substr($node_time,11,8);
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;

        

         //$htmle = $htmle . " meeting_start_time fith " . $meeting_start_time . " server_time fift" . $meeting_start_time . " incremented_time fift " . $incremented_time . " next line ";

        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
         
          $flag6 = True;
          $meeting_end_time = $node6->get('field_meeting_end_time')->value;
          if($next_time_flag7 == False){
            $next_time_flag7 = True;
            $next_time_sub_str = substr($meeting_end_time,11,8);

            $next_time = date('h:i:sa', strtotime($next_time_sub_str));
            $div_hour =substr($next_time,0,2);
            $div_min = substr($next_time,3,2);
             $am_pm = substr($next_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++;}

            if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
           // if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}
            $div_hour_length =  strlen($div_hour);
           // if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
            if($div_hour_length > 2){  $div_hour =  substr($div_hour,1); }

            $next_time = $div_hour.":".$div_min.":00".$am_pm;

            $div_next_time = substr($next_time,0,5);
            $div_next_am_pm = substr($next_time,8,2);
            $div_meeting_end = $div_next_time.$div_next_am_pm;
            
            $name_g = $node6->get('title')->value;
           $entity_id_g = $node6->get('field_company_name')->first()->getValue()['target_id'];
         
           $entity_node_storage6 = \Drupal::entityTypeManager()->getStorage('node');
           $entity_node6 = $entity_node_storage6->load($entity_id_g);
           //$company_name_g = $entity_node6->get('title')->value;
           if(isset($entity_node6)){
               $company_name_g = $entity_node6->get('title')->value;
               }

           $user_data = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
           // $user_email = $user_data->get('email')->value;
           $user_pincode_g = $user_data->get('field_pincode')->value;
           $user_phone_g = $user_data->get('field_phone_')->value;
        
          $div_hour =substr($server_time,0,2);
          $div_min = substr($server_time,3,2);
           $am_pm = substr($server_time,8,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
          if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
          
          $htmlg = '<div class= "parent-node-fields">'.'<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.'<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.'<div class = "parent-node-detail">'.'<div class= "node-fields">'.'<div class= "three-elements">'.'<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.'<div class = "cancel-btn">'."CANCEL".'</div>'.'<div class = "cross">'."X".'</div>'.'</div>'.'<div class = "name">' .'<span>'."Name:".'</span>'.$name_g.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_g.'</div>'.'<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_g.'</div>'.'<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.'<div class = "pincode">' .$user_pincode_g.'</div>'.'</div>'.'</div>'.'</div>';
          $server_time = $next_time ;
          
          $g = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('h:i:sa', $g);

        }
             
        }
          
      }
    }

    if($flag6 == False) {
      $div_hour =substr($server_time,0,2);
      $div_min = substr($server_time,3,2);
       $am_pm = substr($server_time,8,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmlg = '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';
      $server_time = $incremented_time;
      $g = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $g);
    }

/*----------------------------------------8th time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $eight_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    
    foreach($eight_turn as $result7){
      if(is_numeric($result7->nid)){
       $nid = $result7->nid;
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node7 = $node_storage->load($result7->nid);
        $node_time = $node7->get('field_meeting_start_time')->value;
        $node_time_substr = substr($node_time,11,8);
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;
           
        // $htmle = $htmle . " id " . $result6->nid . " server_time fift" . $meeting_start_time . " incremented_time fift " . $incremented_time . " next line ";

        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
         
          $flag7 = True;
          $meeting_end_time = $node7->get('field_meeting_end_time')->value;
          if($next_time_flag8 == False){
            $next_time_flag8 = True;
            $next_time_sub_str = substr($meeting_end_time,11,8);

            $next_time = date('h:i:sa', strtotime($next_time_sub_str));
            $div_hour =substr($next_time,0,2);
            $div_min = substr($next_time,3,2);
             $am_pm = substr($next_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++;}

            if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
            //if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

            $div_hour_length =  strlen($div_hour);
           // if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
            if($div_hour_length > 2){  $div_hour =  substr($div_hour,1); }

            $next_time = $div_hour.":".$div_min.":00".$am_pm;

            $div_next_time = substr($next_time,0,5);
            $div_next_am_pm = substr($next_time,8,2);
            $div_meeting_end = $div_next_time.$div_next_am_pm;
            
            $name_h = $node7->get('title')->value;
           $entity_id = $node7->get('field_company_name')->first()->getValue()['target_id'];
         
           $entity_node_storage7 = \Drupal::entityTypeManager()->getStorage('node');
           $entity_node7 = $entity_node_storage7->load($entity_id);
           //$company_name = $entity_node7->get('title')->value;

           if(isset($entity_node7)){
               $company_name_h = $entity_node7->get('title')->value;
               }

           $user_data = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
           // $user_email = $user_data->get('email')->value;
           $user_pincode = $user_data->get('field_pincode')->value;
           $user_phone_h = $user_data->get('field_phone_')->value;
        
          $div_hour =substr($server_time,0,2);
          $div_min = substr($server_time,3,2);
           $am_pm = substr($server_time,8,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
          if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
          
          $htmlh = '<div class= "parent-node-fields">'.'<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.'<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.'<div class = "parent-node-detail">'.'<div class= "node-fields">'.'<div class= "three-elements">'.'<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.'<div class = "cancel-btn">'."CANCEL".'</div>'.'<div class = "cross">'."X".'</div>'.'</div>'.'<div class = "name">' .'<span>'."Name:".'</span>'.$name_h.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_h.'</div>'.'<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_h.'</div>'.'<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.'<div class = "pincode">' .$user_pincode_h.'</div>'.'</div>'.'</div>'.'</div>';
          $server_time = $next_time ;
          
          $h = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('h:i:sa', $h);

        }
             
        }
          
      }
    }

    if($flag7 == False) {
      $div_hour =substr($server_time,0,2);
      $div_min = substr($server_time,3,2);
       $am_pm = substr($server_time,8,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmlh = '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';
      $server_time = $incremented_time;
      $h = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $h);
    }

/*----------------------------------------9th time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $ninth_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    
    foreach($ninth_turn as $result8){
      if(is_numeric($result8->nid)){
       $nid = $result8->nid;
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node8 = $node_storage->load($result8->nid);
        $node_time = $node8->get('field_meeting_start_time')->value;
        $node_time_substr = substr($node_time,11,8);
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;

         //$htmle = $htmle . " meeting_start_time fith " . $meeting_start_time . " server_time fift" . $meeting_start_time . " incremented_time fift " . $incremented_time . " next line ";

        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
         
          $flag8 = True;
          $meeting_end_time = $node8->get('field_meeting_end_time')->value;
          if($next_time_flag9 == False){
            $next_time_flag9 = True;
            $next_time_sub_str = substr($meeting_end_time,11,8);

            $next_time = date('h:i:sa', strtotime($next_time_sub_str));
            $div_hour =substr($next_time,0,2);
            $div_min = substr($next_time,3,2);
             $am_pm = substr($next_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++;}

            if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
           // if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

            $div_hour_length =  strlen($div_hour);
           // if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
            if($div_hour_length > 2){  $div_hour =  substr($div_hour,1); }

            $next_time = $div_hour.":".$div_min.":00".$am_pm;

            $div_next_time = substr($next_time,0,5);
            $div_next_am_pm = substr($next_time,8,2);
            $div_meeting_end = $div_next_time.$div_next_am_pm;
            
            $name_i = $node8->get('title')->value;
           $entity_id_i = $node8->get('field_company_name')->first()->getValue()['target_id'];
         
           $entity_node_storage8 = \Drupal::entityTypeManager()->getStorage('node');
           $entity_node8 = $entity_node_storage8->load($entity_id_i);
           //$company_name_i = $entity_node8->get('title')->value;

           if(isset($entity_node8)){
               $company_name_i = $entity_node8->get('title')->value;
               }

           $user_data8 = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
           // $user_email = $user_data->get('email')->value;
           $user_pincode_i = $user_data8->get('field_pincode')->value;
           $user_phone_i = $user_data8->get('field_phone_')->value;
        
          $div_hour =substr($server_time,0,2);
          $div_min = substr($server_time,3,2);
           $am_pm = substr($server_time,8,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
          if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
          
          $htmli = '<div class= "parent-node-fields">'.'<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.'<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.'<div class = "parent-node-detail">'.'<div class= "node-fields">'.'<div class= "three-elements">'.'<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.'<div class = "cancel-btn">'."CANCEL".'</div>'.'<div class = "cross">'."X".'</div>'.'</div>'.'<div class = "name">' .'<span>'."Name:".'</span>'.$name_i.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_i.'</div>'.'<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_i.'</div>'.'<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.'<div class = "pincode">' .$user_pincode.'</div>'.'</div>'.'</div>'.'</div>';
          $server_time = $next_time ;
          
          $i = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('h:i:sa', $i);

        }
             
        }
          
      }
    }

    if($flag8 == False) {
      $div_hour =substr($server_time,0,2);
      $div_min = substr($server_time,3,2);
       $am_pm = substr($server_time,8,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmli = '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';
      $server_time = $incremented_time;
      $i = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $i);
    }

/*----------------------------------------10th time--------------------------------------------*/

    // $server_time = $incremented_time;
    // $b = strtotime("+30 minutes", strtotime($server_time));
    // $incremented_time = date('H:i:s', $b);

  $tenth_turn = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
        FROM
        {node_field_data} node_field_data
        LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
        WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time','%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$query_day_plus','%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
    
    foreach($tenth_turn as $result9){
      if(is_numeric($result9->nid)){
       $nid = $result9->nid;
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node9 = $node_storage->load($result9->nid);
        $node_time = $node9->get('field_meeting_start_time')->value;
        $node_time_substr = substr($node_time,11,8);
        $meeting_start_time = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;

         //$htmle = $htmle . " meeting_start_time fith " . $meeting_start_time . " server_time fift" . $meeting_start_time . " incremented_time fift " . $incremented_time . " next line ";

        if($meeting_start_time >= $server_time && $meeting_start_time < $incremented_time){
         
          $flag9 = True;
          $meeting_end_time = $node9->get('field_meeting_end_time')->value;
          if($next_time_flag10 == False){
            $next_time_flag10 = True;
            $next_time_sub_str = substr($meeting_end_time,11,8);

            $next_time = date('h:i:sa', strtotime($next_time_sub_str));
            $div_hour =substr($next_time,0,2);
            $div_min = substr($next_time,3,2);
             $am_pm = substr($next_time,8,2);
            if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++;}

            if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
           // if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

            $div_hour_length =  strlen($div_hour);
            //if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
            if($div_hour_length > 2){  $div_hour =  substr($div_hour,1); }

            $next_time = $div_hour.":".$div_min.":00".$am_pm;

            $div_next_time = substr($next_time,0,5);
            $div_next_am_pm = substr($next_time,8,2);
            $div_meeting_end = $div_next_time.$div_next_am_pm;
            
            $name_j = $node9->get('title')->value;
           $entity_id_j = $node9->get('field_company_name')->first()->getValue()['target_id'];
         
           $entity_node_storage9 = \Drupal::entityTypeManager()->getStorage('node');
           $entity_node9 = $entity_node_storage9->load($entity_id);
           //$company_name_j = $entity_node9->get('title')->value;

           if(isset($entity_node9)){
               $company_name_j = $entity_node9->get('title')->value;
               }

           $user_data9 = \Drupal\user\Entity\User::load(\Drupal::currentUser()->id());
           // $user_email = $user_data->get('email')->value;
           $user_pincode_j = $user_data9->get('field_pincode')->value;
           $user_phone_j = $user_data9->get('field_phone_')->value;
        
          $div_hour =substr($server_time,0,2);
          $div_min = substr($server_time,3,2);
           $am_pm = substr($server_time,8,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = "0"."0"; }
          if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
          
//**************************This is For Reserved time and Not Reserved Time.**********************//
              
        $htmlj = '<div class= "parent-node-fields">'.
        '<div class = "reserved meeting-time">'.$div_hour.":".$div_min.$am_pm."- Reserved".'</div>'.
              '<div  class = "grey">'.$div_hour.":".$div_min.$am_pm.'</div>'.
            
//****** This is a Box Where We see Meeting details and jump to the cancel meeting option.********// 
            
              '<div class = "parent-node-detail">'.
              '<div class= "node-fields">'.
              '<div class= "three-elements">'.
              '<div class = "duration">'.$div_meeting_start ."-".$div_meeting_end.'</div>'.
              '<div class = "cancel-btn">'."CANCEL".
              '</div>'.
              '<div class = "cross">'."X".'</div>'.
              '</div>'.
            
              '<div class = "name">' .'<span>'."Name:".'</span>'.$name_j.'</div>'.'<div class = "company-name">'.'<span>'."Company:".'</span>'.$company_name_j.'</div>'.
              '<div class = "email">' .'<span>'."Email:".'</span>'.'</div>'.'<div class = "phone">'.'<span>'."Phone:".'</span>'.$user_phone_j.'</div>'.
            
//****** This Box is use to Confirm that you want to Cancel Meeting or Not.***********************//  
            
              '<div class= "cancel-text-parent">'.'<div class = "conformation">'.'<span class = "confo-text">'."Conformation".'</span>'.'</div>'.'<div class = "conf-x">'.'<span class = "x-end">'."X".'</span>'.'</div>'.'<div class = "cancel-text">' ."Are you sure  you'd like to cancel this event ?Cancellation is irreversible.".'</div>'.'<div class = "yes">'.'<span class = "yes-text">'."YES".'</span>'.'</div>'.'<div class = "no">'.'<span class = "no-text">'."NO".'</span>'.'</div>'.'</div>'.
              
              '<div class = "pincode">' .$user_pincode_j.'</div>'.'</div>'.'</div>'.'</div>';
          $server_time = $next_time ;
          
          $j = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('h:i:sa', $j);

      }      
    }      
  }
}

    if($flag9 == False) {
      $div_hour =substr($server_time,0,2);
      $div_min = substr($server_time,3,2);
       $am_pm = substr($server_time,8,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = "0"."0"; }
      if($div_min >= 31 && $div_min < 60){ $div_min = 30; }
      $htmlj = '<div class ="meeting-time">'.$div_hour.":".$div_min.$am_pm.'</div>';
      $server_time = $incremented_time;
      $j = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $j);
    }
/*------------------------------------------------------------------------------------------------*/

/*------------------------view 75% ---------------------------------------------------*/ 

$server_time_view = date("h:i:sa", strtotime('+5 hours'));

$view_incre_75 = strtotime("+30 minutes", strtotime($server_time_view));//adding 30 mins to server time 
$incremented_time_75 = date('h:i:sa', $view_incre_75);

$day_plus_view  = date('Y-m-d G:i:s', strtotime('+5 hours 30 minutes')); 
    $view_query = db_query("SELECT node__field_meeting_start_time.field_meeting_start_time_value AS node__field_meeting_start_time_field_meeting_start_time_valu, node_field_data.nid AS nid
  FROM
    {node_field_data} node_field_data
    LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
    WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('$query_time', '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('$day_plus_view', '%Y-%m-%d\T%H:%i:%s')))
      LIMIT 1 OFFSET 0");

    foreach($view_query as $view75){ //foreach to get results
       //drupal_set_message(serialize($result));
      if(is_numeric($view75->nid)){

        drupal_set_message($view75->nid);
         $node_storage = \Drupal::entityTypeManager()->getStorage('node'); //load node
        $node = $node_storage->load($view75->nid);//load node by nid
        $node_time_view75 = $node->get('field_meeting_start_time')->value;//get meeting start time field 
      
        
        $node_time_substr = substr($node_time_view75,11,8);//substring the field value as 18:00
        $meeting_start_time_75 = date('h:i:sa', strtotime($node_time_substr));
        $div_time = substr($meeting_start_time,0,5);
        $div_am_pm = substr($meeting_start_time,8,2);
        $div_meeting_start = $div_time.$div_am_pm;

        if($meeting_start_time_75 >= $server_time_view && $meeting_start_time_75 < $incremented_time_75){

            $flag_view75 = True;
            if($next_time_flag_view == False){
              $meeting_end_time_75 = $node->get('field_meeting_end_time')->value; // getting field value

              $next_time_sub_str = substr($meeting_end_time_75,11,8);// substring value of meeting end time as04:00

              $next_time_view = date('h:i:sa', strtotime($next_time_sub_str));

              $div_hour =substr($next_time_view,0,2);
                //$div_hour = 10;
              $div_min = substr($next_time_view,3,2);
                //$div_min = 45;
            
              $am_pm = substr($next_time_view,8,2);
              
              if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
              if($div_min >= 31 && $div_min < 60){ $div_min = "0"."0"; $div_hour++; }

              if ($div_min== "0"."0") {$div_hour = "0".$div_hour;}
               //if ($div_hour > 9){ $div_hour = substr($div_hour,1,3);}

              $div_hour_length =  strlen($div_hour);
               //if($div_hour_length < 2){  $div_hour =  "0".$div_hour; }
              if($div_hour_length > 2){  $div_hour =  substr($div_hour,1);}
              $next_time = $div_hour.":".$div_min.":00".$am_pm; //.$div_sec;


              $company_img_view = $node->get('field_image')->entity->uri->value;
              $company_logo_view = $node->get('field_logo')->entity->uri->value;
              $name_a_view = $node->get('title')->value;
              $entity_id = $node->get('field_company_name')->first()->getValue()['target_id'];//getting entity ref from node company name id


              $entity_node_storage = \Drupal::entityTypeManager()->getStorage('node');//load node for entityref
              $entity_node = $entity_node_storage->load($entity_id);
              //$company_name_a = $entity_node->get('title')->value;
              
              if(isset($entity_node)){
               $company_name_a = $entity_node->get('title')->value;
               }
               

              $st_time =  substr($meeting_start_time,0,5);
              $am_pms = substr($meeting_start_time,8,2);
              //$html_st_time = $st_time.  $am_pms;
              $en_time =  substr($next_time,0,5);
              $am_pme = substr($next_time,8,2);
              //$html_en_time = $en_time.   $am_pme;
              //$today = date("D, M j, Y  h:i a" , strtotime('+5 hours')); 
              $today = date("l, F  jS , Y h:i a", strtotime('+5 hours'));
              drupal_set_message($today);

              $full_view_75 = '<div>'.$name_a.'</div>'.'<div class = " meeting-time">'.$st_time. ' '.$am_pms." to ".$en_time.' '.$am_pme.'</div>'.'<div>'.$company_name_a.'</div>'.'<div class="seventy-five-per>'.$company_img.'</div>'.'<div>'.$company_logo.'</div>';

              $server_time = $next_time ;
              $a = strtotime("+30 minutes", strtotime($server_time));
                $incremented_time = date('h:i:sa', $a); 
            }
        }    
      }

    }
   if($flag_view75 == False) {  //if flag is false i.e is control dont find any meeting in current time
    
      $full_view_75 = '<div>'."meeting is availble untill".'</div>';//post half hour div
      $server_time = $incremented_time;
       
      $a = strtotime("+30 minutes", strtotime($server_time));
      $incremented_time = date('h:i:sa', $a);

      }


    /*------------------------view 75%  end---------------------------------------------------*/ 

    $viewId = 'front_screen_75_block';
    $view = Views::getView($viewId);
    //$arguments[]= 1;
    if(is_object($view)) {
      $view->setDisplay('block');
      //$view->setArguments($arguments)[];
      $view->execute();
      // Render the view
      $result = \Drupal::service('renderer')->render($view->render());
      // return $result;   
    }
         //$block_view = $result.$server_time."helo";
    $build = [];
    $build['content'] = [

    '#markup' => '<div class="full-view"><div class = "seventy-five-per"><div class="mydiv"></div>'. $result .'</div><div class = "twenty-five-per">'. $htmla.$htmlb.$htmlc.$htmld .$htmle.$htmlf.$htmlg.$htmlh.$htmli.$htmlj.'</div></div>',
      //'#markup' => '<div class="js-var">Our JS Page</div>',
    ];

    $build['#attached']['library'][] = 'php_to_js_ajax/js_exp_two';
    $build['#attached']['drupalSettings']['js_example']['title'] = "helo";

    return $build;
  }

}
