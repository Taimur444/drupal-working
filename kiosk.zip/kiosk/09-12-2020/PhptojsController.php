<?php

namespace Drupal\php_to_js_ajax\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\views\Views;
//use Drupal\Core\Controller\Views;
//use Drupal\Views;
/**
 * Output of our JS page.
 */
class PhptojsController extends ControllerBase {

  public function PhpPage() {

    $server_time = date("H:i:s", strtotime('+5 hours'));//adding 5 hours in server time for pk time
    $z = strtotime("+30 minutes", strtotime($server_time));//adding 30 mins to server time 
    $incremented_time = date('H:i:s', $z);//converting time format 
    $div_hour =substr($server_time,0,-6);//substring te server time and get hour i.e. 11 in 11:00am
    $div_min = substr($server_time,14,2);//substring te server time and get hour i.e. 50 in 11:50am
    $flag = False; //intializing all flag variables as a False
    $flag1 = False;
    $flag2 = False;
    $flag3 = False;
    $flag4 = False; 
    $flag5 = False;
    $flag6 = False;
    $flag7 = False;
    $flag8 = False;
    $flag9 = False;
          
 //get  all meetings of current time  +1 day 
	$search_results = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
FROM
{node_field_data} node_field_data
LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') BETWEEN DATE_FORMAT('2020-12-09T18:31:28', '%Y-%m-%d\T%H:%i:%s') AND DATE_FORMAT('2020-12-10T18:31:28', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
	    
	  foreach($search_results as $result){ //foreach to get results
      if(is_numeric($result->nid)){ //get nid from $results
        $node_storage = \Drupal::entityTypeManager()->getStorage('node'); //load node
        $node = $node_storage->load($result->nid);//load node by nid
        $node_time = $node->get('field_meeting_start_time')->value;//get meeting start time field value
        $meeting_start_time= substr($node_time,11,8);//substring the field value as 18:00

         //if meeting start time is greater and equal to server time and less then incremented time i.e. 30 min + ten current time
        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag = True;  // intialize $flag as a true
          $meeting_end_time = $node->get('field_meeting_end_time')->value; // getting field value
          $next_time = substr($meeting_end_time,11,8);// substring value of meeting end time as 04:00
          	
          $div_hour =substr($server_time,0,-6); //substring hour from server time i.e 01 from 01:00
          $div_min = substr($server_time,3,2); //substring minutes from server time i.e 00 from 01:00
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }//set limit of minutes if its is between 1-30 then show 30 and if it is btw 30-60 then 59.
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmla = '<div class = "reserved">'.$div_hour.":".$div_min .'</div>';//div to post on js side
          $server_time = $next_time ; // giving meeting end time to server time.
            
        }
          
      }
    }

    if($flag == False) {  //if flag is false i.e is control dont find any meeting in current time
      $div_hour =substr($server_time,0,-6); //substring hour from server time i.e 01 from 01:00
      $div_min = substr($server_time,3,2); //substring hour from server time i.e 01 from 01:00
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }//set limit of minutes if its is between 1-30 then show 30 and if it is btw 30-60 then 59.
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmla = '<div>'.$div_hour.":".$div_min.'</div>';//post half hour div
    }

    //some comments for next 9 for each to show 9 meetings with half hour gap
/*----------------------------------------2nd time------------------------------------------------------*/
    $server_time = $incremented_time; // giving 30+ min time in curent time to server
    $a = strtotime("+30 minutes", strtotime($server_time));//add 30+ min again in server time
    $incremented_time = date('H:i:s', $a);// converting to normal
        
    foreach($search_results as $result1){
      if(is_numeric($result1->nid)){
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node1 = $node_storage->load($result1->nid);
        $node_time = $node1->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag1 = True;
          $meeting_end_time = $node1->get('field_meeting_end_time')->value;
          $next_time = substr($meeting_end_time,11,8);
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmlb = '<div class = "reserved">'.$div_hour.":".$div_min .'</div>';
          $server_time = $next_time ;
            
        }
          
      }
    }

    if($flag1 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmlb = '<div>'.$div_hour.":".$div_min.'</div>';
    }


/*----------------------------------------3rd time------------------------------------------------------*/

    $server_time = $incremented_time;
    $b = strtotime("+30 minutes", strtotime($server_time));
    $incremented_time = date('H:i:s', $b);
    
    foreach($search_results as $result2){
      if(is_numeric($result2->nid)){
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node2 = $node_storage->load($result2->nid);
        $node_time = $node2->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag2 = True;
          $meeting_end_time = $node2->get('field_meeting_end_time')->value;
          $next_time = substr($meeting_end_time,11,8);
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmlc = '<div class = "reserved">'.$div_hour.":".$div_min.'</div>';
          $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
        }
          
      }
    }

    if($flag2 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmlc = '<div>'.$div_hour.":".$div_min.'</div>';
    }

/*----------------------------------------4rth time-----------------------------------------------------*/

    $server_time = $incremented_time;
    $c = strtotime("+30 minutes", strtotime($server_time));
    $incremented_time = date('H:i:s', $c);
    foreach($search_results as $result3){
      if(is_numeric($result3->nid)){
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node3 = $node_storage->load($result3->nid);
        $node_time = $node3->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag3 = True;
          $meeting_end_time = $node3->get('field_meeting_end_time')->value;
          $next_time = substr($meeting_end_time,11,8);
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmld = '<div class = "reserved">'.$div_hour.":".$div_min .'</div>';
          $server_time = $next_time ;
            
        }
          
      }
    }

    if($flag3 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmld = '<div>'.$div_hour.":".$div_min.'</div>';
    }
/*----------------------------------------5th time------------------------------------------------------*/
    $server_time = $incremented_time;
    $d = strtotime("+30 minutes", strtotime($server_time));
    $incremented_time = date('H:i:s', $d);
        
    foreach($search_results as $result4){
      if(is_numeric($result4->nid)){
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node4 = $node_storage->load($result4->nid);
        $node_time = $node4->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag4 = True;
          $meeting_end_time = $node4->get('field_meeting_end_time')->value;
          $next_time = substr($meeting_end_time,11,8);
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmle = '<div class = "reserved">'.$div_hour.":".$div_min .'</div>';
          $server_time = $next_time ;
            
        }
          
      }
    }
    if($flag4 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmle = '<div>'.$div_hour.":".$div_min.'</div>';
    }

/*----------------------------------------6th time------------------------------------------------------*/
    $server_time = $incremented_time;
    $e = strtotime("+30 minutes", strtotime($server_time));
    $incremented_time = date('H:i:s', $e);
      
    foreach($search_results as $result5){
      if(is_numeric($result5->nid)){
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node5 = $node_storage->load($result5->nid);
        $node_time = $node5->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag5 = True;
          $meeting_end_time = $node5->get('field_meeting_end_time')->value;
          $next_time = substr($meeting_end_time,11,8);
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmlf = '<div class = "reserved">'.$div_hour.":".$div_min .'</div>';
          $server_time = $next_time ;      
        }    
      }
    }
    if($flag5 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmlf = '<div>'.$div_hour.":".$div_min.'</div>';
    }

/*----------------------------------------7th time-----------------------------------------------------*/
    $server_time = $incremented_time;
    $f = strtotime("+30 minutes", strtotime($server_time));
    $incremented_time = date('H:i:s', $f);

    foreach($search_results as $result6){
      if(is_numeric($result6->nid)){
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node6 = $node_storage->load($result6->nid);
        $node_time = $node6->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag6 = True;
          $meeting_end_time = $node6->get('field_meeting_end_time')->value;
          $next_time = substr($meeting_end_time,11,8);
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmlg = '<div class = "reserved">'.$div_hour.":".$div_min .'</div>';
          $server_time = $next_time ;  
        }
      }
    }

    if($flag6 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmlg = '<div>'.$div_hour.":".$div_min.'</div>';
    }
/*----------------------------------------8th time-----------------------------------------------------*/
    $server_time = $incremented_time;
    $g = strtotime("+30 minutes", strtotime($server_time));
    $incremented_time = date('H:i:s', $g);

    foreach($search_results as $result7){
      if(is_numeric($result7->nid)){
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node7 = $node_storage->load($result7->nid);
        $node_time = $node7->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag7 = True;
          $meeting_end_time = $node7->get('field_meeting_end_time')->value;
          $next_time = substr($meeting_end_time,11,8);
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmlh = '<div class = "reserved">'.$div_hour.":".$div_min .'</div>';
          $server_time = $next_time ;
        }
          
      }
    }
    if($flag7 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmlh = '<div>'.$div_hour.":".$div_min.'</div>';
    }
/*----------------------------------------9th time-----------------------------------------------------*/

    $server_time = $incremented_time;
    $h = strtotime("+30 minutes", strtotime($server_time));
    $incremented_time = date('H:i:s', $h);
       
    foreach($search_results as $result8){
      if(is_numeric($result8->nid)){
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node8 = $node_storage->load($result8->nid);
        $node_time = $node8->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag8 = True;
          $meeting_end_time = $node8->get('field_meeting_end_time')->value;
          $next_time = substr($meeting_end_time,11,8);
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmli = '<div class = "reserved">'.$div_hour.":".$div_min .'</div>';
          $server_time = $next_time ;
        }
      }
    }

    if($flag8 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmli = '<div>'.$div_hour.":".$div_min.'</div>';
    }
/*----------------------------------------10th time-----------------------------------------------------*/

    $server_time = $incremented_time;
    $i = strtotime("+30 minutes", strtotime($server_time));
    $incremented_time = date('H:i:s', $i);

    foreach($search_results as $result9){
      if(is_numeric($result9->nid)){
        $node_storage = \Drupal::entityTypeManager()->getStorage('node');
        $node9 = $node_storage->load($result9->nid);
        $node_time = $node9->get('field_meeting_start_time')->value;
        $meeting_start_time= substr($node_time,11,8);

        if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          $flag9 = True;
          $meeting_end_time = $node9->get('field_meeting_end_time')->value;
          $next_time = substr($meeting_end_time,11,8);
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,3,2);
          if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
          if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          $htmlj = '<div class = "reserved">'.$div_hour.":".$div_min .'</div>';
          $server_time = $next_time ;
        }
      }
    }

    if($flag9 == False) {
      $div_hour =substr($server_time,0,-6);
      $div_min = substr($server_time,3,2);
      if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
      if($div_min > 31 && $div_min < 60){ $div_min = 59; }
      $htmlj = '<div>'.$div_hour.":".$div_min. '</div>';
    } 	
/*------------------------------------------------------------------------------------------------------*/


    $viewId = 'front_screen_75_block';
    $view = Views::getView($viewId);

    if(is_object($view)) {
      $view->setDisplay('block');
      //$view->setArguments($arguments);
      $view->execute();
      // Render the view
      $result = \Drupal::service('renderer')->render($view->render());
      // return $result;   
    }

    $build = [];
    $build['content'] = [

    '#markup' => $result . $htmla.$htmlb.$htmlc.$htmld .$htmle.$htmlf.$htmlg.$htmlh.$htmli.$htmlj,
      //'#markup' => '<div class="js-var">Our JS Page</div>',
    ];

    $build['#attached']['library'][] = 'php_to_js_ajax/js_exp_two';
    $build['#attached']['drupalSettings']['js_example']['title'] = "helo";

    return $build;
  }

}
