<?php

namespace Drupal\php_to_js_ajax\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\views\Views;
//use Drupal\Core\Controller\Views;
//use Drupal\Views;
/**
 * Output of our JS page.
 */
class PhptojsController extends ControllerBase {

  public function PhpPage() {

    /*$search_results = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
     FROM
     {node_field_data} node_field_data
      LEFT JOIN {node__field_time_date} node__field_time_date ON node_field_data.nid = node__field_time_date.entity_id AND node__field_time_date.deleted = '0'
      WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_time_date.field_time_date_value, '%Y-%m-%d\T%H:%i:%s') >= DATE_FORMAT('2020-12-01T12:00:00', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");*/
      $aaa = db_query("SELECT DISTINCT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
    FROM
	{node_field_data} node_field_data
	LEFT JOIN {node__field_time_date} node__field_time_date ON node_field_data.nid = node__field_time_date.entity_id AND node__field_time_date.deleted = '0'
	INNER JOIN {node__field_loco} node__field_loco ON node_field_data.nid = node__field_loco.entity_id AND node__field_loco.deleted = '0'
		WHERE ((node__field_loco.field_loco_target_id = '1')) AND ((node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_time_date.field_time_date_value, '%Y-%m-%d\T%H:%i:%s') >= DATE_FORMAT('2020-12-02T12:00:00', '%Y-%m-%d\T%H:%i:%s'))))LIMIT 11 OFFSET 0");

    //drupal_set_message(serialize($search_results));

    foreach($as as $rfgdfg){
      //drupal_set_message(serialize($result));
      if(is_numeric($rdfgult->nid)){

          

          //$field_output = entity_view($node1->get('field_company_name')->entity, 'default');
           //$field_output2 = entity_view($node1->get('field_loco')->entity, 'default');
          //get full $_REQUEST

          //$today = date("Y-m-d");
          

          //$today_checking = date("l jS \of F Y h:i:s A") ."Fida";
         
         // $system_time = time();
          //$converted_sys_time = gmdate("H:i:s", $system_time);
          
          
        
           
          // $time_in_sec =strtotime($node_time);

           //$time = time();
          //drupal_set_message($system_time);

          
              
          //drupal_set_message($modified_node_time ."node time" );
           // && $system_time == $time_in_sec
           
          if ($node_date == $today && $converted_time == $modified_node_time  ) {
             
          }
           
      }

     
    }
 /*------------------------------------------------------------------------------------------------*/
           $server_time = date("H:i:s", strtotime('+5 hours'));
          

          $z = strtotime("+30 minutes", strtotime($server_time));
          $incremented_time = date('H:i:s', $z);
        
          $div_hour =substr($server_time,0,-6);
          $div_min = substr($server_time,14,2);
          $flag = False;
          $flag1 = False;
          $flag2 = False;
          $flag3 = False;
          $flag4 = False; 
          $flag5 = False;
          $flag6 = False;
          $flag7 = False;
          $flag8 = False;
          $flag9 = False;
          

	     $search_results = db_query("SELECT node_field_data.created AS node_field_data_created, node_field_data.nid AS nid
		FROM
	{node_field_data} node_field_data
	LEFT JOIN {node__field_meeting_start_time} node__field_meeting_start_time ON node_field_data.nid = node__field_meeting_start_time.entity_id AND node__field_meeting_start_time.deleted = '0'
		WHERE (node_field_data.status = '1') AND (node_field_data.type IN ('time')) AND ((DATE_FORMAT(node__field_meeting_start_time.field_meeting_start_time_value, '%Y-%m-%d\T%H:%i:%s') >= DATE_FORMAT('2020-12-09T11:48:02', '%Y-%m-%d\T%H:%i:%s')))LIMIT 11 OFFSET 0");
	    
		foreach($search_results as $result){
        	if(is_numeric($result->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node = $node_storage->load($result->nid);
         
          	$node_time = $node->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          	

        	 if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag = True;
          	
          	$meeting_end_time = $node->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmla = '<div class = "scroll">'.$div_hour.":".$div_min ."hi1".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmla = '<div>'.$div_hour.":".$div_min."hi2".'</div>';
        }
    /*----------------------------------------2nd time----------------------------------------------*/
        $server_time = $incremented_time;
        $a = strtotime("+30 minutes", strtotime($server_time));
        $incremented_time = date('G:i:s', $a);
        
        
        foreach($search_results as $result1){
        	if(is_numeric($result1->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node1 = $node_storage->load($result1->nid);
         
          	$node_time = $node1->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          



        	 if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag1 = True;
          	
          	$meeting_end_time = $node1->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmlb = '<div class = "scroll">'.$div_hour.":".$div_min ."hi3".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag1 == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmlb = '<div>'.$div_hour.":".$div_min."hi4".'</div>';
        }


/*----------------------------------------3rd time----------------------------------------------*/
        $server_time = $incremented_time;
        $b = strtotime("+30 minutes", strtotime($server_time));
        $incremented_time = date('G:i:s', $b);
    
       foreach($search_results as $result2){
        	if(is_numeric($result2->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node2 = $node_storage->load($result1->nid);
         
          	$node_time = $node2->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          	



        	if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag2 = True;
          	
          	$meeting_end_time = $node2->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmlc = '<div class = "scroll">'.$div_hour.":".$div_min ."hi5".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag2 == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmlc = '<div>'.$div_hour.":".$div_min."hi6".'</div>';
        }

   /*----------------------------------------4rth time----------------------------------------------*/

        $server_time = $incremented_time;
        $c = strtotime("+30 minutes", strtotime($server_time));
        $incremented_time = date('G:i:s', $c);
        
       foreach($search_results as $result3){
        	if(is_numeric($result3->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node3 = $node_storage->load($result1->nid);
         
          	$node_time = $node3->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          	



        	if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag3 = True;
          	
          	$meeting_end_time = $node3->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmld = '<div class = "scroll">'.$div_hour.":".$div_min ."hi7".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag3 == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmld = '<div>'.$div_hour.":".$div_min."hi8".'</div>';
        }
/*----------------------------------------5th time----------------------------------------------*/
        $server_time = $incremented_time;
        $d = strtotime("+30 minutes", strtotime($server_time));
        $incremented_time = date('G:i:s', $d);
        
       foreach($search_results as $result4){
        	if(is_numeric($result4->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node4 = $node_storage->load($result1->nid);
         
          	$node_time = $node4->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          	



        	if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag4 = True;
          	
          	$meeting_end_time = $node4->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmle = '<div class = "scroll">'.$div_hour.":".$div_min ."hi9".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag4 == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmle = '<div>'.$div_hour.":".$div_min."hi10".'</div>';
        }

     /*----------------------------------------6th time----------------------------------------------*/
          $server_time = $incremented_time;
        $e = strtotime("+30 minutes", strtotime($server_time));
        $incremented_time = date('G:i:s', $e);
        
       foreach($search_results as $result5){
        	if(is_numeric($result5->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node5 = $node_storage->load($result1->nid);
         
          	$node_time = $node5->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          	



        	if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag5 = True;
          	
          	$meeting_end_time = $node5->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmlf = '<div class = "scroll">'.$div_hour.":".$div_min ."hi11".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag5 == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmlf = '<div>'.$div_hour.":".$div_min."hi12".'</div>';
        }
        /*----------------------------------------7th time----------------------------------------------*/
         $server_time = $incremented_time;
        $f = strtotime("+30 minutes", strtotime($server_time));
        $incremented_time = date('G:i:s', $f);
        drupal_set_message($incremented_time ." 7th time");
       foreach($search_results as $result6){
        	if(is_numeric($result6->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node6 = $node_storage->load($result6->nid);
         
          	$node_time = $node6->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          	



        	if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag6 = True;
          	
          	$meeting_end_time = $node6->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmlg = '<div class = "scroll">'.$div_hour.":".$div_min ."hi13".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag6 == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmlg = '<div>'.$div_hour.":".$div_min."hi14".'</div>';
        }
        /*----------------------------------------8th time----------------------------------------------*/
          $server_time = $incremented_time;
        $g = strtotime("+30 minutes", strtotime($server_time));
        $incremented_time = date('G:i:s', $g);
        drupal_set_message($incremented_time ." 8th time");
       foreach($search_results as $result7){
        	if(is_numeric($result7->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node7 = $node_storage->load($result7->nid);
         
          	$node_time = $node7->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          	



        	if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag7 = True;
          	
          	$meeting_end_time = $node7->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmlh = '<div class = "scroll">'.$div_hour.":".$div_min ."hi15".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag7 == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmlh = '<div>'.$div_hour.":".$div_min."hi16".'</div>';
        }
        /*----------------------------------------9th time----------------------------------------------*/

         $server_time = $incremented_time;
        $h = strtotime("+30 minutes", strtotime($server_time));
        $incremented_time = date('G:i:s', $h);
        drupal_set_message($incremented_time ." 9th time");
       foreach($search_results as $result8){
        	if(is_numeric($result8->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node8 = $node_storage->load($result8->nid);
         
          	$node_time = $node8->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          	



        	if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag8 = True;
          	
          	$meeting_end_time = $node8->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmli = '<div class = "scroll">'.$div_hour.":".$div_min ."hi17".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag8 == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmli = '<div>'.$div_hour.":".$div_min."hi18".'</div>';
        }
      /*----------------------------------------10th time----------------------------------------------*/
      $server_time = $incremented_time;
        $i = strtotime("+30 minutes", strtotime($server_time));
        $incremented_time = date('G:i:s', $i);
        drupal_set_message($incremented_time ." 10th time");
       foreach($search_results as $result9){
        	if(is_numeric($result9->nid)){
        	
          	$node_storage = \Drupal::entityTypeManager()->getStorage('node');
          	$node9 = $node_storage->load($result9->nid);
         
          	$node_time = $node9->get('field_meeting_start_time')->value;
          	$meeting_start_time= substr($node_time,11,8);
          	



        	if($meeting_start_time >= $server_time && $meeting_start_time <= $incremented_time){
          	
          	$flag9 = True;
          	
          	$meeting_end_time = $node9->get('field_meeting_end_time')->value;
          	$next_time = substr($meeting_end_time,11,8);
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min > 1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
            $htmlj = '<div class = "scroll">'.$div_hour.":".$div_min ."hi21".'</div>';
            $server_time = $next_time ;
            //drupal_set_message($server_time."new server time");
             
              }
          
            }
        }
        if($flag9 == False) {
          	
          	$div_hour =substr($server_time,0,-6);
          	$div_min = substr($server_time,3,2);
          	if ($div_min >1 && $div_min < 30 ){ $div_min = 30; }
            if($div_min > 31 && $div_min < 60){ $div_min = 59; }
          	$htmlj = '<div>'.$div_hour.":".$div_min."hi20".'</div>';
         } 	
/*---------------------------------------------------------------------------*/
    $viewId = 'front_screen_75_block';
    $view = Views::getView($viewId);
    if(is_object($view)) {
      $view->setDisplay('block');
      //$view->setArguments($arguments);
      $view->execute();
      // Render the view
      $result = \Drupal::service('renderer')->render($view->render());
      // return $result;   
     }
     $build = [];
    $build['content'] = [

      '#markup' => $result . $htmla.$htmlb.$htmlc.$htmld .$htmle.$htmlf.$htmlg.$htmlh.$htmli.$htmlj,
      //'#markup' => '<div class="js-var">Our JS Page</div>',
    ];
    $build['#attached']['library'][] = 'php_to_js_ajax/js_exp_two';
    $build['#attached']['drupalSettings']['js_example']['title'] = "helo";

    return $build;
  }

}
