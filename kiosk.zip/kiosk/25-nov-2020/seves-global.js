/**
 * @file
 * Global utilities.
 *
 */
jQuery(document).ready(function() {
		jQuery( ".block-block-content0c30f63d-699f-4819-8d43-9fb57c625c4b, .block-block-content9defa65e-335c-423c-99fa-3043c21bba59, .block-block-content5a8c0031-746b-4cb0-ac39-f76b5382aa34" ).wrapAll( "<div class='material' /><div class='container' /><div class='row glass-block' />");
		jQuery( ".block-block-content0c30f63d-699f-4819-8d43-9fb57c625c4b").wrapAll( "<div class='col-md-4' />");
		jQuery( ".block-block-content9defa65e-335c-423c-99fa-3043c21bba59").wrapAll( "<div class='col-md-4' />");
		jQuery( ".block-block-content5a8c0031-746b-4cb0-ac39-f76b5382aa34").wrapAll( "<div class='col-md-4' />");
		jQuery('.block-views-blockhomepage-taxonomy-block-1').wrap('<div class="container" />')
		jQuery(".block-views-blockhomepage-taxonomy-block-1 .homepage-vocabulary").prependTo(".block-views-blockhomepage-taxonomy-block-1 .view-content.row");
		jQuery(".block-views-blockhomepage-taxonomy-block-1 .homepage-vocabulary").wrap("<div class='col-lg-2' />")
		jQuery(".block-views-blockhomepage-taxonomy-block-1 .view-content.row .views-row").wrapAll("<div class='col-lg-10' />")
		jQuery(".homepage-vocabulary .vocab").eq(0).addClass('active');
		jQuery('.block-views-blockhomepage-taxonomy-block-1 .view-content .col-lg-10 .views-row').wrapAll('<div class="application" />')
		jQuery('.block-views-blockhomepage-taxonomy-block-2 .view-content .views-row').appendTo('.block-views-blockhomepage-taxonomy-block-1 .view-content .col-lg-10').wrapAll('<div class="pattern" />')

		jQuery('.block-views-blockhomepage-taxonomy-block-3 .view-content .views-row').appendTo('.block-views-blockhomepage-taxonomy-block-1 .view-content .col-lg-10').wrapAll('<div class="shape" />')
		jQuery('.block-views-blockhomepage-taxonomy-block-4 .view-content .views-row').appendTo('.block-views-blockhomepage-taxonomy-block-1 .view-content .col-lg-10').wrapAll('<div class="color" />')
		jQuery('.pattern, .shape, .color').hide()

		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:first-Child a').empty().attr('title','Facebook');
		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:first-Child a').append('<i class="fa fa-facebook" aria-hidden="true"></i>');

		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(2) a').empty().attr('title','Twitter');
		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(2) a').append('<i class="fa fa-twitter" aria-hidden="true"></i>');

		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(3) a').empty().attr('title','Pinterest');
		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(3) a').append('<i class="fa fa-pinterest-p" aria-hidden="true"></i>');

		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(4) a').empty().attr('title','Instagram');
		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(4) a').append('<i class="fa fa-instagram" aria-hidden="true"></i>');

		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(5) a').empty().attr('title','Houzz');
		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(5) a').append('<i class="fa fa-houzz" aria-hidden="true"></i>');

		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(6) a').empty().attr('title','Linkedin');
		jQuery('#navbar-top ul[block="block-socialmediaicons"] li:nth-Child(6) a').append('<i class="fa fa-linkedin" aria-hidden="true"></i>');





		jQuery('#edit-submit-blocks, #header button, #edit-submit-blog, #edit-submit-blocks--2').empty().append('<i class="fa fa-search" aria-hidden="true"></i>');
		jQuery('.form-item-search-api-fulltext input').attr('placeholder','Search');
    jQuery('.view-blog .form-item-search-api-fulltext input').attr('placeholder','');
		jQuery('#views-exposed-form-blocks-block-1 label, .button--ultimenu, .form-item-search-api-fulltext .description').remove();
		jQuery('#block-socialmediaicons-2 ul li:first-Child a').prepend('<i class="fa fa-facebook" aria-hidden="true"></i>');
		jQuery('#block-socialmediaicons-2 ul li:nth-Child(2) a').prepend('<i class="fa fa-twitter" aria-hidden="true"></i>');
		jQuery('#block-socialmediaicons-2 ul li:nth-Child(3) a').prepend('<i class="fa fa-pinterest-p" aria-hidden="true"></i>');
		jQuery('#block-socialmediaicons-2 ul li:nth-Child(4) a').prepend('<i class="fa fa-instagram" aria-hidden="true"></i>');
		jQuery('#block-socialmediaicons-2 ul li:nth-Child(5) a').prepend('<i class="fa fa-houzz" aria-hidden="true"></i>');
		jQuery('#block-socialmediaicons-2 ul li:nth-Child(6) a').prepend('<i class="fa fa-linkedin" aria-hidden="true"></i>');
		jQuery('#block-block-contenta9bc2090-a6ce-4ad1-bdaf-0208cd85b29a br').remove();
		jQuery('.vocab-application').click(function(){
				jQuery(".homepage-vocabulary .vocab").removeClass('active');
				jQuery(".homepage-vocabulary .vocab").eq(0).addClass('active');
				jQuery('.application').show()
				jQuery('.pattern, .shape, .color').hide()
		})

		jQuery('.vocab-pattern').click(function(){
				jQuery(".homepage-vocabulary .vocab").removeClass('active');
				jQuery(".homepage-vocabulary .vocab").eq(1).addClass('active');
				jQuery('.pattern').show()
				jQuery('.application, .shape, .color').hide()
		})

		jQuery('.vocab-shape').click(function(){
				jQuery(".homepage-vocabulary .vocab").removeClass('active');
				jQuery(".homepage-vocabulary .vocab").eq(2).addClass('active');
				jQuery('.shape').show()
				jQuery('.pattern, .application, .color').hide()
		})

		jQuery('.vocab-color').click(function(){
				jQuery(".homepage-vocabulary .vocab").removeClass('active');
				jQuery(".homepage-vocabulary .vocab").eq(3).addClass('active');
				jQuery('.color').show()
				jQuery('.pattern, .shape, .application').hide()
		})


		jQuery('.site-footer .container-fluid').addClass('container').removeClass('container-fluid');
		jQuery('.site-footer .container').addClass('foolter-logo');
		jQuery("#block-logo, .block-footerfifthmenu, .block-footerfifthmenu2").unwrap();
		jQuery("#edit-name--2").attr("placeholder", "NAME");
		jQuery("#edit-email").attr("placeholder", "EMAIL");
    jQuery(".form-item-email #edit-email").attr("placeholder", "");
		jQuery('#block-socialmediaicons .nav-item a').attr('target','_blank');
		jQuery('#block-socialmediaicons-2 .nav-item a').attr('target','_blank');
		jQuery('.nav-link-https--wwwsevescom-').attr('target','_blank');
		jQuery(".foolter-logo .region").removeClass('row');
		jQuery(".block-block-content0ef1b5f0-8e68-479e-a478-a4ddd13a1b6a .block-field-blockblock-contentimage-blocksbody .field__item p:first-Child").remove();
		jQuery(".block-block-content0ef1b5f0-8e68-479e-a478-a4ddd13a1b6a h2").after('<p>Subcopy style if needed.</p>')
		jQuery(".block-block-content0ef1b5f0-8e68-479e-a478-a4ddd13a1b6a .block-field-blockblock-contentimage-blocksbody .field__item").wrap('<div class="container" />')
		var elems = jQuery(".block-block-content0ef1b5f0-8e68-479e-a478-a4ddd13a1b6a .block-field-blockblock-contentimage-blocksbody .field__item p");
		var wrapper = jQuery('<div class="performance" />');
		var pArrLen = elems.length;
		for (var i = 0;i < pArrLen;i+=2){
			elems.filter(':eq('+i+'),:eq('+(i+1)+')').wrapAll(wrapper);
		};
		jQuery('.block-block-contenta9bc2090-a6ce-4ad1-bdaf-0208cd85b29a').wrap('<div class="container" />');
		jQuery('.block-block-contenta9bc2090-a6ce-4ad1-bdaf-0208cd85b29a .field__item h2, .block-block-contenta9bc2090-a6ce-4ad1-bdaf-0208cd85b29a .field__item p:last-child').wrapAll('<div class="wrap-text" />')

		jQuery('.block-block-content64009fc7-c64e-454b-96cb-d278471f4623 .content .field__item').wrapAll('<div class="container" />')
		jQuery('.bring-left, .bring-right').wrapAll('<div class="row justify-content-center" />')
		jQuery('.bring-left').wrap('<div class="col-lg-5 col-md-6" />');
		jQuery('.bring-right').wrap('<div class="col-lg-5 col-md-6" />')
		jQuery('.bring-left .bring-text p, .bring-left .bring-text img').remove();
		jQuery('.bring-right h5,.bring-right h3,.bring-right p').wrapAll('<div class="bring-text" />');
		//jQuery('.bring-right h1').replaceWith('<h3>Award-Winning Municipal Infrastructure Building in Edmonton, Canada</h3>');
		jQuery('#block-glassblock-3,#block-glassblock2ndmenu, #block-glassblockmenuimage-2').wrapAll('<div class="row" />')
		jQuery('#block-accessories, #block-accessoriesmenuimage').wrapAll('<div class="row" />');
		jQuery('#block-lwarchitecturalsystems-2, #block-lwarchitecturalsystems').wrapAll('<div class="row" />');
		jQuery('#block-glassblock-3').wrap('<div class="col-md-3 block-glassblock-3" />');
		jQuery('#block-glassblock2ndmenu').wrap('<div class="col-md-6" />');
		jQuery('#block-glassblockmenuimage-2').wrap('<div class="col-md-3" />');
		jQuery('#block-accessories').wrap('<div class="col-md-8" />');
		jQuery('#block-accessoriesmenuimage').wrap('<div class="col-md-4" />');
		jQuery('#block-lwarchitecturalsystems-2').wrap('<div class="col-md-8" />');
		jQuery('#block-lwarchitecturalsystems').wrap('<div class="col-md-4" />');

		var boundary = jQuery("#header #block-glassblock-3 .menu-item--expanded .menu li:nth-Child(5)");
		jQuery("<ul class='menu'>").insertAfter(boundary.parent()).append(boundary.nextAll().addBack());

		jQuery('#block-accessories .nav > li:nth-Child(4) > a, #block-accessories .nav > li:nth-Child(4) > ul').wrapAll('<div class="vents" />')
		jQuery('.vents').appendTo('#block-accessories .nav > li:nth-Child(3)');
		jQuery('#block-glassblock2ndmenu > .nav > li:nth-Child(3) span, #block-glassblock2ndmenu > .nav > li:nth-Child(3) .menu').wrapAll('<div class="sizing" />')
		jQuery('.sizing').appendTo('#block-glassblock2ndmenu > .nav > li:nth-Child(2)');
		jQuery('#block-glassblock2ndmenu > .nav > li:nth-Child(5) span, #block-glassblock2ndmenu > .nav > li:nth-Child(5) .menu').wrapAll('<div class="colors" />')
		jQuery('.colors').appendTo('#block-glassblock2ndmenu > .nav > li:nth-Child(4)');
		jQuery('#block-lwarchitecturalsystems-2').prepend('<h3>LightWise<sup>&reg;</sup> Architectural Systems</h3><p>Solutions for commercial projects that need high performance systems</p>')



		jQuery('button.navbar-toggler').append('<i class="fa fa-bars" aria-hidden="true"></i>')
		jQuery('button.navbar-toggler .navbar-toggler-icon').remove();


		jQuery('.block-inline-blockbasic ~ div.block-views-exposed-filter-blockblocks-block-1').addClass('search-box')
		jQuery('#search-text, .search-box').wrapAll('<div class="search-card" />');
		jQuery('#block-seves-content .layout--twocol-section--25-75').addClass('container search-content');
                jQuery('.node--type-product-line-color-subsection .section-main-content').addClass('container search-content');
		jQuery('.search-card~.block-facet--links').addClass('container navigation');
		jQuery('.search-content .layout__region--second .views-row').addClass('col-lg-3 col-md-4')
		jQuery('.search-content .block-facet-blockcolor-taxonomy-term-color-block-2- ul li a span,.search-content .pager__item--next, .search-content .block-facet-blockcolor-taxonomy-term-name ul li a span, .search-content .js-pager__items li a[title="Go to last page"] span, .search-content .js-pager__items li a[title="Go to previous page"], .search-content .js-pager__items li a[title="Go to first page"] span').remove();
		jQuery('.search-content .layout__region--second').addClass('col-lg-9')
		jQuery('.search-content .layout__region--first').addClass('col-lg-3')
		jQuery('.search-content .js-pager__items li a[title="Go to last page"]').append('<i class="fa fa-caret-right" aria-hidden="true"></i>');
		jQuery('.search-content .js-pager__items li a[title="Go to first page"]').append('<i class="fa fa-caret-left" aria-hidden="true"></i>');
		jQuery('.search-content .js-pager__items li a[title="Go to last page"], .search-content .js-pager__items li a[title="Go to first page"]').css('font-size','30px');
		if(jQuery('.search-content .js-pager__items li:first-child').hasClass('active')){
			jQuery('.search-content .js-pager__items').prepend('<li class="page-item"><i class="fa fa-caret-left" aria-hidden="true"></i></li>')
			jQuery('.search-content .js-pager__items li:first-child').css({'font-size':'30px','margin-right':'15px','color':'#CCC'});
		}
		jQuery('.page-node-9 .layout__region--first h2,.page-node-10 .layout__region--first h2').click(function(){
			jQuery(this).next('.content').slideToggle('slow');
			jQuery(this).toggleClass('slide-collapsed')
		})
		setTimeout(function(){
		jQuery('.page-node-9 .layout__region--first .item-list__checkbox .facet-item, .page-node-10 .layout__region--first .item-list__checkbox .facet-item').each(function (i,val) {

			jQuery(val).find('.facets-checkbox').prependTo(jQuery(val).find('label'));
			jQuery(val).find('.facets-checkbox').after('<span class="checkmark"></span>')

			if(!jQuery(this).find('.facet-item__value').text().indexOf('Off')){

			jQuery(this).find('.facet-item__value').parent().parent().remove();
		}

		})
		},2000)

		setTimeout(function(){
		jQuery('.page-node-10 #block-seves-content .total').wrap('<div class="container" />');
		},1000)

		var colorList = jQuery('.search-content .block-facet-blockcolor-taxonomy-term-color-block-2- ul li, .search-content .block-facet-blockcolor-taxonomy-term-name ul li');

		for(var i=0;i<colorList.length;i++){
		var backColor = jQuery(colorList[i]).find('a').attr('data-drupal-facet-item-value');
		if(backColor=='#FFFFFF'){
		jQuery(colorList[i]).find('a').css({'background':backColor})
		} else {
			jQuery(colorList[i]).find('a').css({'background':backColor,'border-color':backColor})
		}
		}
		jQuery('.search-content .form-item-sort-by').append('<label class="custom-sort-select">Sort by: <strong>A-Z</strong>&nbsp;&nbsp;&nbsp;<i class="fa fa-angle-down" aria-hidden="true"></i></label>');
		jQuery('.search-content .form-item-sort-by #edit-sort-by--3').remove();
		jQuery('.search-content .form-item-sort-by #edit-sort-by--4').remove();


		jQuery('.page-node-4523 .field--name-field-banner-links a[href="/how-to-buy"], .page-node-4524 .field--name-field-banner-links a[href="/how-to-buy"], .page-node-4525 .field--name-field-banner-links a[href="/how-to-buy"], .page-node-4526 .field--name-field-banner-links a[href="/how-to-buy"]').removeClass('btn-small').addClass('btn-medium');

		/*===================  Node 12 ===========================*/

		jQuery('.page-node-12 .node__content .layout__region .block-field-blocknodepagebody:not(:first-child),.page-node-12 .node__content .layout__region .block-facet-blockresources-for,.page-node-12 .node__content .layout__region .block-facet-blockproduct-line-or-collection,.page-node-12 .node__content .layout__region .block-facet-blocktechnical-document,.page-node-12 .node__content .layout__region .block-views-blockresources-block-1,.page-node-12 .node__content .layout__region .block-views-blockresources-block-2').wrapAll('<div class="container" />')

		jQuery('.page-node-12  .node__content .layout__region .block-block-content421d35b0-c858-49cd-82ce-68f9a4bae455').insertAfter('.page-node-12 .node__content .layout__region > .block-field-blocknodepagebody');

		/* Wrapper for Resource Page Header */
		jQuery('.page-node-12 .layout__region--content > .block-field-blocknodepagebody,.page-node-12 .layout__region--content > .block-field-blocknodepagebody~.block-block-content421d35b0-c858-49cd-82ce-68f9a4bae455').wrapAll('<div class="banner-node-12"/><div class="inner"/>');

		jQuery('.page-node-12 .container > .block-field-blocknodepagebody').addClass('mt-3');
		jQuery('.page-node-12 .block-facet--dropdown').wrapAll('<div class="row" />');
		jQuery('.page-node-12 .block-facet--dropdown').addClass('col-xl-3 col-lg-4 col-md-6');
		jQuery('.page-node-12 .block-facet--dropdown select').addClass('form-control');
		jQuery('.page-node-12 .container .block-views-blockresources-block-1').addClass('mt-5 mb-5');
		jQuery('.page-node-12 .container .block-views-blockresources-block-1 .row .views-row:nth-child(-n4),.page-node-12 .container .block-views-blockresources-block-2 .row .views-row:nth-child(-n4)').addClass('col-md-12 mb-4');
		jQuery('.page-node-12 .container .block-views-blockresources-block-1 .row .views-row:nth-child(n5),.page-node-12 .container .block-views-blockresources-block-2 .row .views-row:nth-child(n5)').addClass('col-md-12 mb-4');
		jQuery('.page-node-12 .require-login p').prepend('<i class="fa fa-diamond" aria-hidden="true"></i> ');
		if(jQuery('.page-node-12 .requires-registration a').length > 0){
			jQuery('.page-node-12 .requires-registration a').append(' <i class="fa fa-diamond" aria-hidden="true"></i> ');
			} else {
				jQuery('.page-node-12 .requires-registration').append(' <i class="fa fa-diamond" aria-hidden="true"></i> ');
			}
		jQuery('.page-node-12 .view-id-resources .view-filters').insertBefore('.page-node-12 .container > .row > .block-facet-blockresources-for');
		jQuery('.page-node-12 .container > .row > .view-filters').wrap('<div class="col-md-3" />');
		jQuery('.page-node-12 #edit-submit-resources--2,.page-node-12 #edit-submit-resources--4').text('');
		jQuery('.page-node-12 #edit-submit-resources--2,.page-node-12 #edit-submit-resources--4').append('<i class="fa fa-search" aria-hidden="true"></i>');
		jQuery('.block-views-exposed-filter-blockresources-block-1 h2').remove();
		jQuery('.page-node-12 .block-views-exposed-filter-blockresources-block-1').insertBefore('.page-node-12 .container > .mt-3 ~ .row >  .block-facet-blockresources-for');
		jQuery('.page-node-12 .container > .mt-3 ~ .row > .block-views-exposed-filter-blockresources-block-1').wrap('<div class="col-xl-3 col-lg-4 col-md-6" />');
		jQuery('.banner-node-12 .block-field-blocknodepagebody').addClass('container');

		jQuery('.page-node-12 .container .block-facet-blockresources-for select,.page-node-12 .container .block-facet-blockproduct-line-or-collection select,.page-node-12 .container .block-facet-blocktechnical-document select,.page-node-12 .container .block-facet-blockresource-for-2 select,.page-node-12 .container .block-facet-blockproduct-line-or-collection-2 select,.page-node-12 .container .block-facet-blocktechnical-document-2 select').on('change',function(){
			setTimeout(function(){

			jQuery('.page-node-12 .container .block-views-blockresources-block-1 .row .views-row,.page-node-12 .container .block-views-blockresources-block-2 .row .views-row').addClass('col-md-12 mb-4');
			if(jQuery('.page-node-12 .requires-registration a').length > 0){
			jQuery('.page-node-12 .requires-registration a').append(' <i class="fa fa-diamond" aria-hidden="true"></i> ');
			} else {
				jQuery('.page-node-12 .requires-registration').append(' <i class="fa fa-diamond" aria-hidden="true"></i> ');
			}

			},1600)
		})
		jQuery('.page-node-12 #edit-submit-resources--4,.page-node-12 #edit-submit-resources--2').on('click',function(){
			setTimeout(function(){

			jQuery('.page-node-12 .container .block-views-blockresources-block-1 .row .views-row,.page-node-12 .container .block-views-blockresources-block-2 .row .views-row').addClass('col-md-12 mb-4');
			if(jQuery('.page-node-12 .requires-registration a').length > 0){
			jQuery('.page-node-12 .requires-registration a').append(' <i class="fa fa-diamond" aria-hidden="true"></i> ');
			} else {
				jQuery('.page-node-12 .requires-registration').append(' <i class="fa fa-diamond" aria-hidden="true"></i> ');
			}
			},1600)
		})


		jQuery('#edit-search-api-fulltext--2, #edit-search-api-fulltext--4').keypress(function (e) {
		 var key = e.which;
		 if(key == 13)  // the enter key code
		  {
			setTimeout(function(){

			jQuery('.page-node-12 .container .block-views-blockresources-block-1 .row .views-row,.page-node-12 .container .block-views-blockresources-block-2 .row .views-row').addClass('col-md-12 mb-4');
			if(jQuery('.page-node-12 .requires-registration a').length > 0){
			jQuery('.page-node-12 .requires-registration a').append(' <i class="fa fa-diamond" aria-hidden="true"></i> ');
			} else {
				jQuery('.page-node-12 .requires-registration').append(' <i class="fa fa-diamond" aria-hidden="true"></i> ');
			}
			},1600)
		  }
		});

		/*===================  Node 100 ===========================*/

		jQuery('#glassBlockCarousel').click(function(){
			setTimeout(function(){
		jQuery('.page-node-5373 #cboxClose,.page-node-100 #cboxPrevious,.page-node-100 #cboxNext,.page-node-100 #cboxClose,.page-node-100 #cboxCurrent').empty();

		jQuery('.page-node-100 #cboxClose,.page-node-5373 #cboxClose').append('X');
		jQuery('.page-node-100 #cboxClose,.page-node-5373 #cboxClose').css('opacity','1');
			},500)
		});

		jQuery('.page-node-100,.page-node-5373').on('click','#cboxNext',function(){
			jQuery('.page-node-5373 #cboxClose,.page-node-100 #cboxPrevious,.page-node-100 #cboxNext,.page-node-100 #cboxClose,.page-node-100 #cboxCurrent').css('opacity','0');
			setTimeout(function(){
		jQuery('.page-node-5373 #cboxClose,.page-node-100 #cboxPrevious,.page-node-100 #cboxNext,.page-node-100 #cboxClose,.page-node-100 #cboxCurrent').empty();

		jQuery('.page-node-100 #cboxClose,.page-node-5373 #cboxClose').append('X');
		jQuery('.page-node-100 #cboxClose,.page-node-5373 #cboxClose').css('opacity','1');
			},500)
		});

		jQuery('.page-node-100,.page-node-5373').on('click','#cboxPrevious',function(){
			jQuery('.page-node-5373 #cboxClose,.page-node-100 #cboxPrevious,.page-node-100 #cboxNext,.page-node-100 #cboxClose,.page-node-100 #cboxCurrent').css('opacity','0');
			setTimeout(function(){
		jQuery('.page-node-5373 #cboxClose,.page-node-100 #cboxPrevious,.page-node-100 #cboxNext,.page-node-100 #cboxClose,.page-node-100 #cboxCurrent').empty();

		jQuery('.page-node-100 #cboxClose,.page-node-5373 #cboxClose').append('X');
		jQuery('.page-node-100 #cboxClose,.page-node-5373 #cboxClose').css('opacity','1');
			},500)
		});

		if (window.matchMedia('(max-width:480px)').matches) {
			jQuery('#ultimenu-main').append('<li class="ultimenu__item uitem"><a href="/seves/about" class="ultimenu__link">About</a></li><li class="ultimenu__item uitem"><a href="/seves/contact" class="ultimenu__link">Contact</a></li><li class="ultimenu__item uitem"><a href="https://www.seves.com/" class="ultimenu__link">Global Site</a></li>')


			jQuery('.ultimenu__link span').remove()
			jQuery('.ultimenu__link~.ultimenu__flyout').remove();
			jQuery('#block-exposedformblocksblock-1').insertAfter('.navbar-brand');

			jQuery('.view-content .slick').slick({slidesToShow: 1,slidesToScroll: 1})





			jQuery('.navbar-toggler').click(function(){
			if(jQuery('.navbar-toggler').attr('aria-expanded')=='false'){

				jQuery('.navbar-toggler i').removeClass('fa-bars').addClass('fa-times')
				jQuery('#block-socialmediaicons').css({'zIndex':'0'})

			} else {

				jQuery('.navbar-toggler i').removeClass('fa-times').addClass('fa-bars')
				jQuery('#block-socialmediaicons').css({'zIndex':'2'})

			}

			});


			//jQuery('.path-frontpage .block-field-blocknodepagebody .field__item h3').remove();
			//jQuery('.path-frontpage .block-field-blocknodepagebody .field__item').append('<h3>More Patterns.</h3><h3>More Colors.</h3><h3>More Shapes and Sizes.</h3><h3>More Choices.</h3>')

		}
		if (window.matchMedia('(min-width:481px) and (max-width: 991px)')) {
			jQuery('#block-exposedformblocksblock-1').insertAfter('#navbar-main > a')

			jQuery('.navbar-toggler').click(function(){
			if(jQuery('.navbar-toggler').attr('aria-expanded')=='false'){

				jQuery('.navbar-toggler i').removeClass('fa-bars').addClass('fa-times')

			} else {

				jQuery('.navbar-toggler i').removeClass('fa-times').addClass('fa-bars')

			}
			});

			/* Search page */

			jQuery('.page-node-9 .container, .page-node-10 .container').removeClass('layout--twocol-section--25-75');

		}




		if ((window.matchMedia('(min-width:992px)').matches)) {
			jQuery('#block-exposedformblocksblock-1').insertAfter('#CollapsingNavbar')

		}

		if (window.matchMedia('(max-width:991px)').matches) {

			if(jQuery('.vocab-application').hasClass('active')){
				jQuery('.application').hide()
				jQuery('.vocab-application').removeClass('active');
			}

			if(jQuery('.vocab-application').hasClass('active')){
				jQuery('.application').hide()
				jQuery('.vocab-application').removeClass('active');
			}

			jQuery('.vocab-application').click(function(){
				jQuery('.application').insertAfter('.vocab-application').slideDown("slow")
			})
			jQuery('.vocab-pattern').click(function(){
				jQuery('.pattern').insertAfter('.vocab-pattern').slideDown("slow")
			})
			jQuery('.vocab-shape').click(function(){
				jQuery('.shape').insertAfter('.vocab-shape').slideDown("slow")
			})
			jQuery('.vocab-color').click(function(){
				jQuery('.color').insertAfter('.vocab-color').slideDown("slow")
			})

		jQuery('#header .navbar-toggler-right i:first-Child').remove();





		if(jQuery('.path-frontpage .form-item-search-api-fulltext input, .page-node-10 .form-item-search-api-fulltext #edit-search-api-fulltext--4, .page-node-9 .form-item-search-api-fulltext #edit-search-api-fulltext--2').val()==''){
			jQuery('.path-frontpage #edit-submit-blocks, #edit-submit-blocks--4, #edit-submit-blocks--2').attr('type','button')
			jQuery('.path-frontpage #edit-submit-blocks, #edit-submit-blocks--4, #edit-submit-blocks--2').click(function(){
				if(jQuery('.path-frontpage .form-item-search-api-fulltext input, .page-node-10 .form-item-search-api-fulltext #edit-search-api-fulltext--4, .page-node-9 .form-item-search-api-fulltext #edit-search-api-fulltext--2').val()!=''){
					jQuery('.path-frontpage #edit-submit-blocks, #edit-submit-blocks--4, #edit-submit-blocks--2').attr('type','submit')
				}
				jQuery('.path-frontpage .form-item-search-api-fulltext input, .page-node-10 .form-item-search-api-fulltext #edit-search-api-fulltext--4, .page-node-9 .form-item-search-api-fulltext #edit-search-api-fulltext--2').toggle()



				if(jQuery('.path-frontpage .form-item-search-api-fulltext input, .page-node-10 .form-item-search-api-fulltext #edit-search-api-fulltext--4, .page-node-9 .form-item-search-api-fulltext #edit-search-api-fulltext--2').css('display')=='none'){
				jQuery('.path-frontpage #edit-submit-blocks, #edit-submit-blocks--4, #edit-submit-blocks--2').css({})
				} else if(jQuery('.path-frontpage .form-item-search-api-fulltext input, .page-node-10 .form-item-search-api-fulltext #edit-search-api-fulltext--4, .page-node-9 .form-item-search-api-fulltext #edit-search-api-fulltext--2').css('display')=='inline-block'){
					jQuery('.path-frontpage #edit-submit-blocks, #edit-submit-blocks--4, #edit-submit-blocks--2').css({})

					jQuery('.path-frontpage .form-item-search-api-fulltext input, .page-node-10 .form-item-search-api-fulltext #edit-search-api-fulltext--4, .page-node-9 .form-item-search-api-fulltext #edit-search-api-fulltext--2').css({'width':'235px'})

				}
			});
			} else {
				jQuery('.path-frontpage #edit-submit-blocks, #edit-submit-blocks--4, #edit-submit-blocks--2').attr('type','submit')
			}







		}

	jQuery('#block-footerfifthmenu').appendTo('#block-footeraddressblock');

	jQuery(window).on('resize', function(){

		jQuery('.slick-prev, .slick-next').empty();
		jQuery('.navbar-brand').text().substring(3,-3)

	})
	setTimeout(function(){
		jQuery('.slick-prev, .slick-next').empty();
		jQuery('.navbar-brand').text().substring(3,-3)
	},1000)
	jQuery('.view-id-inspiration.view-display-id-block_1 .view-content').slick({
	  infinite: true,
	  speed: 300,
	  slidesToShow: 3,
	  slidesToScroll: 3,
          variableWidth: true,

	  responsive: [
		{
		  breakpoint: 1024,
		  settings: {
			slidesToShow: 3,
			slidesToScroll: 3
		  }
		},
		{
		  breakpoint: 600,
		  settings: {
			slidesToShow: 2,
			slidesToScroll: 2
		  }
		},
		{
		  breakpoint: 480,
		  settings: {
			slidesToShow: 1,
			slidesToScroll: 1
		  }
		}
		// You can unslick at a given breakpoint now by adding:
		// settings: "unslick"
		// instead of a settings object
	  ]
	});

	jQuery('body').append('<a href="#" class="back-to-top"><i class="fa fa-sort-asc" aria-hidden="true"></i></a>');

	jQuery(window).scroll(function(){
        if (jQuery(this).scrollTop() > 100) {
            jQuery('.back-to-top').fadeIn();
        } else {
            jQuery('.back-to-top').fadeOut();
        }
    });


    jQuery('.back-to-top').click(function(){
        jQuery('html, body').animate({scrollTop : 0},800);
        return false;
    });

// For Taxonomy Page Color Subsection Filter *SAL*
  	let navigator = ".page-vocabulary-series-line .series-line-subsection-navigator";
  	jQuery(navigator).find('.field-content').eq(0).addClass('active');

  	jQuery(".page-vocabulary-series-line .views-element-container .view-content")
  	.find('.view-grouping').eq(0).wrapAll('<a name="filter-group-1" class="filter-group-1"></a>');
  	jQuery(".page-vocabulary-series-line .views-element-container .view-content")
  	.find('.view-grouping').eq(1).wrapAll('<a name="filter-group-2" class="filter-group-2"></a>');
  	jQuery(".page-vocabulary-series-line .views-element-container .view-content")
  	.find('.view-grouping').eq(2).wrapAll('<a name="filter-group-3" class="filter-group-3"></a>');
  	jQuery(".page-vocabulary-series-line .views-element-container .view-content")
  	.find('.view-grouping').eq(3).wrapAll('<a name="filter-group-4" class="filter-group-4"></a>');
  	jQuery(".page-vocabulary-series-line .views-element-container .view-content")
  	.find('.view-grouping').eq(4).wrapAll('<a name="filter-group-5" class="filter-group-5"></a>');
  	jQuery(".page-vocabulary-series-line .vocabulary-series-line .content")
  	.find('.layout--onecol').eq(0).wrapAll('<div class="title-description" />');

  	jQuery(navigator)
  	.find('.field-content').eq(0)
  	.click(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	})
  	.mouseover(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	}),
  	jQuery(navigator)
  	.find('.field-content').eq(1)
  	.click(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	})
  	.mouseover(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	}),
  	jQuery(navigator)
  	.find('.field-content').eq(2)
  	.click(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	})
  	.mouseover(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	}),
  	jQuery(navigator)
  	.find('.field-content').eq(3)
  	.click(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	})
  	.mouseover(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	}),
  	jQuery(navigator)
  	.find('.field-content').eq(4)
  	.click(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	})
  	.mouseover(function() {
          jQuery(navigator).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	});


  	jQuery('.page-vocabulary-series-line .layout--threecol-section').addClass('row')
  	jQuery('.page-vocabulary-series-line .layout--threecol-section .layout__region--first').addClass('col col-lg-4 col-md-4 col-sm-12')
	jQuery('.page-vocabulary-series-line .layout--threecol-section .layout__region--second').addClass('col col-lg-4 col-md-4 col-sm-12')
	jQuery('.page-vocabulary-series-line .layout--threecol-section .layout__region--third').addClass('col col-lg-4 col-md-4 col-sm-12')
  	jQuery('.page-vocabulary-series-line .layout--twocol-section .layout__region--first').addClass('col col-lg-3 col-md-3 col-sm-12')
  	jQuery('.page-vocabulary-series-line .layout--twocol-section .layout__region--second').addClass('col col-lg-9 col-md-9 col-sm-12')

  /** ACCESSORIES Sticky Tabs**/
  let navigator_new = ".node--type-accessory-section .series-line-subsection-navigator";
  	jQuery(navigator_new).find('.field-content').eq(0).addClass('active');

  	jQuery(".node--type-accessory-section .views-element-container .view-content")
  	.find('.view-grouping').eq(0).wrapAll('<a name="filter-group-1" class="filter-group-1"></a>');
  	jQuery(".node--type-accessory-section .views-element-container .view-content")
  	.find('.view-grouping').eq(1).wrapAll('<a name="filter-group-2" class="filter-group-2"></a>');
  	jQuery(".node--type-accessory-section .views-element-container .view-content")
  	.find('.view-grouping').eq(2).wrapAll('<a name="filter-group-3" class="filter-group-3"></a>');
  	jQuery(".node--type-accessory-section .views-element-container .view-content")
  	.find('.view-grouping').eq(3).wrapAll('<a name="filter-group-4" class="filter-group-4"></a>');
  	jQuery(".node--type-accessory-section .views-element-container .view-content")
  	.find('.view-grouping').eq(4).wrapAll('<a name="filter-group-5" class="filter-group-5"></a>');
  	jQuery(".node--type-accessory-section .vocabulary-series-line .content")
  	.find('.layout--onecol').eq(0).wrapAll('<div class="title-description" />');

  	jQuery(navigator_new)
  	.find('.field-content').eq(0)
  	.click(function() {
          jQuery(navigator_new).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	}),
  	jQuery(navigator_new)
  	.find('.field-content').eq(1)
  	.click(function() {
          jQuery(navigator_new).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	}),
  	jQuery(navigator_new)
  	.find('.field-content').eq(2)
  	.click(function() {
          jQuery(navigator_new).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	}),
  	jQuery(navigator_new)
  	.find('.field-content').eq(3)
  	.click(function() {
          jQuery(navigator_new).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	}),
  	jQuery(navigator_new)
  	.find('.field-content').eq(4)
  	.click(function() {
          jQuery(navigator_new).find('.field-content').removeClass('active');
          jQuery(this).addClass('active');
  	});

	/* ACCESSORIES TABS */
	jQuery(".accessories-tabbed-nav .accessories-tab").eq(0).addClass('active');
	jQuery('accessories-tab-2').hide();

	jQuery('.related-accessories').click(function(){
		jQuery(".accessories-tabbed-nav .accessories-tab").removeClass('active');
		jQuery(".accessories-tabbed-nav .accessories-tab").eq(0).addClass('active');
		jQuery('.accessories-tab-1').show()
		jQuery('.accessories-tab-2').hide()
	})

	jQuery('.accessories-how-to').click(function(){
		jQuery(".accessories-tabbed-nav .accessories-tab").removeClass('active');
		jQuery(".accessories-tabbed-nav .accessories-tab").eq(1).addClass('active');
		jQuery('.accessories-tab-2').show()
		jQuery('.accessories-tab-1').hide()
	})

	//fixed to scroll treatment.

	//jQuery('.block-views-blockaccessory-subsection-list-block-1').scrollToFixed({ marginTop: 10, limit: jQuery(jQuery('h2')[5]).offset().top });


	jQuery( ".total" ).hide();
	var urlParams = new URLSearchParams(window.location.search);
	var string = urlParams.get('search_api_fulltext');
	if(string){
		jQuery( ".total" ).append( '"'+string+'"');
		var mb = jQuery('.total').text();
		jQuery(".search-card").after('<div class = "total" >' +mb + '</div>');

	}
	jQuery("form#views-exposed-form-blocks-block-1 .custom-sort-select").click(function() {

	  var urlParams = new URLSearchParams(window.location.search);
	  var sort_order = urlParams.get('sort_order');
	  if(!sort_order){
		  newUrl = window.location.href + "?sort_order=ASC";
	  }
	  if(sort_order == 'ASC'){
		  var newUrl = location.href.replace("sort_order=ASC","sort_order=DESC");
	  }else if(sort_order == 'DESC'){
		  var newUrl = location.href.replace("sort_order=DESC","sort_order=ASC");
	  }
	  jQuery(location).attr('href', newUrl)
	});


	// Glass Block Details Page
	jQuery(".node--type-glass-block .layout--onecol .block-inline-blockbasic .field--type-text-with-summary h3").eq(0).addClass('active tab1');
	jQuery(".node--type-glass-block .layout--onecol .block-inline-blockbasic .field--type-text-with-summary h3").eq(1).addClass('tab2');
	jQuery(".node--type-glass-block .layout--onecol .block-inline-blockbasic .field--type-text-with-summary h3").eq(2).addClass('tab3');
	jQuery(".node--type-glass-block .layout--onecol .block-inline-blockbasic .field--type-text-with-summary h3").eq(3).addClass('tab4');
	jQuery(".node--type-glass-block .layout--onecol .block-inline-blockbasic .field--type-text-with-summary h3").eq(4).addClass('tab5');
	jQuery(".node--type-glass-block #tab2").hide();
	jQuery(".node--type-glass-block #tab3").hide();
	jQuery(".node--type-glass-block #tab4").hide();
	jQuery(".node--type-glass-block #tab5").hide();

	function switch_tabs(tab) {
		jQuery(".node--type-glass-block .tabs").hide();
		jQuery(".node--type-glass-block .layout--onecol .menu-block .field--type-text-with-summary h3").removeClass('active');
		jQuery(".node--type-glass-block ." + tab ).addClass('active');
		jQuery(".node--type-glass-block #" + tab ).show();
	}

	jQuery(".node--type-glass-block .tab1").click(function(){
		switch_tabs('tab1');
	});
	jQuery(".node--type-glass-block .tab2").click(function(){
		switch_tabs('tab2');
	});
	jQuery(".node--type-glass-block .tab3").click(function(){
		switch_tabs('tab3');
	});
	jQuery(".node--type-glass-block .tab4").click(function(){
		switch_tabs('tab4');
	});
	jQuery(".node--type-glass-block .tab5").click(function(){
		switch_tabs('tab5');
	});


	 /* SpyScroll Start */
/*
	jQuery('.block-views-blockaccessory-subsection-for-accessory-section-block-1 .s-views-row:first-Child').attr('id','Anchors');
	jQuery('.block-views-blockaccessory-subsection-for-accessory-section-block-1 .s-views-row:nth-Child(2)').attr('id','Channel');
	jQuery('.block-views-blockaccessory-subsection-for-accessory-section-block-1 .s-views-row:nth-Child(3)').attr('id','Horizontals');
	jQuery('.block-views-blockaccessory-subsection-for-accessory-section-block-1 .s-views-row:nth-Child(4)').attr('id','Verticals');

	 jQuery.fn.isInViewport = function() {
    var elementTop = jQuery(this).offset().top;
    var elementBottom = elementTop + jQuery(this).outerHeight();

    var viewportTop = jQuery(window).scrollTop();
    var viewportBottom = viewportTop + jQuery(window).height();

    return elementBottom > viewportTop && elementTop < viewportBottom;
};
	if ((window.matchMedia('(min-width:845px)').matches)) {
		jQuery(window).scroll(function() {

			if(jQuery(window).scrollTop() > 452 && jQuery('#Verticals').isInViewport()==true){
				jQuery('.view-id-accessory_subsection_list.view-display-id-block_1').css({'position':'fixed','top':'137px'});
				console.log('footer')
			} else {
				jQuery('.view-id-accessory_subsection_list.view-display-id-block_1').css('position','static');
			}
		})
	}
*/
		/* SpyScroll end */

    //Slick slider initialize
    jQuery('.glassblock-slider').slick({
      arrows:false,
      dots: false,
      infinite:true,
      speed:500,
      autoplay:true,
      autoplaySpeed: 3000,
      slidesToShow:1,
      slidesToScroll:1
    });
    //On click of slider-nav childern,
    //Slick slider navigate to the respective index.
    jQuery('.glassblock-slider-nav > div').click(function() {
      jQuery('.glassblock-slider').slick('slickGoTo',jQuery(this).index());
    })

  /* Start How To Buy Webform */

  jQuery('#webform-submission-how-to-buy-add-form #edit-please-contact-us-regarding .custom-switch').each(function() {
    var how_to_buy_input_element = jQuery(this).children( "input" );
    var how_to_buy_label_element = jQuery(this).children( "label" ).html();
    var how_to_buy_input_label_element = "<div class='input-container'>" + how_to_buy_input_element.prop('outerHTML') + "</div><div class='label-container'>"	+ how_to_buy_label_element + "</div>";
    jQuery(this).html(how_to_buy_input_label_element);
  });

  jQuery('#webform-submission-how-to-buy-add-form button.btn').mouseover(function(){
    jQuery(this).css({"background-color":"#FFF4AA","border-color":"#FFF4AA"});
  });
  jQuery('#webform-submission-how-to-buy-add-form button.btn').mouseout(function(){
    jQuery(this).css({"background-color":"#FFE533","border-color":"#FFE533"});
  });

  jQuery('#webform-submission-how-to-buy-add-form ul.thumbnails.image_picker_selector li .thumbnail').each(function() {
    var how_to_buy_thumbnail_img = jQuery(this).children( "img" );
    var how_to_buy_thumbnail_p = jQuery(this).children( "p" );
    jQuery(this).html(how_to_buy_thumbnail_p);
    jQuery(this).children("p").after(how_to_buy_thumbnail_img);
  });
  /* End How To Buy Webform */
  /* Fancy login form buttons start */
  jQuery('#fancy-login-user-login-form #edit-actions--4 .btn-primary').mouseover(function(){
    jQuery(this).css({"background-color":"#FFF4AA","border-color":"#FFF4AA"});
  });
  jQuery('#fancy-login-user-login-form #edit-actions--4 .btn-primary').mouseout(function(){
    jQuery(this).css({"background-color":"#FFE533","border-color":"#FFE533"});
  });
  jQuery('#fancy-login-user-login-form #edit-actions--2 .btn-primary').mouseover(function(){
    jQuery(this).css({"background-color":"#FFF4AA","border-color":"#FFF4AA"});
  });
  jQuery('#fancy-login-user-login-form #edit-actions--2 .btn-primary').mouseout(function(){
    jQuery(this).css({"background-color":"#FFE533","border-color":"#FFE533"});
  });
  /********Fancy login button form end****/
  /* login, register, reset form start */
  jQuery('body.page-user-login form#user-login-form #edit-submit').mouseover(function(){
    jQuery(this).css({"background-color":"#FFF4AA","border-color":"#FFF4AA"});
  });
  jQuery('body.page-user-login form#user-login-form #edit-submit').mouseout(function(){
    jQuery(this).css({"background-color":"#FFE533","border-color":"#FFE533"});
  });
  jQuery('body.page-user-register form#user-register-form #edit-submit').mouseover(function(){
    jQuery(this).css({"background-color":"#FFF4AA","border-color":"#FFF4AA"});
  });
  jQuery('body.page-user-register form#user-register-form #edit-submit').mouseout(function(){
    jQuery(this).css({"background-color":"#FFE533","border-color":"#FFE533"});
  });
  jQuery('body.page-user-password form#user-pass #edit-submit').mouseover(function(){
    jQuery(this).css({"background-color":"#FFF4AA","border-color":"#FFF4AA"});
  });
  jQuery('body.page-user-password form#user-pass #edit-submit').mouseout(function(){
    jQuery(this).css({"background-color":"#FFE533","border-color":"#FFE533"});
  });
  /********login, register, reset form end****/

  jQuery('#glassBlockCarousel').carousel({
   interval: false
  });
  jQuery('#carousel-thumbs').carousel({
    interval: false
  });

  // handles the carousel thumbnails
  // https://stackoverflow.com/questions/25752187/bootstrap-carousel-with-thumbnails-multiple-carousel
  jQuery('[id^=carousel-selector-]').click(function() {
    var id_selector = jQuery(this).attr('id');
    var id = parseInt( id_selector.substr(id_selector.lastIndexOf('-') + 1) );
    jQuery('#glassBlockCarousel').carousel(id);
  });
  // Only display 3 items in nav on mobile.
  if (jQuery(window).width() < 575) {
    jQuery('#carousel-thumbs .row div:nth-child(4)').each(function() {
      var rowBoundary = jQuery(this);
      jQuery('<div class="row mx-0">').insertAfter(rowBoundary.parent()).append(rowBoundary.nextAll().addBack());
    });
    jQuery('#carousel-thumbs .carousel-item .row:nth-child(even)').each(function() {
      var boundary = jQuery(this);
      jQuery('<div class="carousel-item">').insertAfter(boundary.parent()).append(boundary.nextAll().addBack());
    });
  }
  // Hide slide arrows if too few items.
  if (jQuery('#carousel-thumbs .carousel-item').length < 2) {
    jQuery('#carousel-thumbs [class^=carousel-control-]').remove();
    jQuery('.machine-carousel-container #carousel-thumbs').css('padding','0 5px');
  }
  // when the carousel slides, auto update
  jQuery('#glassBlockCarousel').on('slide.bs.carousel', function(e) {
    var id = parseInt( jQuery(e.relatedTarget).attr('data-slide-number') );
    jQuery('[id^=carousel-selector-]').removeClass('selected');
    jQuery('[id=carousel-selector-'+id+']').addClass('selected');
  });
});

jQuery("body").children().each(function () {
    jQuery(this).html( jQuery(this).html().replace(/Â®/g,"<sup>Â®</sup>") );
});

jQuery('.block-views-blockseries-line-sections-block-1 .view-header h2').text(jQuery('.breadcrumb .breadcrumb-item:nth-of-type(2) a').text() + ' Accessories:');
jQuery('.block-views-blockseries-line-sections-block-2 .view-header h2').text(jQuery('.breadcrumb .breadcrumb-item:nth-of-type(2) a').text() + ' Docs:');
