/**
 * @file
 * Global utilities.
 *
 */
 /*
(function ($, Drupal) {
  
  'use strict';

  Drupal.behaviors.kiosk = {
    attach: function (context, settings) {

    }
  };
  
$(document).ready(function(){
$("hello").scroll(function(){
	alert("hi");
  	/*var currentscrollposition = $(this).scrollTop();
   // $("span").text( x+= 1);
   if (currentscrollposition > midscroll ) {
   //	$("hello").hide();
   	//alert("scroll=281");
   }
    $("h1").text(currentscrollposition);*/
    /*
  });

});
     
})(jQuery, Drupal);

*/
jQuery(document).ready(function($) {

	// var d = new Date();
	// alert(d);
	// var date_leftside_block = jQuery('.d-flex .justify-content-center .date')val();
	// 	  alert(date_leftside_block);
   $("#hello").scroll(function() {
   	  var myDiv = document.getElementById("hello");
     // window.scrollTo(500, myDiv.innerHeight);
    //scroll_new.scrollTo(0, 300);

     //alert("111");
});
// 	$('.hello').scroll(function(){

//     $('.hello').scrollTo(0, 300);
	

// });

});
