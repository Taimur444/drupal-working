/**
 * @file
 * Global utilities.
 *
 */
(function ($, Drupal) {

  'use strict';

  Drupal.behaviors.kiosk = {
    attach: function (context, settings) {

    }
  };

})(jQuery, Drupal);
