<?php

namespace Drupal\message;

/**
 * Message module-specific exception.
 */
class MessageException extends \Exception {}
