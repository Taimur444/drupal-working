Message notify example module is intended for developers and site builders
wanting to understand the key concepts and features of Message notify module.

To see example in action:
- Enable the Message-notify example module
- Set up email sending in your drupal site (you can set up core mail module or use contrib modules, such as smtp module)
- Add a comment to a node, and an email will be sent to the node author

NOTE: By default the module will sent an blank email to the author.You need to configute display view.
      - Go to MANAGE DISPLAY -> NOTIFY - EMAIL BODY & NOTIFY - EMAIL SUBJECT (Custom display settings for notify must be enabled to see this tabs)
