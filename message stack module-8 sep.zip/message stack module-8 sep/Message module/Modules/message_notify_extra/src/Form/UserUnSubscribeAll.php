<?php

namespace Drupal\message_notify_extra\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;

/**
 * Implements the state demo form controller.
 *
 * This example demonstrates using the #states property to bind the visibility
 * of a form element to the value of another element in the form. In the
 * example, when the user checks the "Need Special Accommodation" checkbox,
 * additional form elements are made visible.
 *
 * The submit handler for this form is implemented by the
 * \Drupal\form_api_example\Form\DemoBase class.
 *
 * @see \Drupal\Core\Form\FormBase
 * @see \Drupal\form_api_example\Form\DemoBase
 * @see drupal_process_states()
 */
class UserUnSubscribeAll extends FormBase {

  /**
   * Build the simple form.
   *
   * @inheritdoc
   */
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['description'] = [
      '#type' => 'item',
      '#markup' => $this->t('UnSubsribe to all nodes of Content Type.'),
    ];
   $form['question_subscribe'] = [
      '#type' => 'checkbox',
      '#title' => 'UnSubcribe to All Questions',
      '#default_value' => false,
    ];
    $form['topic_subscribe'] = [
      '#type' => 'checkbox',
      '#title' => 'UnSubcribe to All Posts',
      '#default_value' => false,
    ];
    // Add a submit button that handles the submission of the form.
    $form['actions']['submit'] = [
      '#type' => 'submit',
      '#value' => $this->t('Submit'),
    ];

    return $form;
  }

  /**
   * Getter method for Form ID.
   *
   * @inheritdoc
   */
  public function getFormId() {
    return 'form_api_example_state_demo';
  }

  /**
   * Implements submitForm callback.
   *
   * @inheritdoc
   */
  public function submitForm(array &$form, FormStateInterface $form_state) {
    // Find out what was submitted.
    $values = $form_state->getValues();  // getting form values

    $account = \Drupal::currentUser();  // loading current user
    $flag_id = "subscribe_node";         // flag id
    $flag_service = \Drupal::service('flag');
    $flag = $flag_service->getFlagById($flag_id); 
    $user = \Drupal::entityTypeManager()->getStorage('user')->load($account->id());
      //UnSubscribe to Question content
      $question_subscribe_form_value = $values['question_subscribe']; //form values
      // Get All nodes of a content type . i will use it to flag all nodes of type
      $question_nids = \Drupal::entityQuery('node')->condition('type','question')->execute(); 
      $question_nodes =  \Drupal\node\Entity\Node::loadMultiple($question_nids);
      if($question_subscribe_form_value == true) { // option is checked then unsubscribe from question node. 
        foreach ($question_nodes as $node) {
          $flagging = $flag_service->getFlagging($flag, $node, $account);
          if ($flagging) {
            $flag_service->unflag($flag, $node, $account); //unflag the node
          }
        }
        $this->messenger()->addMessage($this->t('You have UnSubscribed from All Question Conetnt'));
      }
      //unSubscribe to Topic content
      $topic_subscribe_form_value = $values['topic_subscribe'];
      // Get All nodes of a content type . i will use it to flag all nodes of type
      $topic_nids = \Drupal::entityQuery('node')->condition('type','topic')->execute();
      $topic_nodes =  \Drupal\node\Entity\Node::loadMultiple($topic_nids);
      if($topic_subscribe_form_value == true) { // option is checked then unsubscribe from topic node.
        foreach ($topic_nodes as $node) {
          $flagging = $flag_service->getFlagging($flag, $node, $account);
          if ($flagging) {
            $flag_service->unflag($flag, $node, $account);
          }
        }
        $this->messenger()->addMessage($this->t('You have UnSubscribed from All Posts Conetnt'));
      }
  }

}
