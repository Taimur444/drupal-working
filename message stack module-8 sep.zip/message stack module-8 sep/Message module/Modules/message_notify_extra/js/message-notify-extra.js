jQuery(document).ready(function($) {
	$('span.bell-outer').click(function () {
        // TOGGLE (SHOW OR HIDE) NOTIFICATION WINDOW.
        $('#block-views-block-list-subscribed-content-block-1 .view-content').fadeToggle('fast', function () {
            if ($('#block-views-block-list-subscribed-content-block-1 .view-content').is(':hidden')) {
                //$('svg.bi-bell').css('background-color', '#2E467C');
                $('#noti_Counter').css('display', 'block');
                $('#block-views-block-list-subscribed-content-block-1 .more-link').css('display', 'none');
            }
            // CHANGE BACKGROUND COLOR OF THE BUTTON.
            else{
                $('#block-views-block-list-subscribed-content-block-1 .more-link').css('display', 'block');
                //alert("534534");
            }
        });
        //$('#block-danland-views-block-duplicate-of-subscribe-node-block-1 .view-content').css('display', 'block');
        $('#noti_Counter').css('display', 'none');    // HIDE THE COUNTER.

        //return false;
    });
});

