var resturant_sub_menu = document.getElementById('resturant-sub-menu');
var restaurant_menu_height = resturant_sub_menu.offsetHeight;   
alert(restaurant_menu_height);  
if (restaurant_menu_height <=50) {
	$(".food-section-restaurant-details").css({'height':'100'});
} 
else if (restaurant_menu_height <=100) {
 	$(".food-section-restaurant-details").css({'height':'150'});	
}  
else if (restaurant_menu_height <=150) {
 	$(".food-section-restaurant-details").css({'height':'200'});	
} 
else if (restaurant_menu_height <=200) {
 	$(".food-section-restaurant-details").css({'height':'250'});	
} 
else if (restaurant_menu_height <=250) {
 	$(".food-section-restaurant-details").css({'height':'300'});	
} 
else if (restaurant_menu_height <=300) {
 	$(".food-section-restaurant-details").css({'height':'350'});	
}
else(restaurant_menu_height <=350) {
 	$(".food-section-restaurant-details").css({'height':'400'});	
}  
               