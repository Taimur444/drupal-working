$(document).ready(function(){   //blocks variable at front page
  alert("jQuery");
  var block1_food_menu_section = $( '.head-section-food-menu .block1-food-menu-section .field' ).html();
  var block2_food_menu_section = $( '.head-section-food-menu .block2-food-menu-section .field' ).html();
  var block3_food_menu_section = $( '.head-section-food-menu .block3-food-menu-section .field' ).html();
  var block4_food_menu_section = $( '.head-section-food-menu .block4-food-menu-section .field' ).html();
  var food_section_restaurant_details = $('.food-section-restaurant-info .food-section-restaurant-details' ).html();

  if((food_section_restaurant_details=undefined)) { // if submenu is undefined
    $(".food-section-restaurant-image img").css({'maargin-left':'28%'});
    $(".food-section-restaurant-details").css({'display': 'none'});
  }
       // conditions for blocks if any one in undefined then other blocks will adjust space.i.e. if bolck one is empty.                                           
    if((block1_food_menu_section==undefined) && (block2_food_menu_section!==undefined) && (block3_food_menu_section!==undefined) && (block4_food_menu_section!==undefined)){
              
    }
        // if  third block is empty.    
    else if((block1_food_menu_section!==undefined) && (block2_food_menu_section!==undefined) && (block3_food_menu_section==undefined) && (block4_food_menu_section!==undefined)){
      $(".block3-food-menu-section").css({'display': 'none'});
      $(".block1-food-menu-section").css({'width': '30%'});
    }
        // if third and fourth block is epmty.
    else if((block1_food_menu_section!==undefined) && (block2_food_menu_section!==undefined) && (block3_food_menu_section==undefined) && (block4_food_menu_section==undefined)) {
      $(".block3-food-menu-section").css({'display': 'none'});
      $(".block4-food-menu-section").css({'display': 'none'});
      $(".block1-food-menu-section").css({'width': '50%'});
      $(".block2-food-menu-section").css({'width': '50%'});
    }
       //if block 1 and 2 is empty.
    else if((block1_food_menu_section==undefined) && (block2_food_menu_section==undefined) && (block3_food_menu_section!==undefined) && (block4_food_menu_section!==undefined)) {
      $(".block1-food-menu-section").css({'display': 'none'});
      $(".block2-food-menu-section").css({'display': 'none'});
               
    }
      //if block 1 and 3 is empty.
    else if((block1_food_menu_section==undefined) && (block2_food_menu_section!==undefined) && (block3_food_menu_section==undefined) && (block4_food_menu_section!==undefined)) {
      $(".block1-food-menu-section").css({'display': 'none'});
      $(".block3-food-menu-section").css({'display': 'none'});
      $(".block2-food-menu-section").css({'width': '50%'});
      $(".block4-food-menu-section").css({'width': '50%'});
    }

      //if block 2 and 3 is empty.
    else if((block1_food_menu_section!==undefined) && (block2_food_menu_section==undefined) && (block3_food_menu_section==undefined) && (block4_food_menu_section!==undefined)) {
      $(".block2-food-menu-section").css({'display': 'none'});
      $(".block3-food-menu-section").css({'display': 'none'});
      $(".block1-food-menu-section").css({'width': '50%'});
      $(".block4-food-menu-section").css({'width': '50%'});
    }

      //if block 2 and 4 is empty.
    else if((block1_food_menu_section!==undefined) && (block2_food_menu_section==undefined) && (block3_food_menu_section!==undefined) && (block4_food_menu_section==undefined)) {
      $(".block2-food-menu-section").css({'display': 'none'});
      $(".block4-food-menu-section").css({'display': 'none'});
      $(".block1-food-menu-section").css({'width': '50%'});
      $(".block3-food-menu-section").css({'width': '50%'});
    }

      //if block 1 and 4 is empty.
    else if((block1_food_menu_section==undefined) && (block2_food_menu_section!==undefined) && (block3_food_menu_section!==undefined) && (block4_food_menu_section==undefined)) {
      $(".block1-food-menu-section").css({'display': 'none'});
      $(".block4-food-menu-section").css({'display': 'none'});
      $(".block2-food-menu-section").css({'width': '50%'});
      $(".block3-food-menu-section").css({'width': '50%'});
    }
         
      //if block 1 and 2 is empty 
    else if((block1_food_menu_section==undefined) && (block2_food_menu_section==undefined) && (block3_food_menu_section==undefined) && (block4_food_menu_section!==undefined)) {
      $(".block1-food-menu-section").css({'display': 'none'});
      $(".block2-food-menu-section").css({'display': 'none'});
      $(".block3-food-menu-section").css({'display': 'none'});
      $(".block4-food-menu-section").css({'width': '100%'});
              
    }

     //if block 2,3 & 4  is empty.
    else if((block1_food_menu_section!==undefined) && (block2_food_menu_section==undefined) && (block3_food_menu_section==undefined) && (block4_food_menu_section==undefined)) {
      $(".block2-food-menu-section").css({'display': 'none'});
      $(".block3-food-menu-section").css({'display': 'none'});
      $(".block4-food-menu-section").css({'display': 'none'});
      $(".block1-food-menu-section").css({'width': '100%'});
    }

     //if block 1,3 & 4  is empty.
    else if((block1_food_menu_section==undefined) && (block2_food_menu_section!==undefined) && (block3_food_menu_section==undefined) && (block4_food_menu_section==undefined)) {
      $(".block1-food-menu-section").css({'display': 'none'});
      $(".block3-food-menu-section").css({'display': 'none'});
      $(".block4-food-menu-section").css({'display': 'none'});
      $(".block2-food-menu-section").css({'width': '100%'});
    }
     
     //if block 1  is empty.   
    else if((block1_food_menu_section==undefined) && (block2_food_menu_section!==undefined) && (block3_food_menu_section!==undefined) && (block4_food_menu_section!==undefined)) {
      alert("hello12");
      $(".block2-food-menu-section").css({'width': '30%'});
      $(".block3-food-menu-section").css({'width': '30%'});
      $(".block4-food-menu-section").css({'width': '100%'});
      $(".block1-food-menu-section").css({'display': 'none'});
    }
     
     //if block 2  is empty.
    else if((block1_food_menu_section!==undefined) && (block2_food_menu_section==undefined) && (block3_food_menu_section!==undefined) && (block4_food_menu_section!==undefined)) {
      $(".block1-food-menu-section").css({'width': '30%'});
      $(".block3-food-menu-section").css({'width': '30%'});
      $(".block4-food-menu-section").css({'width': '30%'});
      $(".block2-food-menu-section").css({'display': 'none'});
    }

    //if block  3  is empty.
    else if((block1_food_menu_section!==undefined) && (block2_food_menu_section!==undefined) && (block3_food_menu_section==undefined) && (block4_food_menu_section!==undefined)) {
      $(".block1-food-menu-section").css({'width': '30%'});
      $(".block2-food-menu-section").css({'width': '30%'});
      $(".block4-food-menu-section").css({'width': '30%'});
      $(".block3-food-menu-section").css({'display': 'none'});
    }

    //if block  4  is empty.
    else if((block1_food_menu_section!==undefined) && (block2_food_menu_section!==undefined) && (block3_food_menu_section!==undefined) && (block4_food_menu_section==undefined)) {
      alert("4th block empty");
      $(".block1-food-menu-section").css({'width': '30%','transform': 'translateX(-166%)'});
      $(".block2-food-menu-section").css({'width': '30%','transform': 'translateY(-100%)','margin-left': '32.65%'});
      $(".block3-food-menu-section").css({'width': '30%','transform': 'translateY(-216%)','margin-left': '65%'});
      $(".container .heading-gallery").css({'margin-top': '10%','margin-left': '31%','margin-right': '32%'});
      $(".block4-food-menu-section").css({'display': 'none'});
    }
}
//$(document).ready(function(){
  if(window.matchMedia("(max-width: 767px)").matches){ 
      alert("This is a tablet or desktop.");
                                                   // The viewport is less than 768 pixels wide
    $(".block1-food-menu-section").css({'width': '100%','transform': 'translateX(0%)'});
    $(".block2-food-menu-section").css({'width': '100%','transform': 'translateY(2%)','margin-left': '0.65%'});
    $(".block3-food-menu-section").css({'width': '100%','transform': 'translateY(2%)','margin-left': '1%'});
    $(".block4-food-menu-section").css({'display': 'none'});

  } 
  else{
    // The viewport is at least 768 pixels wide
    alert("else.");
    $(".food-section-restaurant-details").css({'transform': 'translateY(-133%)','margin-left': '50%'});
    $(".block1-food-menu-section").css({'transform': 'translateY(-172%)','margin-left': '30px'});
    $(".block2-food-menu-section").css({'transform': 'translateY(-170%)','margin-left': '0.65%'});
    $(".block3-food-menu-section").css({'transform': 'translateY(-281%)','margin-left': '65%'});
  }

//});
bsContainerWidth = $("body").find('.container').width()
    if (bsContainerWidth <= 700){
      $(".block3-food-menu-section").css({'width': '100%','transform': 'translateX(1%)','margin-left': '0%'});
      $(".block4-food-menu-section").css({'width': '100%','transform': 'translateY(1%)','margin-left': '1%','margin-top': '1.3%'});
    }

    else if (bsContainerWidth <= 768){
      $(".block3-food-menu-section").css({'width': '48%','transform': 'translateX(-2%)','margin-left': '0%'});
      $(".block4-food-menu-section").css({'width': '48%','transform': 'translateY(-106%)','margin-left': '51%','margin-top': '1.3%'});
    }

    else if (bsContainerWidth >= 992){
      $(".block3-food-menu-section").css({'width': '49%','transform': 'translateY(-5%)','margin-left': '0%'});
      $(".block4-food-menu-section").css({'width': '49%','transform': 'translateY(-116%)','margin-left': '0%','margin-top': '1.3%'});
    }
                          
    else{
                         
    }
 


  
  // countLines(); 
var resturant_sub_menu = document.getElementById('resturant-sub-menu');
var restaurant_menu_height = resturant_sub_menu.offsetHeight;   
alert(restaurant_menu_height);
if(window.matchMedia("(max-width: 767px)").matches){ 
  alert("new mobile veiw");
  if (restaurant_menu_height <=50) {
  alert("new height 100");
  $(".food-section-restaurant-details").css({'height':'100'});
  }

  else if (restaurant_menu_height <=100) {
  alert("new height 150");
  $(".food-section-restaurant-details").css({'height':'150'});  
  }
  else if (restaurant_menu_height <=150) {
  alert("new height 200");
  $(".food-section-restaurant-details").css({'height':'200'});  
  }
  else if (restaurant_menu_height <=200) {
  alert("new height 250");
  $(".food-section-restaurant-details").css({'height':'250'});  
  }
  else if (restaurant_menu_height <=250) {
  alert("new height 300");
  $(".food-section-restaurant-details").css({'height':'300'});  
  }
  else if (restaurant_menu_height <=300) {
  alert("new height 350");
  $(".food-section-restaurant-details").css({'height':'350'});  
  }
  else if(restaurant_menu_height <=350) {
  alert("new height 400");
  $(".food-section-restaurant-details").css({'height':'400'});  
  }
  else if(restaurant_menu_height <=400) {
  alert("new height 400");
  $(".food-section-restaurant-details").css({'height':'450'});  
  }

}
if(window.matchMedia("(max-width: 768px)").matches){ 
  alert("new tablet veiw");
  if (restaurant_menu_height <=50) {
  alert("new height 100");
  $(".food-section-restaurant-details").css({'height':'100'});
  }

  else if (restaurant_menu_height <=100) {
  alert("new height 150");
  $(".food-section-restaurant-details").css({'height':'150'});  
  }
  else if (restaurant_menu_height <=150) {
  alert("new height 200");
  $(".food-section-restaurant-details").css({'height':'200'});  
  }
  else if (restaurant_menu_height <=200) {
  alert("new height 250");
  $(".food-section-restaurant-details").css({'height':'250'});  
  }
  else if (restaurant_menu_height <=250) {
  alert("new height 300");
  $(".food-section-restaurant-details").css({'height':'300'});  
  }
  else if (restaurant_menu_height <=300) {
  alert("new height 350");
  $(".food-section-restaurant-details").css({'height':'350'});  
  }
  else if(restaurant_menu_height <=350) {
  alert("new height 400");
  $(".food-section-restaurant-details").css({'height':'400'});  
  }
  else if(restaurant_menu_height <=400) {
  alert("new height 400");
  $(".food-section-restaurant-details").css({'height':'450'});  
  }
}