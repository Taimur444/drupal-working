#nav-bar
{
	position:sticky;
	top:0;

}