<?php

namespace Drupal\message_subscribe\Exception;

/**
 * Message subscribe exceptions.
 */
class MessageSubscribeException extends \Exception {}
